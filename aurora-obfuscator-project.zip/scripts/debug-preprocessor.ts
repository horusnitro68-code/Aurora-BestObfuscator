import { tokenize } from "../src/lib/luauPreprocessor";
import * as fs from "fs";

const source = fs.readFileSync("/tmp/segurity.lua.txt", "utf8");

// Inline minimal versions of findLoops/transformLoop for debugging
const KEYWORDS = new Set([
  "and", "break", "do", "else", "elseif", "end", "false", "for",
  "function", "if", "in", "local", "nil", "not", "or", "repeat",
  "return", "then", "true", "until", "while", "continue",
]);

function tokenizeLocal(source: string) {
  const tokens: any[] = [];
  let i = 0;
  while (i < source.length) {
    const ch = source[i];
    if (ch === "[" && source[i + 1] === "[") {
      const start = i;
      let eq = 0;
      i += 2;
      while (source[i] === "=") { eq++; i++; }
      const close = "]" + "=".repeat(eq) + "]";
      while (i < source.length) {
        if (source.slice(i, i + close.length) === close) { i += close.length; break; }
        i++;
      }
      tokens.push({ type: "string", text: source.slice(start, i), start, end: i });
      continue;
    }
    if (ch === "-" && source[i + 1] === "-") {
      const start = i;
      i += 2;
      while (i < source.length && source[i] !== "\n") i++;
      tokens.push({ type: "comment", text: source.slice(start, i), start, end: i });
      continue;
    }
    if (ch === '"' || ch === "'") {
      const start = i;
      const quote = ch;
      i++;
      while (i < source.length) {
        if (source[i] === "\\") { i += 2; continue; }
        if (source[i] === quote) { i++; break; }
        i++;
      }
      tokens.push({ type: "string", text: source.slice(start, i), start, end: i });
      continue;
    }
    if (/\s/.test(ch)) {
      const start = i;
      while (i < source.length && /\s/.test(source[i])) i++;
      tokens.push({ type: "other", text: source.slice(start, i), start, end: i });
      continue;
    }
    if (/[a-zA-Z_]/.test(ch)) {
      const start = i;
      while (i < source.length && /[a-zA-Z0-9_]/.test(source[i])) i++;
      const word = source.slice(start, i);
      tokens.push({ type: KEYWORDS.has(word) ? "keyword" : "identifier", text: word, start, end: i });
      continue;
    }
    if (/[0-9]/.test(ch)) {
      const start = i;
      while (i < source.length && /[0-9.a-zA-Z]/.test(source[i])) i++;
      tokens.push({ type: "other", text: source.slice(start, i), start, end: i });
      continue;
    }
    tokens.push({ type: "other", text: ch, start: i, end: i + 1 });
    i++;
  }
  return tokens;
}

function findLoops(tokens: any[], source: string) {
  const loops: any[] = [];
  const stack: any[] = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t.type !== "keyword") continue;
    if (t.text === "do") {
      let isLoopBody = false;
      let loopType: any = undefined;
      for (let j = i - 1; j >= 0; j--) {
        const prev = tokens[j];
        if (prev.type === "keyword" && (prev.text === "while" || prev.text === "for" || prev.text === "if" || prev.text === "elseif")) {
          if (prev.text === "while" || prev.text === "for") {
            isLoopBody = true;
            loopType = prev.text;
          }
          break;
        }
      }
      stack.push({ type: "do", isLoopBody, loopKeywordType: loopType, doTokenEnd: t.end });
    } else if (t.text === "if") {
      stack.push({ type: "if" });
    } else if (t.text === "function") {
      stack.push({ type: "function" });
    } else if (t.text === "repeat") {
      stack.push({ type: "repeat", doTokenEnd: t.end });
    } else if (t.text === "end") {
      const entry = stack.pop();
      if (entry && entry.type === "do" && entry.isLoopBody && entry.loopKeywordType) {
        loops.push({ type: entry.loopKeywordType, bodyStart: entry.doTokenEnd, bodyEnd: t.start });
      }
    } else if (t.text === "until") {
      let entry = stack.pop();
      while (entry && entry.type !== "repeat") entry = stack.pop();
      if (entry && entry.type === "repeat") {
        loops.push({ type: "repeat", bodyStart: entry.doTokenEnd, bodyEnd: t.start });
      }
    }
  }
  return loops;
}

let s = source
  .replace(/\btask\.wait\b/g, "wait")
  .replace(/\btask\.spawn\b/g, "spawn")
  .replace(/\btask\.delay\b/g, "delay")
  .replace(/\btask\.defer\b/g, "defer")
  .replace(/\btypeof\b/g, "type");

let iterations = 0;
let changed = true;
while (changed && iterations < 20) {
  changed = false;
  iterations++;
  const tokens = tokenizeLocal(s);
  const loops = findLoops(tokens, s).sort((a: any, b: any) => b.bodyStart - a.bodyStart);
  console.log(`Iteration ${iterations}: found ${loops.length} loops`);
  for (const loop of loops.slice(0, 10)) {
    const body = s.slice(loop.bodyStart, loop.bodyEnd).trimStart();
    const preview = body.slice(0, 80).replace(/\n/g, "\\n");
    console.log(`  ${loop.type} bodyStart=${loop.bodyStart} bodyEnd=${loop.bodyEnd} first80=${preview}`);
  }
  // We won't actually transform here, just inspect
  changed = false;
}

console.log("Done");
