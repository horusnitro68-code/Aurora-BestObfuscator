import { obfuscateLua } from "../src/lib/luaObfuscator";
import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

function runLua(name: string, code: string, input?: string): { output: string; error?: string } {
  const L = lauxlib.luaL_newstate();
  lualib.luaL_openlibs(L);

  let captured = "";
  lauxlib.luaL_dostring(L, to_luastring(`
    __capture = {}
    __print = print
    function print(...)
      local args = {...}
      local s = {}
      for i = 1, #args do
        s[i] = tostring(args[i])
      end
      table.insert(__capture, table.concat(s, "\t"))
    end
  `));

  const status = lauxlib.luaL_dostring(L, to_luastring(code));
  if (status !== lua.LUA_OK) {
    const err = lua.lua_tostring(L, -1);
    return { output: captured, error: err ? to_jsstring(err) : `Lua error ${status}` };
  }

  lauxlib.luaL_dostring(L, to_luastring(`
    for i = 1, #__capture do
      __capture[i] = __capture[i]
    end
  `));

  const getResult = lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
  const result = lua.lua_tostring(L, -1);
  return {
    output: result ? to_jsstring(result) : "",
    error: undefined,
  };
}

function testScript(name: string, source: string) {
  console.log(`\n=== ${name} ===`);
  console.log(`Input size: ${source.length} bytes`);

  const original = runLua("original", source);
  if (original.error) {
    console.log(`Original script error: ${original.error}`);
    return;
  }
  console.log(`Original output:\n${original.output || "(empty)"}`);

  const vmResult = tryCompileToVM(source);
  if (!vmResult.success) {
    console.log(`VM compilation failed: ${vmResult.error}`);
    console.log("Falling back to legacy obfuscation...");
  }

  let obfuscated: string;
  try {
    obfuscated = obfuscateLua(source);
  } catch (err) {
    console.log(`Obfuscation failed: ${err instanceof Error ? err.message : err}`);
    return;
  }

  const usedVM = obfuscated.includes("Aurora X VM v4.0");
  console.log(`Used real VM: ${usedVM}`);
  console.log(`Output size: ${obfuscated.length} bytes`);

  const obfResult = runLua("obfuscated", obfuscated);
  if (obfResult.error) {
    console.log(`Obfuscated execution error: ${obfResult.error}`);
    return;
  }
  console.log(`Obfuscated output:\n${obfResult.output || "(empty)"}`);

  if (original.output === obfResult.output) {
    console.log("✅ Outputs match");
  } else {
    console.log("❌ Outputs differ");
    console.log(`Expected: ${JSON.stringify(original.output)}`);
    console.log(`Got: ${JSON.stringify(obfResult.output)}`);
  }
}

const tests = {
  arithmetic: `local a = 5
local b = 3
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a % b)
print(a ^ b)`,

  logic: `local x = 10
if x > 5 then
  print("greater")
else
  print("less")
end
if x <= 10 then
  print("ok")
end`,

  functions: `function double(n)
  return n * 2
end
print(double(7))
function sum(a, b)
  return a + b
end
print(sum(3, 4))`,

  tables: `local t = {a = 1, b = 2}
print(t.a)
print(t.b)
t.c = 3
print(t.c)
local arr = {10, 20, 30}
print(#arr)
print(arr[1])`,

  loops: `local s = 0
for i = 1, 5 do
  s = s + i
end
print(s)

local n = 3
while n > 0 do
  print(n)
  n = n - 1
end`,

  strings: `local a = "Hello"
local b = "World"
print(a .. " " .. b)
print(#a)`,

  factorial: `function fact(n)
  if n <= 1 then
    return 1
  else
    return n * fact(n - 1)
  end
end
print(fact(5))`,

  fibonacci: `function fib(n)
  if n <= 1 then
    return n
  end
  return fib(n - 1) + fib(n - 2)
end
print(fib(10))`,
};

for (const [name, source] of Object.entries(tests)) {
  testScript(name, source);
}
