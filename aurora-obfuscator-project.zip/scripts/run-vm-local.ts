#!/usr/bin/env bun
/**
 * Aurora X VM - Local Runner
 * Runs a compiled VM Lua file with the enhanced Roblox mock locally.
 * Shows errors like Delta would, no need to upload to gofile.
 *
 * Usage:
 *   bun run scripts/run-vm-local.ts <compiled.lua>    # Run pre-compiled file
 *   bun run scripts/run-vm-local.ts --source <src.lua> # Compile and run source
 */

import { tryCompileToVM } from '../src/lib/vmObfuscator';
import { execSync, spawn } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

const MOCK_PATH = path.resolve(__dirname, '..', 'test-harness', 'roblox-mock.lua');
const LUA_BIN = 'lua5.1';

const args = process.argv.slice(2);
const DEBUG = args.includes('--debug');
const TIMEOUT = parseInt(args[args.indexOf('--timeout') + 1] || '30', 10) * 1000;

let targetFile: string | null = null;
let sourceMode = false;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--source') {
    sourceMode = true;
    targetFile = args[i + 1];
    break;
  }
  if (args[i] === '--timeout') {
    i++; // skip timeout value
    continue;
  }
  if (args[i] === '--debug') {
    continue;
  }
  if (!args[i].startsWith('--')) {
    targetFile = args[i];
  }
}

if (!targetFile) {
  console.error('Usage:');
  console.error('  bun run scripts/run-vm-local.ts <compiled.lua>');
  console.error('  bun run scripts/run-vm-local.ts --source <source.lua>');
  console.error('  bun run scripts/run-vm-local.ts --debug <file>');
  console.error('  bun run scripts/run-vm-local.ts --timeout 60 <file>');
  process.exit(1);
}

// Step 1: Compile if source mode
let runFile = targetFile;
if (sourceMode) {
  console.log(`[1/2] Compiling ${targetFile}...`);
  const src = fs.readFileSync(targetFile, 'utf-8');
  const result = tryCompileToVM(src);
  if (!result.success) {
    console.error(`[FAIL] Compilation error: ${result.error}`);
    process.exit(1);
  }
  
  runFile = '/tmp/aurora-vm-run.lua';
  fs.writeFileSync(runFile, result.output);
  console.log(`[OK] Compiled: ${(result.output.length / 1024).toFixed(1)} KB`);
}

// Step 2: Run with mock
console.log(`[2/2] Running with Roblox mock...\n`);
console.log('─'.repeat(50));

const startTime = Date.now();

try {
  const output = execSync(`${LUA_BIN} ${MOCK_PATH} ${runFile} 2>&1`, {
    timeout: TIMEOUT,
    encoding: 'utf-8',
    maxBuffer: 10 * 1024 * 1024,
  });
  
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
  
  // Print mock stderr output (warnings, errors)
  const lines = output.split('\n');
  for (const line of lines) {
    if (line.startsWith('[WARN]') || line.startsWith('[Mock]') || line.startsWith('[Aurora')) {
      console.log(`  ${line}`);
    }
  }
  
  // Print actual script output (stdout)
  console.log('\n--- Script Output ---');
  for (const line of lines) {
    if (!line.startsWith('[WARN]') && !line.startsWith('[Mock]') && line.trim()) {
      console.log(`  ${line}`);
    }
  }
  
  console.log(`\n[OK] Script completed in ${elapsed}s`);
  
} catch (e: any) {
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
  
  // Capture stderr/stdout from the error
  const stderr = (e.stderr || '') as string;
  const stdout = (e.stdout || '') as string;
  const combined = `${stdout}\n${stderr}`.trim();
  
  console.log(`[FAIL] Script crashed after ${elapsed}s`);
  console.log('─'.repeat(50));
  
  // Show the error clearly
  const errorLines = combined.split('\n');
  let inError = false;
  
  for (const line of errorLines) {
    // Highlight VM errors
    if (line.includes('[Aurora VM]') || line.includes('Runtime error:') || 
        line.includes('Stack Begin') || line.includes('Stack End') ||
        line.includes('Script ') || line.includes('[WARN]')) {
      console.log(`  ${line}`);
      inError = true;
    } else if (line.trim() && line.includes('error')) {
      if (inError) {
        console.log(`  ${line}`);
      }
    }
  }
  
  // Show full error for debug mode
  if (DEBUG) {
    console.log('\n--- Full Output ---');
    console.log(combined.substring(0, 2000));
  }
  
  // Show exit code
  const status = (e as any).status;
  console.log(`\n[EXIT] Code: ${status !== undefined ? status : 'signal'}`);
  
  process.exit(1);
}
