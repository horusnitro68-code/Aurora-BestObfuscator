import { obfuscateLua } from "../src/lib/luaObfuscator";
import { canCompileWithVM, tryCompileToVM } from "../src/lib/vmObfuscator";
import * as luaparse from "luaparse";

function testScript(name: string, source: string) {
  console.log(`\n=== ${name} ===`);
  console.log(`Input size: ${source.length} bytes`);
  const canVM = canCompileWithVM(source);
  console.log(`Can compile with VM: ${canVM}`);

  const vmResult = tryCompileToVM(source);
  if (!vmResult.success) {
    console.log(`VM compilation failed: ${vmResult.error}`);
  } else {
    console.log(`VM compilation succeeded; output preview: ${vmResult.output.slice(0, 120)}...`);
  }

  const start = performance.now();
  const output = obfuscateLua(source);
  const end = performance.now();

  console.log(`Output size: ${output.length} bytes`);
  console.log(`Time: ${(end - start).toFixed(2)}ms`);

  // Try to detect if VM was used (simple heuristic)
  const usedVM = output.includes("Aurora X VM v4.0");
  console.log(`Used real VM: ${usedVM}`);

  // Syntax check the generated Lua output
  try {
    luaparse.parse(output, { comments: true });
    console.log("Generated Lua syntax: valid");
  } catch (err) {
    console.log(`Generated Lua syntax: INVALID - ${err instanceof Error ? err.message : err}`);
  }

  return output;
}

// Small script: should use VM
const small = `local a = 1
local b = 2
local c = a + b
print(c)
if c > 2 then
  print("greater")
else
  print("less")
end
function hello(x)
  return x * 2
end
local t = {a=1, b=2}
hello(t.a)
`;

// Medium script
const medium = (() => {
  const lines: string[] = [];
  lines.push("local sum = 0");
  for (let i = 1; i <= 100; i++) {
    lines.push(`sum = sum + ${i}`);
    lines.push(`if sum > ${i * 10} then`);
    lines.push(`  print("big")`);
    lines.push("end");
  }
  lines.push("print(sum)");
  return lines.join("\n");
})();

// Large synthetic script (~500KB)
const large = (() => {
  const lines: string[] = [];
  lines.push("local data = {}");
  for (let i = 1; i <= 15000; i++) {
    lines.push(`data["key_${i}"] = ${i * 7}`);
    lines.push(`data["flag_${i}"] = ${i % 2 == 0 ? "true" : "false"}`);
    if (i % 100 === 0) {
      lines.push(`if data["key_${i}"] > ${i * 10} then`);
      lines.push(`  print("threshold")`);
      lines.push("end");
    }
  }
  lines.push("print(#data)");
  return lines.join("\n");
})();

console.log("Testing Aurora X VM obfuscator...");

try {
  testScript("Small script", small);
} catch (err) {
  console.error("Small script failed:", err instanceof Error ? err.message : err);
}

try {
  testScript("Medium script", medium);
} catch (err) {
  console.error("Medium script failed:", err instanceof Error ? err.message : err);
}

try {
  testScript("Large synthetic script (~500KB)", large);
} catch (err) {
  console.error("Large script failed:", err instanceof Error ? err.message : err);
}
