/**
 * Ofusca con protección ULTRA (3 capas):
 *   1. VM bytecode (source → VM)
 *   2. Legacy chunks (VM → Legacy)
 *   3. Legacy AGAIN sobre el resultado (Legacy → Legacy²)
 * + keyLength 512, chunkSize 128 (máxima fragmentación)
 * Uso: bun scripts/obfuscate-ultra.ts <input.lua> <output.lua>
 */
import { readFileSync, writeFileSync } from "node:fs";
import { obfuscateLua, legacyObfuscateLua, type ObfuscationOptions } from "../src/lib/luaObfuscator.js";

const sourcePath = process.argv[2];
const outputPath = process.argv[3];
if (!sourcePath || !outputPath) {
  console.error("Uso: bun scripts/obfuscate-ultra.ts <input.lua> <output.lua>");
  process.exit(1);
}

const source = readFileSync(sourcePath, "utf-8");
console.log(`📄 Source: ${sourcePath} (${(source.length / 1024).toFixed(1)} KB)`);

// Capa 1+2: VM + Legacy (doble protección interna)
const opts: Partial<ObfuscationOptions> = {
  watermark: "Protected by Aurora X v4.0 - ULTRA",
  doubleProtection: true,
  controlFlow: true,
  antiDebug: true,
  botProtection: true,
  keyLength: 512,
  chunkSize: 128,
  advancedOpcodes: true,
};

console.log("🔒 Capa 1+2: VM + Legacy...");
const layer12 = obfuscateLua(source, opts);

// Capa 3: Legacy otra vez sobre el resultado (triple capa)
console.log("🔒 Capa 3: Legacy² sobre el resultado...");
const layer3 = legacyObfuscateLua(layer12, {
  watermark: "Protected by Aurora X v4.0 - ULTRA",
  doubleProtection: false,
  controlFlow: true,
  antiDebug: true,
  botProtection: true,
  keyLength: 512,
  chunkSize: 128,
  advancedOpcodes: true,
});

writeFileSync(outputPath, layer3, "utf-8");
console.log(`✅ Ofuscado ULTRA: ${outputPath} (${(layer3.length / 1024).toFixed(1)} KB)`);
console.log(`📏 Original: ${source.length} B → Capa1+2: ${layer12.length} B → ULTRA: ${layer3.length} B (x${(layer3.length / Math.max(source.length, 1)).toFixed(1)})`);
