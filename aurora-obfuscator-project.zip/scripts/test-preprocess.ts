import { preprocessLuau } from "../src/lib/luauPreprocessor.ts";
import { readFileSync } from "node:fs";

// Read the exact raw source
const raw = readFileSync("public/bloxfruit_raw.lua", "utf-8");

// Find the queue_on_teleport section
const lines = raw.split("\n");
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes("queue_on_teleport") || lines[i].includes("aurorax.site")) {
    const start = Math.max(0, i - 1);
    const end = Math.min(lines.length, i + 4);
    console.log("=== RAW SOURCE (lines " + (start+1) + "-" + end + ") ===");
    for (let j = start; j < end; j++) {
      console.log("L" + (j+1) + ": " + JSON.stringify(lines[j]));
    }
    break;
  }
}

// Now preprocess the whole thing
const preprocessed = preprocessLuau(raw);

// Find the same section in preprocessed output
const ppLines = preprocessed.split("\n");
for (let i = 0; i < ppLines.length; i++) {
  if (ppLines[i].includes("queue_on_teleport") || ppLines[i].includes("aurorax.site")) {
    const start = Math.max(0, i - 1);
    const end = Math.min(ppLines.length, i + 4);
    console.log("\n=== PREPROCESSED (lines " + (start+1) + "-" + end + ") ===");
    for (let j = start; j < end; j++) {
      console.log("L" + (j+1) + ": " + JSON.stringify(ppLines[j]));
    }
    break;
  }
}

// Check if :// survived
const hasColonSlash = preprocessed.includes("://");
console.log("\n:// present in output:", hasColonSlash);
if (!hasColonSlash) {
  const idx = preprocessed.indexOf("aurorax.site");
  if (idx >= 0) {
    console.log("Context around aurorax.site:", JSON.stringify(preprocessed.substring(idx - 15, idx + 50)));
  }
}
