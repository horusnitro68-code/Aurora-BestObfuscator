import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

const source = `local base = {x = 10}
local t = {}
setmetatable(t, {__index = base})
print(t.x)

t.y = 99
print(t.y)

local mt = getmetatable(t)
print(mt.__index.x)`;

console.log("=== Metatables test ===");
const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);

lauxlib.luaL_dostring(L, to_luastring(`
  __capture = {}
  function print(...)
    local args = {...}
    local s = {}
    for i = 1, #args do s[i] = tostring(args[i]) end
    table.insert(__capture, table.concat(s, "\t"))
  end
`));

const status = lauxlib.luaL_dostring(L, to_luastring(result.output));
if (status !== lua.LUA_OK) {
  const err = lua.lua_tostring(L, -1);
  console.log("Error:", err ? to_jsstring(err) : `Lua error ${status}`);
  process.exit(1);
}

lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
const out = lua.lua_tostring(L, -1);
console.log("Output:\n", out ? to_jsstring(out) : "(empty)");
