import { tryCompileToVM } from "../src/lib/vmObfuscator";

const source = `local x = 10
print("greater")
print("less")`;

const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

const keyMatch = result.output.match(/local _K=\{([^}]+)\}/);
const dataMatch = result.output.match(/local _D=\{([^}]+)\}/);

if (!keyMatch || !dataMatch) {
  console.log("Could not extract key/data");
  process.exit(1);
}

const key = keyMatch[1].split(",").map(Number);
const data = dataMatch[1].split(",").map(Number);

for (let i = 0; i < data.length; i++) {
  data[i] ^= key[i % key.length];
}

let pos = 0;
function read() {
  return data[pos++];
}

console.log("Raw decoded bytes:", data.slice(0, 50));

const l = read();
const numConsts = read();
console.log("locals count:", l, "num consts:", numConsts);

const constants: unknown[] = [];
for (let i = 0; i < numConsts; i++) {
  const type = read();
  console.log(`constant ${i} type ${type} at pos ${pos}`);
  if (type === 0) constants.push(null);
  else if (type === 1) constants.push(read() === 1);
  else if (type === 2) {
    const len = read();
    let s = "";
    for (let j = 0; j < len; j++) s += String.fromCharCode(read());
    constants.push(Number(s));
  } else if (type === 3) {
    const len = read();
    let s = "";
    for (let j = 0; j < len; j++) s += String.fromCharCode(read());
    constants.push(s);
  }
}

console.log("Constants decoded:", constants);
