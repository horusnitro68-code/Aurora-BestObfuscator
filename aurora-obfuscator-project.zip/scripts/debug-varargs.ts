import { obfuscateLua } from "../src/lib/luaObfuscator";

const code = `function f(...) return ... end\nprint(f(1,2,3))`;
const obfuscated = obfuscateLua(code);
console.log("Used VM:", obfuscated.includes("Aurora X VM v4.0"));
console.log("Output length:", obfuscated.length);
console.log("\n--- Generated output ---\n");
console.log(obfuscated);
