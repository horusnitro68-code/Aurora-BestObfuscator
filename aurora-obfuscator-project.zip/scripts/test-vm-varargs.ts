import { obfuscateLua } from "../src/lib/luaObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

function runLua(code: string): { output: string; error?: string } {
  const L = lauxlib.luaL_newstate();
  lualib.luaL_openlibs(L);

  let captured = "";
  lauxlib.luaL_dostring(L, to_luastring(`
    __capture = {}
    local _p = print
    function print(...)
      local args = {...}
      local s = {}
      for i = 1, #args do
        s[i] = tostring(args[i])
      end
      table.insert(__capture, table.concat(s, "\t"))
    end
  `));

  const status = lauxlib.luaL_dostring(L, to_luastring(code));
  if (status !== lua.LUA_OK) {
    const err = lua.lua_tostring(L, -1);
    return { output: captured, error: err ? to_jsstring(err) : `Lua error ${status}` };
  }

  const getResult = lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
  const result = lua.lua_tostring(L, -1);
  return {
    output: result ? to_jsstring(result) : "",
    error: undefined,
  };
}

const cases = [
  {
    name: "varargs basic",
    code: `function f(...) return ... end\nprint(f(1,2,3))`,
    expected: "1",
  },
  {
    name: "varargs in call",
    code: `function f(...) print(...) end\nf(10,20,30)`,
    expected: "10\t20\t30",
  },
  {
    name: "select vararg",
    code: `function f(...) return select(2, ...) end\nprint(f(1,2,3))`,
    expected: "2",
  },
];

for (const c of cases) {
  console.log(`\n=== ${c.name} ===`);
  let obfuscated: string;
  try {
    obfuscated = obfuscateLua(c.code);
  } catch (err) {
    console.log(`Obfuscation failed: ${err instanceof Error ? err.message : err}`);
    continue;
  }
  const usedVM = obfuscated.includes("Aurora X VM v4.0");
  console.log(`Used real VM: ${usedVM}`);
  if (!usedVM) {
    console.log("VM did not handle script");
    continue;
  }
  const orig = runLua(c.code);
  const obf = runLua(obfuscated);
  console.log("Original output:", orig.output);
  if (orig.error) console.log("Original error:", orig.error);
  console.log("Obfuscated output:", obf.output);
  if (obf.error) console.log("Obfuscated error:", obf.error);
  console.log(orig.output === obf.output && !obf.error ? "✅ Match" : "❌ Mismatch");
}
