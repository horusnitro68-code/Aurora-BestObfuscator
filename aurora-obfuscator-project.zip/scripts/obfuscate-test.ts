import { obfuscateLua } from "../src/lib/luaObfuscator";
import fs from "fs";

const source = fs.readFileSync("/tmp/aroraxilove.lua.txt", "utf-8");
console.log("Source size:", source.length, "bytes");

const start = Date.now();
try {
  const result = obfuscateLua(source, {
    watermark: "Aurora X Obfuscator",
    controlFlow: true,
    keyLength: 32,
    chunkSize: 4096,
    advancedOpcodes: true,
    antiDebug: true,
    botProtection: true,
  });
  const elapsed = Date.now() - start;
  fs.writeFileSync("/tmp/aroraxilove.obfuscated.lua", result);
  console.log("Obfuscated in", elapsed, "ms");
  console.log("Output size:", result.length, "bytes");
  console.log("First 200 chars:");
  console.log(result.slice(0, 200));
} catch (err) {
  console.error("Obfuscation failed:", err);
  process.exit(1);
}
