#!/usr/bin/env bun
/**
 * Dump bytecode instructions around a specific PC to debug compiler bugs.
 * Usage: bun run scripts/dump-bytecode.ts
 * 
 * Patches the compiler to dump instruction at pc=4901 from the root proto
 * of the Blox Fruit script.
 */

// First, let's monkey-patch the vmObfuscator source to capture the ctx
import * as fs from 'fs';

// Read the original source
const origSrc = fs.readFileSync('src/lib/vmObfuscator.ts', 'utf-8');

// Inject a debug hook before the return statement
// Find:   return { success: true, output };
// Insert debug dump before it
const debugHook = `
  // DEBUG: Dump instructions around pc=4901 from root proto
  if (ctx && ctx.proto) {
    const rootProto = ctx.proto;
    const pc = 4901;
    const start = Math.max(0, pc - 10);
    const end = Math.min(rootProto.code.length, pc + 10);
    console.error('===== BYTECODE DUMP around pc=' + pc + ' =====');
    console.error('Root proto code length:', rootProto.code.length);
    console.error('Root proto constants:', rootProto.constants.length);
    console.error('Root proto globalNames:', JSON.stringify(rootProto.globalNames?.slice(0, 100)));
    console.error('Root proto child protos:', rootProto.protos.length);
    console.error('');
    console.error('Instructions:');
    for (let i = start; i < end; i++) {
      if (i >= 0 && i < rootProto.code.length) {
        const ins = rootProto.code[i];
        const opName = Object.entries(OpCode).find(([k, v]) => v === (opcodeMap ? opcodeMap.indexOf(ins.op) : ins.op))?.[0] || 'UNKNOWN';
        const aStr = opName === 'CALL' || opName === 'CALLM' ? 'nArgs=' + ins.a : 
                     opName === 'PUSH_K' ? 'const[' + ins.a + ']' :
                     opName === 'GET_GLOBAL' ? 'global[' + ins.a + ']="' + (rootProto.globalNames?.[ins.a] || 'UNKNOWN') + '"' :
                     opName === 'SET_GLOBAL' ? 'global[' + ins.a + ']="' + (rootProto.globalNames?.[ins.a] || 'UNKNOWN') + '"' :
                     'a=' + ins.a;
        const bStr = opName === 'JMP' || opName === 'JMP_IF' || opName === 'JMP_IF_NOT' || opName === 'PEEK_JMP_IF' || opName === 'PEEK_JMP_IF_NOT' ? '->pc=' + ins.b :
                     opName === 'CALL' || opName === 'CALLM' ? 'flags=' + ins.b :
                     'b=' + ins.b;
        const marker = i + 1 === pc ? ' <-- HERE' : '';
        console.error('  [' + (i + 1) + '] ' + opName.padEnd(16) + aStr.padEnd(30) + bStr + marker);
      }
    }
    console.error('');
    // Also dump constants referenced at pc+0, pc-1, pc-2
    for (let offset = -2; offset <= 0; offset++) {
      const absPc = pc + offset - 1; // 0-indexed
      if (absPc >= 0 && absPc < rootProto.code.length) {
        const ins = rootProto.code[absPc];
        if (ins.op === opcodeMap[OpCode.PUSH_K]) {
          const constIdx = ins.a;
          const c = rootProto.constants[constIdx];
          if (c) {
            console.error('  const[' + constIdx + '] at pc=' + (absPc + 1) + ': type=' + c.type + ' value=' + JSON.stringify(c.value));
          }
        }
      }
    }
    console.error('===== END DUMP =====');
  }
`;

// Insert debug hook before the return statement
const patched = origSrc.replace(
  '  return { success: true, output };',
  debugHook + '\n  return { success: true, output };'
);

// Write patched source
fs.writeFileSync('src/lib/vmObfuscator.ts', patched);
console.error('Patched vmObfuscator.ts with debug hook');

// Now import and compile
const { tryCompileToVM } = await import('../src/lib/vmObfuscator');
const src = fs.readFileSync('/tmp/segurity-embedded.lua.txt', 'utf-8');
const result = tryCompileToVM(src);

// Restore original source
fs.writeFileSync('src/lib/vmObfuscator.ts', origSrc);

if (!result.success) {
  console.error('FAIL:', result.error);
  process.exit(1);
}
console.error('Compilation succeeded, output size:', result.output.length);
