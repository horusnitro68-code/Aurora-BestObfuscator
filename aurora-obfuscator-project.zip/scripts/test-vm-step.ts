import { obfuscateLua } from "../src/lib/luaObfuscator";
import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

function runLua(name: string, code: string): { output: string; error?: string } {
  const L = lauxlib.luaL_newstate();
  lualib.luaL_openlibs(L);

  let captured = "";
  lauxlib.luaL_dostring(L, to_luastring(`
    __capture = {}
    function print(...)
      local args = {...}
      local s = {}
      for i = 1, #args do s[i] = tostring(args[i]) end
      table.insert(__capture, table.concat(s, "\t"))
    end
  `));

  const status = lauxlib.luaL_dostring(L, to_luastring(code));
  if (status !== lua.LUA_OK) {
    const err = lua.lua_tostring(L, -1);
    return { output: captured, error: err ? to_jsstring(err) : `Lua error ${status}` };
  }

  lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
  const result = lua.lua_tostring(L, -1);
  return {
    output: result ? to_jsstring(result) : "",
    error: undefined,
  };
}

function testScript(name: string, source: string) {
  console.log(`\n=== ${name} ===`);
  console.log(`Input size: ${source.length} bytes`);

  const original = runLua("original", source);
  if (original.error) {
    console.log(`Original script error: ${original.error}`);
    return;
  }
  console.log(`Original output:\n${original.output || "(empty)"}`);

  const vmResult = tryCompileToVM(source);
  if (!vmResult.success) {
    console.log(`VM compilation failed: ${vmResult.error}`);
    return;
  }

  const obfuscated = vmResult.output;
  const usedVM = obfuscated.includes("Aurora X VM v4.0");
  console.log(`Used real VM: ${usedVM}`);
  console.log(`Output size: ${obfuscated.length} bytes`);

  const obfResult = runLua("obfuscated", obfuscated);
  if (obfResult.error) {
    console.log(`Obfuscated execution error: ${obfResult.error}`);
    return;
  }
  console.log(`Obfuscated output:\n${obfResult.output || "(empty)"}`);

  if (original.output === obfResult.output) {
    console.log("✅ Outputs match");
  } else {
    console.log("❌ Outputs differ");
  }
}

const tests = {
  hello: `print("hello")`,
  arithmetic: `local a = 5
local b = 3
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a % b)
print(a ^ b)`,
  logic: `local x = 10
if x > 5 then
  print("greater")
else
  print("less")
end
if x <= 10 then
  print("ok")
end`,
  functions: `function double(n)
  return n * 2
end
print(double(7))`,
  loops: `local s = 0
for i = 1, 5 do
  s = s + i
end
print(s)`,
};

for (const [name, source] of Object.entries(tests)) {
  testScript(name, source);
}
