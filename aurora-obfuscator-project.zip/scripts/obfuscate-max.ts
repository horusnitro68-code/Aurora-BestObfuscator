/**
 * Ofusca un script con protección MÁXIMA: VM + Legacy (doble capa), antiDebug,
 * botProtection, controlFlow, keyLength máximo y chunks pequeños para máxima
 * fragmentación.
 * Uso: bun scripts/obfuscate-max.ts <input.lua> <output.lua>
 */
import { readFileSync, writeFileSync } from "node:fs";
import { obfuscateLua, type ObfuscationOptions } from "../src/lib/luaObfuscator.js";

const sourcePath = process.argv[2];
const outputPath = process.argv[3];
if (!sourcePath || !outputPath) {
  console.error("Uso: bun scripts/obfuscate-max.ts <input.lua> <output.lua>");
  process.exit(1);
}

const source = readFileSync(sourcePath, "utf-8");
console.log(`📄 Source: ${sourcePath} (${(source.length / 1024).toFixed(1)} KB)`);

// ===== PROTECCIÓN MÁXIMA: TODAS las capas al máximo =====
const options: Partial<ObfuscationOptions> = {
  watermark: "Protected by Aurora X v4.0 - MAX SECURITY",
  doubleProtection: true, // ✅ VM + Legacy (dos capas que romper)
  controlFlow: true,      // ✅ ramas de código muerto + labels confusos
  antiDebug: true,        // ✅ anti-debug / anti-tamper
  botProtection: true,    // ✅ detección de hooks en load/loadstring
  keyLength: 256,         // ✅ clave XOR de 256 bytes
  chunkSize: 512,         // ✅ chunks pequeños = máxima fragmentación
  advancedOpcodes: true,  // ✅ opcodes CALL/RETURN/JUMP
};

console.log("🔒 Ofuscando con protección MÁXIMA (VM + Legacy)...");
const start = Date.now();
const result = obfuscateLua(source, options);
const elapsed = Date.now() - start;

writeFileSync(outputPath, result, "utf-8");
console.log(`✅ Ofuscado: ${outputPath} (${(result.length / 1024).toFixed(1)} KB) en ${(elapsed / 1000).toFixed(1)}s`);
console.log(`📏 Tamaño original: ${source.length} bytes → ofuscado: ${result.length} bytes (x${(result.length / Math.max(source.length, 1)).toFixed(1)})`);
