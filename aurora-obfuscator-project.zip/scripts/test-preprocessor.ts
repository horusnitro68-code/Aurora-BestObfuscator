import { preprocessLuau } from "../src/lib/luauPreprocessor";

const examples = [
  {
    name: "simple continue",
    input: `while true do
  if not _G.AutoFarm_Bone then continue end
  print("farming")
end`,
  },
  {
    name: "task.wait and typeof",
    input: `task.spawn(function()
  while task.wait() do
    if typeof(x) == "CFrame" then
      continue
    end
  end
end)`,
  },
  {
    name: "nested loops",
    input: `while true do
  while true do
    if x then continue end
  end
  if y then continue end
end`,
  },
];

for (const ex of examples) {
  console.log(`--- ${ex.name} ---`);
  console.log("INPUT:");
  console.log(ex.input);
  console.log("\nOUTPUT:");
  try {
    console.log(preprocessLuau(ex.input));
  } catch (err) {
    console.error("ERROR:", err);
  }
  console.log("\n");
}

// Minimal single test with safety
console.log("--- minimal ---");
console.log(preprocessLuau('while true do\n  if not x then continue end\n  print(1)\nend'));
