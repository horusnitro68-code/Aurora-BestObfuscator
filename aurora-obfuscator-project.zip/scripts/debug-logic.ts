import { tryCompileToVM } from "../src/lib/vmObfuscator";

const source = `local x = 10
if x > 5 then
  print("greater")
else
  print("less")
end
if x <= 10 then
  print("ok")
end`;

const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

console.log("=== Generated Lua ===");
console.log(result.output);
console.log("=== End ===");
