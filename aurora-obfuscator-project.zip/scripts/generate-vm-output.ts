/**
 * Generate VM-obfuscated output from bloxfruit_raw.lua
 * Run: npx tsx scripts/generate-vm-output.ts
 */

import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";
import { preprocessLuau } from "../src/lib/luauPreprocessor";
import { tryCompileToVM, VM_DEFAULT_OPTIONS } from "../src/lib/vmObfuscator";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PROJECT_ROOT = path.resolve(__dirname, "..");

const source = fs.readFileSync(
  path.join(PROJECT_ROOT, "public", "bloxfruit_raw.lua"),
  "utf-8"
);

const preprocessed = preprocessLuau(source);

const result = tryCompileToVM(preprocessed, {
  ...VM_DEFAULT_OPTIONS,
  watermark: "Aurora X Obfuscator",
});

if (result.success) {
  const outputPath = path.join(
    PROJECT_ROOT,
    "public",
    "aurora-bloxfruit-vm-final.lua"
  );
  fs.writeFileSync(outputPath, result.output, "utf-8");
  console.log(`✅ VM output generated: ${outputPath}`);
  console.log(`   Size: ${result.output.length} bytes`);
  console.log(`   Lines: ${result.output.split("\n").length}`);
} else {
  console.error("❌ VM compilation failed:", result.error);
}
