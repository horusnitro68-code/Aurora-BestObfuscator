/**
 * Script para ofuscar con Legacy puro (sin VM)
 * Uso: bun scripts/obfuscate-legacy.ts
 */
import { readFileSync, writeFileSync } from "node:fs";
import { legacyObfuscateLua, type ObfuscationOptions } from "../src/lib/luaObfuscator.js";

const sourcePath = process.argv[2] || "public/bloxfruit_raw.lua";
const outputPath = process.argv[3] || "public/aurora-bloxfruit-legacy-obfuscated.lua";

const source = readFileSync(sourcePath, "utf-8");
console.log(`📄 Source: ${sourcePath} (${(source.length / 1024).toFixed(1)} KB)`);

const options: Partial<ObfuscationOptions> = {
  watermark: "Protected by Aurora X v4.0",
  doubleProtection: false, // ⚠️ LEGACY ONLY, sin VM
  controlFlow: true,
  antiDebug: true,
  botProtection: true,
  keyLength: 32,
  chunkSize: 4096,
  advancedOpcodes: true,
};

console.log("🔒 Ofuscando con Legacy...");
const start = Date.now();
const result = legacyObfuscateLua(source, options);
const elapsed = Date.now() - start;

writeFileSync(outputPath, result, "utf-8");
console.log(`✅ Ofuscado: ${outputPath} (${(result.length / 1024).toFixed(1)} KB) en ${(elapsed / 1000).toFixed(1)}s`);
