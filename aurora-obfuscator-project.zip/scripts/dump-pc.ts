#!/usr/bin/env bun
/**
 * Dump bytecode around pc=4901 from Blox Fruit compilation.
 * Expects vmObfuscator.ts to have been patched with __DEBUG_PROTO/__DEBUG_OPMAP.
 */

import { tryCompileToVM } from '../src/lib/vmObfuscator';
import * as fs from 'fs';

const OPCODE_NAMES = [
  'NOP','PUSH_K','PUSH_LOCAL','STORE_LOCAL','POP',
  'GET_GLOBAL','SET_GLOBAL','GET_TABLE','SET_TABLE','NEWTABLE',
  'ADD','SUB','MUL','DIV','MOD','POW','CONCAT',
  'UNM','NOT','LEN',
  'EQ','LT','LE',
  'JMP','JMP_IF','JMP_IF_NOT',
  'CALL','RETURN','CLOSURE','VARARGS','EXPAND_VARARGS',
  'CALLM','EXPAND_MULTIRET','PEEK_JMP_IF','PEEK_JMP_IF_NOT',
  'DUP','SWAP',
];

const OPCODE_COUNT = 37;

const src = fs.readFileSync('/tmp/segurity-embedded.lua.txt', 'utf8');
console.log(`Source: ${src.length.toLocaleString()} chars`);

console.log('Compiling...');
const start = Date.now();
const r = tryCompileToVM(src);
const elapsed = ((Date.now() - start) / 1000).toFixed(1);

if (!r.success) {
  console.log(`FAIL after ${elapsed}s: ${r.error}`);
  process.exit(1);
}
console.log(`OK in ${elapsed}s, output: ${r.output.length.toLocaleString()} chars`);

// Access captured debug globals
const proto = (globalThis as any).__DEBUG_PROTO;
const opcodeMap = (globalThis as any).__DEBUG_OPMAP;

if (!proto) {
  console.log('ERROR: __DEBUG_PROTO not set - monkey-patch failed');
  process.exit(1);
}

// Build reverse opcode map: reverseMap[shuffled] = original
const reverseMap: number[] = new Array(OPCODE_COUNT);
for (let i = 0; i < OPCODE_COUNT; i++) {
  reverseMap[opcodeMap[i]] = i;
}

const code = proto.code;
const globalNames = proto.globalNames || [];
const constants = proto.constants || [];
const locals = proto.locals || [];

console.log(`\nRoot proto: ${code.length} instructions, ${constants.length} constants, ${globalNames.length} global names`);

// Dump around pc=4901
const TARGET = 4901; // 1-based pc
const START = Math.max(0, TARGET - 15);
const END = Math.min(code.length, TARGET + 6);

console.log(`\n=== Instructions around pc=${TARGET} ===`);
console.log(`Index   Raw Decoded  Op              a     b     Detail`);
console.log('─'.repeat(75));

for (let i = START; i < END; i++) {
  const ins = code[i];
  const pc = i + 1;
  const shuffled = ins.op;
  const decoded = reverseMap[shuffled] !== undefined ? reverseMap[shuffled] : shuffled;
  const opName = OPCODE_NAMES[decoded] || `UNK${decoded}`;
  const marker = pc === TARGET ? ' ◄── CALL FAILS HERE' : '';
  
  let detail = '';
  if (decoded === 5 || decoded === 6) {
    const gnName = globalNames[ins.a] !== undefined ? globalNames[ins.a] : `(idx=${ins.a})`;
    detail = `gn="${gnName}"`;
  } else if (decoded === 1) {
    const c = constants[ins.a];
    if (c) {
      let val = typeof c.value === 'string' ? JSON.stringify(c.value.substring(0, 30)) : String(c.value);
      if (val.length > 35) val = val.substring(0, 35) + '...';
      detail = `const=${val}`;
    }
  } else if (decoded === 26 || decoded === 31) {
    detail = `nArgs=${ins.a} flags=${ins.b}`;
  } else if ([23,24,25,33,34].includes(decoded)) {
    detail = `target=${ins.b}`;
  } else if (decoded === 2 || decoded === 3) {
    detail = `local[${ins.a}]${ins.a < locals.length ? '=' + locals[ins.a] : ''}`;
  } else if (decoded === 7 || decoded === 8) {
    detail = 'gettable/settable';
  }
  
  console.log(`[${String(i).padStart(5)}] ${String(shuffled).padStart(3)} → ${String(decoded).padStart(4)} ${opName.padEnd(16)} a=${String(ins.a).padStart(4)} b=${String(ins.b).padStart(4)}  ${detail}${marker}`);
}

// Dump global names for reference
console.log(`\n=== Global Name Table (${globalNames.length} entries) ===`);
for (let i = 0; i < globalNames.length; i++) {
  if (globalNames[i].includes('sea') || globalNames[i].length < 7) {
    console.log(`  [${i}] ${globalNames[i]}`);
  }
}

// Show first few constants
console.log(`\n=== First 20 Constants ===`);
for (let i = 0; i < Math.min(constants.length, 20); i++) {
  const c = constants[i];
  let val = typeof c.value === 'string' ? JSON.stringify(c.value.substring(0, 40)) : String(c.value);
  if (val.length > 42) val = val.substring(0, 42) + '...';
  console.log(`  [${i}] ${c.type}: ${val}`);
}

// Clean up debug globals
delete (globalThis as any).__DEBUG_PROTO;
delete (globalThis as any).__DEBUG_OPMAP;

// Restore original file
console.log('\nRestoring original vmObfuscator.ts...');
const origSv = fs.readFileSync('src/lib/vmObfuscator.ts', 'utf8');
const restored = origSv.replace(
  'const __DEBUG_PROTO = ctx.proto;\n  const __DEBUG_OPMAP = opcodeMap;\n  ',
  ''
);
fs.writeFileSync('src/lib/vmObfuscator.ts', restored);
console.log('Done.');
