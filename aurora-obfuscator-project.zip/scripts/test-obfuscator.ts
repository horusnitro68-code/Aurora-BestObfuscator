import { obfuscateLua } from "../src/lib/luaObfuscator";

function generateLuaScript(targetBytes: number): string {
  const lines: string[] = [
    "-- Generated test script for Aurora X",
    "local results = {}",
  ];
  let currentSize = lines.join("\n").length + 1;
  let i = 0;

  while (currentSize < targetBytes) {
    const line = `results[${i}] = ${i} * ${i} -- ${Math.random().toString(36).slice(2)}`;
    lines.push(line);
    currentSize += line.length + 1;
    i++;
  }

  lines.push("return results");
  return lines.join("\n");
}

function runTest(name: string, size: number) {
  console.log(`\n[${name}] Generating ${size / 1024} KB script...`);
  const source = generateLuaScript(size);
  console.log(`[${name}] Source size: ${(source.length / 1024).toFixed(1)} KB`);

  const start = performance.now();
  const output = obfuscateLua(source);
  const elapsed = performance.now() - start;

  console.log(`[${name}] Output size: ${(output.length / 1024).toFixed(1)} KB`);
  console.log(`[${name}] Time: ${elapsed.toFixed(1)} ms`);
  console.log(`[${name}] First 120 chars: ${output.slice(0, 120)}`);

  if (output.length < 100) {
    throw new Error("Output too short");
  }
  if (!output.includes("Aurora X")) {
    throw new Error("Watermark missing");
  }
  if (!output.includes("local _")) {
    throw new Error("Generated Lua structure missing");
  }
}

const tests = [1, 50, 100, 300, 600].map((kb) => kb * 1024);

for (const size of tests) {
  runTest(`${size / 1024}KB`, size);
}

console.log("\nAll tests passed!");
