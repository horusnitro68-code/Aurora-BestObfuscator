import { tryCompileToVM } from "../src/lib/vmObfuscator";

const source = `print("hello")`;

const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

console.log("=== Generated Lua ===");
console.log(result.output);
console.log("=== End ===");
