import * as luaparse from "luaparse";

const source = `print("greater")`;

const ast = luaparse.parse(source, { scope: true, locations: false, comments: false });

function findStringLiterals(node: any): any[] {
  const results: any[] = [];
  function walk(n: any) {
    if (!n) return;
    if (n.type === "StringLiteral") {
      results.push(n);
    }
    for (const key in n) {
      const child = n[key];
      if (Array.isArray(child)) {
        child.forEach(walk);
      } else if (typeof child === "object" && child !== null) {
        walk(child);
      }
    }
  }
  walk(ast);
  return results;
}

const strings = findStringLiterals(ast);
console.log("Found StringLiterals:", strings.length);
strings.forEach((s, i) => {
  console.log(`StringLiteral ${i}:`, JSON.stringify(s, null, 2));
});
