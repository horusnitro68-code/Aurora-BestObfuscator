import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

const testName = process.argv[2] || "hello";

const tests: Record<string, string> = {
  hello: `print("hello")`,
  arithmetic: `local a = 5
local b = 3
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a % b)
print(a ^ b)`,
  logic: `local x = 10
if x > 5 then
  print("greater")
else
  print("less")
end
if x <= 10 then
  print("ok")
end`,
  functions: `function double(n)
  return n * 2
end
print(double(7))`,
  loops: `local s = 0
for i = 1, 5 do
  s = s + i
end
print(s)`,
  tables: `local t = {a = 1, b = 2}
print(t.a)
print(t.b)
t.c = 3
print(t.c)
local arr = {10, 20, 30}
print(#arr)
print(arr[1])`,
};

const source = tests[testName];
if (!source) {
  console.log("Unknown test:", testName);
  console.log("Available:", Object.keys(tests).join(", "));
  process.exit(1);
}

console.log(`=== ${testName} ===`);
console.log(`Input:\n${source}\n`);

console.log("Compiling...");
const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}
console.log(`Output size: ${result.output.length}`);

const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);

lauxlib.luaL_dostring(L, to_luastring(`
  __capture = {}
  function print(...)
    local args = {...}
    local s = {}
    for i = 1, #args do s[i] = tostring(args[i]) end
    table.insert(__capture, table.concat(s, "\t"))
  end
`));

console.log("Running...");
const status = lauxlib.luaL_dostring(L, to_luastring(result.output));
if (status !== lua.LUA_OK) {
  const err = lua.lua_tostring(L, -1);
  console.log("Error:", err ? to_jsstring(err) : `Lua error ${status}`);
  process.exit(1);
}

lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
const out = lua.lua_tostring(L, -1);
console.log("Output:", out ? to_jsstring(out) : "(empty)");
