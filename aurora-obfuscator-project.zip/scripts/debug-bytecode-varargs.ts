import { obfuscateLuaVM } from "../src/lib/vmObfuscator";

const code = `function f(...) return ... end\nprint(f(1,2,3))`;
const result = obfuscateLuaVM(code);
if (!result.usedVM) {
  console.log("VM not used");
  process.exit(0);
}

// Extract key and data from the output using regex
const keyMatch = result.output.match(/local _K=\{([^}]+)\}/);
const dataMatch = result.output.match(/local _D=\{([^}]+)\}/);
if (!keyMatch || !dataMatch) {
  console.log("Could not extract key/data");
  process.exit(1);
}

const key = keyMatch[1].split(",").map((s) => parseInt(s.trim(), 10));
const data = dataMatch[1].split(",").map((s) => parseInt(s.trim(), 10));

// XOR decrypt
const decrypted = data.map((b, i) => b ^ key[i % key.length]);

let idx = 0;
function next(): number {
  return decrypted[idx++];
}

const opNames: Record<number, string> = {
  0: "NOP", 1: "PUSH_K", 2: "PUSH_LOCAL", 3: "STORE_LOCAL", 4: "POP",
  5: "GET_GLOBAL", 6: "SET_GLOBAL", 7: "GET_TABLE", 8: "SET_TABLE", 9: "NEWTABLE",
  10: "ADD", 11: "SUB", 12: "MUL", 13: "DIV", 14: "MOD", 15: "POW", 16: "CONCAT",
  17: "UNM", 18: "NOT", 19: "LEN", 20: "EQ", 21: "LT", 22: "LE", 23: "JMP",
  24: "JMP_IF", 25: "JMP_IF_NOT", 26: "CALL", 27: "RETURN", 28: "CLOSURE",
  29: "VARARGS", 30: "EXPAND_VARARGS",
};

function decodeProto(depth = 0): any {
  const n = next();
  const v = next();
  const nc = next();
  const constants: any[] = [];
  for (let i = 0; i < nc; i++) {
    const t = next();
    if (t === 0) {
      constants.push({ type: "nil" });
    } else if (t === 1) {
      constants.push({ type: "boolean", value: next() === 1 });
    } else if (t === 2) {
      const len = next();
      const s: number[] = [];
      for (let j = 0; j < len; j++) s.push(next());
      constants.push({ type: "number", value: parseFloat(s.map((b) => String.fromCharCode(b)).join("")) });
    } else if (t === 3) {
      const len = next();
      const s: number[] = [];
      for (let j = 0; j < len; j++) s.push(next());
      constants.push({ type: "string", value: s.map((b) => String.fromCharCode(b)).join("") });
    }
  }
  const ni = next();
  const instructions: any[] = [];
  for (let i = 0; i < ni; i++) {
    const op = next();
    const a = next();
    const b = next();
    instructions.push({ op, a, b, name: opNames[op] || `OP${op}` });
  }
  const np = next();
  const protos: any[] = [];
  for (let i = 0; i < np; i++) {
    protos.push(decodeProto(depth + 1));
  }
  return { n, v, constants, instructions, protos };
}

const proto = decodeProto();
console.log(JSON.stringify(proto, null, 2));
