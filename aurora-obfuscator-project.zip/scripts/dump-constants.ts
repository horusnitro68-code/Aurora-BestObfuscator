import * as fs from 'fs';

const origSrc = fs.readFileSync('src/lib/vmObfuscator.ts', 'utf-8');
const marker = 'return { success: true, output };';

const debugHook = `
  // DEBUG: Dump constants
  if (ctx && ctx.proto) {
    const targets = [1498, 1540, 1541, 1542];
    console.error('===== CONSTANTS =====');
    for (const idx of targets) {
      const c = ctx.proto.constants[idx];
      if (c) {
        console.error('const[' + idx + ']:', JSON.stringify(c));
      } else {
        console.error('const[' + idx + ']: UNDEFINED');
      }
    }
    console.error('===== END CONSTANTS =====');
  }
`;

const patched = origSrc.replace(marker, debugHook + '\n' + marker);
fs.writeFileSync('src/lib/vmObfuscator.ts', patched);
console.error('Patched');

// Import and compile
const { tryCompileToVM } = await import('../src/lib/vmObfuscator');
const src = fs.readFileSync('/tmp/segurity-embedded.lua.txt', 'utf-8');
const r = tryCompileToVM(src);

// Restore
fs.writeFileSync('src/lib/vmObfuscator.ts', origSrc);
console.error('Restored. Done:', r.output.length);
