import { tryCompileToVM } from "../src/lib/vmObfuscator";

const source = `local t = {a = 1, b = 2}
print(t.a)
print(t.b)
t.c = 3
print(t.c)
local arr = {10, 20, 30}
print(#arr)
print(arr[1])`;

const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

const keyMatch = result.output.match(/local _K=\{([^}]+)\}/);
const dataMatch = result.output.match(/local _D=\{([^}]+)\}/);

if (!keyMatch || !dataMatch) {
  console.log("Could not extract key/data");
  process.exit(1);
}

const key = keyMatch[1].split(",").map(Number);
const data = dataMatch[1].split(",").map(Number);

for (let i = 0; i < data.length; i++) {
  data[i] ^= key[i % key.length];
}

let pos = 0;
function read() {
  return data[pos++];
}

const opNames: Record<number, string> = {
  0: "NOP", 1: "PUSH_K", 2: "PUSH_LOCAL", 3: "STORE_LOCAL", 4: "POP",
  5: "GET_GLOBAL", 6: "SET_GLOBAL", 7: "GET_TABLE", 8: "SET_TABLE", 9: "NEWTABLE",
  10: "ADD", 11: "SUB", 12: "MUL", 13: "DIV", 14: "MOD", 15: "POW", 16: "CONCAT",
  17: "UNM", 18: "NOT", 19: "LEN", 20: "EQ", 21: "LT", 22: "LE",
  23: "JMP", 24: "JMP_IF", 25: "JMP_IF_NOT", 26: "CALL", 27: "RETURN", 28: "CLOSURE", 29: "VARARGS",
};

function decodeProto(depth = 0) {
  const l = read();
  const numConsts = read();
  const constants: unknown[] = [];
  for (let i = 0; i < numConsts; i++) {
    const type = read();
    if (type === 0) constants.push(null);
    else if (type === 1) constants.push(read() === 1);
    else if (type === 2) {
      const len = read();
      let s = "";
      for (let j = 0; j < len; j++) s += String.fromCharCode(read());
      constants.push(Number(s));
    } else if (type === 3) {
      const len = read();
      let s = "";
      for (let j = 0; j < len; j++) s += String.fromCharCode(read());
      constants.push(s);
    }
  }

  const numInstr = read();
  const instructions: { op: number; a: number; b: number }[] = [];
  for (let i = 0; i < numInstr; i++) {
    instructions.push({ op: read(), a: read(), b: read() });
  }

  const numProtos = read();
  for (let i = 0; i < numProtos; i++) decodeProto(depth + 1);

  return { l, constants, instructions };
}

const proto = decodeProto();

console.log("Constants:");
proto.constants.forEach((c, i) => console.log(`  [${i}] = ${JSON.stringify(c)}`));

console.log("\nInstructions:");
proto.instructions.forEach((ins, i) => {
  console.log(`  [${i + 1}] ${opNames[ins.op] || "?"} ${ins.a} ${ins.b}`);
});
