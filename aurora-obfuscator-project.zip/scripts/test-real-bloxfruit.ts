import { obfuscateLua } from "../src/lib/luaObfuscator";
import { obfuscateLuaVM, VM_DEFAULT_OPTIONS } from "../src/lib/vmObfuscator";
import { preprocessLuau } from "../src/lib/luauPreprocessor";
import * as fs from "fs";
import * as luaparse from "luaparse";

const source = fs.readFileSync("/tmp/segurity.lua.txt", "utf8");
console.log("Original size:", source.length);

// Step 1: preprocess
const preprocessed = preprocessLuau(source);
console.log("Preprocessed size:", preprocessed.length);
fs.writeFileSync("/tmp/segurity.preprocessed.lua.txt", preprocessed);

// Step 2: verify Lua 5.1 syntax
try {
  luaparse.parse(preprocessed, { luaVersion: '5.2', scope: true, locations: false, comments: false });
  console.log("Preprocessed script parses as Lua 5.2 ✅");
} catch (err) {
  console.error("Preprocessed script fails Lua 5.1 parse:", err);
  process.exit(1);
}

// Step 3: try VM obfuscator directly to see if VM is used
console.log("Trying VM obfuscator...");
const vmResult = obfuscateLuaVM(source, VM_DEFAULT_OPTIONS);
if (vmResult.usedVM) {
  console.log("VM obfuscation succeeded ✅");
  console.log("VM output size:", vmResult.output.length);
  fs.writeFileSync("/tmp/segurity.obfuscated.lua.txt", vmResult.output);
  // Extract loader line (look for loadstring(game:HttpGet(...)) or similar)
  const loaderMatch = vmResult.output.match(/loadstring\(game:HttpGet\([^)]+\)\)/);
  if (loaderMatch) {
    console.log("Loader found:", loaderMatch[0]);
  } else {
    console.log("No standard loader line found in output");
  }
} else {
  console.log("VM obfuscation failed, fallback to legacy.");
  console.log("VM error:", vmResult.error);
  const output = obfuscateLua(preprocessed, VM_DEFAULT_OPTIONS);
  fs.writeFileSync("/tmp/segurity.obfuscated.lua.txt", output);
  console.log("Legacy output size:", output.length);
}
