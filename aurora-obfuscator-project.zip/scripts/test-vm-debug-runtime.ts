import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

const source = `local x = 10
if x > 5 then
  print("greater")
else
  print("less")
end
if x <= 10 then
  print("ok")
end`;

const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

// Inject debug print into the runtime by replacing the while loop guard
const patched = result.output.replace(
  "while true do\n    local _i=_C[_pc]",
  "while true do\n    print('PC:', _pc, 'MAX:', #_C)\n    if _pc > #_C or _pc < 1 then error('PC out of bounds: ' .. _pc) end\n    local _i=_C[_pc]"
);

const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);

lauxlib.luaL_dostring(L, to_luastring(`
  __capture = {}
  function print(...)
    local args = {...}
    local s = {}
    for i = 1, #args do s[i] = tostring(args[i]) end
    table.insert(__capture, table.concat(s, "\t"))
  end
`));

console.log("Running with debug PC...");
const status = lauxlib.luaL_dostring(L, to_luastring(patched));
if (status !== lua.LUA_OK) {
  const err = lua.lua_tostring(L, -1);
  console.log("Error:", err ? to_jsstring(err) : `Lua error ${status}`);
  process.exit(1);
}

lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
const out = lua.lua_tostring(L, -1);
console.log("Output:", out ? to_jsstring(out) : "(empty)");
