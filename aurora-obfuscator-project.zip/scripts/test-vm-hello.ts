import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

const source = `print("hello")`;

console.log("Compiling...");
const result = tryCompileToVM(source);
if (!result.success) {
  console.log("Compilation failed:", result.error);
  process.exit(1);
}

console.log("Compiled. Output size:", result.output.length);
console.log("Running in fengari...");

const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);

let captured: string[] = [];
lauxlib.luaL_dostring(L, to_luastring(`
  __capture = {}
  function print(...)
    local args = {...}
    local s = {}
    for i = 1, #args do s[i] = tostring(args[i]) end
    table.insert(__capture, table.concat(s, "\t"))
  end
`));

const status = lauxlib.luaL_dostring(L, to_luastring(result.output));
if (status !== lua.LUA_OK) {
  const err = lua.lua_tostring(L, -1);
  console.log("Error:", err ? to_jsstring(err) : `Lua error ${status}`);
  process.exit(1);
}

lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
const out = lua.lua_tostring(L, -1);
console.log("Output:", out ? to_jsstring(out) : "(empty)");
