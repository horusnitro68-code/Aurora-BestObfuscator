import { obfuscateLua } from "../src/lib/luaObfuscator";
import { tryCompileToVM } from "../src/lib/vmObfuscator";
import * as fengari from "fengari";

const { lua, lauxlib, lualib, to_luastring, to_jsstring } = fengari as any;

function generateLargeScript(targetBytes: number): string {
  const lines: string[] = [];
  lines.push("local total = 0");
  lines.push("local data = {}")

  let currentBytes = 30;
  let i = 1;
  while (currentBytes < targetBytes) {
    const line = `data[${i}] = ${i} * ${i}; total = total + data[${i}]`;
    lines.push(line);
    currentBytes += line.length + 1;
    i++;
  }

  lines.push("print(total)");
  return lines.join("\n");
}

function runLua(code: string): { output: string; error?: string } {
  const L = lauxlib.luaL_newstate();
  lualib.luaL_openlibs(L);

  lauxlib.luaL_dostring(L, to_luastring(`
    __capture = {}
    function print(...)
      local args = {...}
      local s = {}
      for i = 1, #args do s[i] = tostring(args[i]) end
      table.insert(__capture, table.concat(s, "\t"))
    end
  `));

  const status = lauxlib.luaL_dostring(L, to_luastring(code));
  if (status !== lua.LUA_OK) {
    const err = lua.lua_tostring(L, -1);
    return { output: "", error: err ? to_jsstring(err) : `Lua error ${status}` };
  }

  lauxlib.luaL_dostring(L, to_luastring(`return table.concat(__capture, "\\n")`));
  const result = lua.lua_tostring(L, -1);
  return { output: result ? to_jsstring(result) : "", error: undefined };
}

async function testLargeScript(targetBytes: number) {
  console.log(`\n=== Large script ${targetBytes / 1024}KB ===`);
  const source = generateLargeScript(targetBytes);
  console.log(`Generated source: ${source.length} bytes`);

  const startCompile = Date.now();
  const result = tryCompileToVM(source);
  const compileTime = Date.now() - startCompile;
  console.log(`Compile time: ${compileTime}ms`);

  if (!result.success) {
    console.log(`Compilation failed: ${result.error}`);
    return;
  }

  console.log(`Output size: ${result.output.length} bytes`);

  const original = runLua(source);
  if (original.error) {
    console.log(`Original error: ${original.error}`);
    return;
  }
  console.log(`Original output: ${original.output.slice(0, 100)}...`);

  const startRun = Date.now();
  const obf = runLua(result.output);
  const runTime = Date.now() - startRun;
  console.log(`Run time: ${runTime}ms`);

  if (obf.error) {
    console.log(`Obfuscated error: ${obf.error}`);
    return;
  }

  console.log(`Obfuscated output: ${obf.output.slice(0, 100)}...`);

  if (original.output === obf.output) {
    console.log(" ✅ Outputs match");
  } else {
    console.log(" ❌ Outputs differ");
  }
}

(async () => {
  await testLargeScript(400 * 1024);
  await testLargeScript(600 * 1024);
})();
