/**
 * Clyde-style AST transforms for Aurora X
 * 
 * Ported from Clyde Luau Obfuscator (sfr-development/Clyde-Luau-Obfuscator)
 * Provides:
 *  - Scope-aware variable renaming
 *  - Opaque predicates on conditions
 *  - String literal encryption
 *  - AST-to-Lua printer
 */

import * as luaparse from "luaparse";

// ============== AST TYPES (compatible with luaparse) ==============

type LUANode = luaparse.Node;
type LUAStatement = luaparse.Statement;
type LUAExpression = luaparse.Expression;

// ============== KEYWORD + GLOBAL PRESERVATION ==============

const KEYWORDS = new Set([
  "and", "break", "continue", "do", "else", "elseif", "end", "false",
  "for", "function", "goto", "if", "in", "local", "nil", "not", "or",
  "repeat", "return", "then", "true", "until", "while",
]);

const PRESERVED_GLOBALS = new Set([
  "_G", "game", "workspace", "script", "shared", "plugin",
  "Players", "Instance", "Vector3", "Vector2", "CFrame", "Color3",
  "UDim2", "UDim", "Ray", "BrickColor", "Enum", "Axes", "Faces",
  "math", "string", "table", "typeof", "pairs", "ipairs", "next",
  "print", "warn", "error", "assert", "tick", "wait", "spawn",
  "delay", "elapsedTime", "time", "typeof",
  "getfenv", "setfenv", "newproxy", "rawequal", "rawget", "rawset",
  "select", "tonumber", "tostring", "type", "unpack", "xpcall", "pcall",
  "loadstring", "load", "bit32", "coroutine", "debug", "io", "os",
  "getgenv", "getrawmetatable", "hookfunction", "checkcaller",
  "newcclosure", "identifyexecutor", "getexecutorname", "request",
  "http_request", "syn_request", "getgc", "getinstances", "getscripts",
  "cloneref", "compareinstances", "Drawing", "crypt", "buffer", "websocket",
  "syn", "fluxus", "KRNL_LOADED",
]);

// ============== SCOPE MANAGER FOR NAME MANGLING ==============

class ScopeManager {
  private stack: Map<string, string>[] = [new Map()];
  private nameCounter = 0;

  pushScope() {
    this.stack.push(new Map());
  }

  popScope() {
    this.stack.pop();
  }

  declare(name: string): string {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name) || KEYWORDS.has(name)) return name;
    if (PRESERVED_GLOBALS.has(name)) return name;

    const newName = this.generateUnique();
    const currentScope = this.stack[this.stack.length - 1];
    currentScope!.set(name, newName);
    return newName;
  }

  resolve(name: string): string {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name) || KEYWORDS.has(name)) return name;
    if (PRESERVED_GLOBALS.has(name)) return name;

    for (let i = this.stack.length - 1; i >= 0; i--) {
      const mapped = this.stack[i]!.get(name);
      if (mapped !== undefined) return mapped;
    }
    return name;
  }

  private generateUnique(): string {
    const chars = "abcdefghjkmnpqrstuvwxyz";
    let name: string;
    do {
      const idx = this.nameCounter++;
      name = "_" + chars[idx % chars.length] + Math.floor(idx / chars.length).toString(36);
    } while (KEYWORDS.has(name));
    return name;
  }
}

// ============== NAME MANGLING TRANSFORM ==============

function transformChunk(node: LUANode, scope: ScopeManager): LUANode {
  if (Array.isArray((node as any).body)) {
    (node as any).body = (node as any).body.map((s: LUANode) => transformStatement(s, scope));
  }
  return node;
}

function transformStatement(stmt: LUANode, scope: ScopeManager): LUANode {
  const type = (stmt as any).type;
  switch (type) {
    case "LocalStatement": {
      const s = stmt as any;
      s.vars = s.vars.map((v: any) => ({
        ...v,
        name: scope.declare(v.name),
      }));
      if (s.values) s.values = s.values.map((e: any) => transformExpression(e, scope));
      return s;
    }
    case "AssignmentStatement": {
      const s = stmt as any;
      s.vars = s.vars.map((v: any) => transformVar(v, scope));
      s.values = s.values.map((e: any) => transformExpression(e, scope));
      return s;
    }
    case "LocalFunction": // luaparse uses LocalStatement with FunctionExpression
    case "FunctionDeclaration": {
      const s = stmt as any;
      // Rename function name if it has one
      if (s.identifier) {
        s.identifier = scope.declare(s.identifier);
      }
      scope.pushScope();
      if (s.parameters) {
        s.parameters = s.parameters.map((p: any) =>
          typeof p === "string" ? scope.declare(p) : p
        );
      }
      if (s.body) {
        if (Array.isArray(s.body)) {
          s.body = s.body.map((b: any) => transformStatement(b, scope));
        }
      }
      scope.popScope();
      return s;
    }
    case "CallStatement": {
      const s = stmt as any;
      s.expression = transformExpression(s.expression, scope);
      return s;
    }
    case "IfStatement": {
      const s = stmt as any;
      s.condition = transformExpression(s.condition, scope);
      scope.pushScope();
      s.body = s.body.map((b: any) => transformStatement(b, scope));
      scope.popScope();
      if (s.elseifClauses) {
        s.elseifClauses = s.elseifClauses.map((c: any) => {
          c.condition = transformExpression(c.condition, scope);
          scope.pushScope();
          c.body = c.body.map((b: any) => transformStatement(b, scope));
          scope.popScope();
          return c;
        });
      }
      if (s.elseBody) {
        scope.pushScope();
        s.elseBody = s.elseBody.map((b: any) => transformStatement(b, scope));
        scope.popScope();
      }
      return s;
    }
    case "WhileStatement": {
      const s = stmt as any;
      s.condition = transformExpression(s.condition, scope);
      scope.pushScope();
      s.body = s.body.map((b: any) => transformStatement(b, scope));
      scope.popScope();
      return s;
    }
    case "RepeatStatement": {
      const s = stmt as any;
      scope.pushScope();
      s.body = s.body.map((b: any) => transformStatement(b, scope));
      scope.popScope();
      s.condition = transformExpression(s.condition, scope);
      return s;
    }
    case "ForNumericStatement": {
      const s = stmt as any;
      s.variable = scope.declare(s.variable);
      s.start = transformExpression(s.start, scope);
      s.end = transformExpression(s.end, scope);
      if (s.step) s.step = transformExpression(s.step, scope);
      scope.pushScope();
      s.body = s.body.map((b: any) => transformStatement(b, scope));
      scope.popScope();
      return s;
    }
    case "ForGenericStatement": {
      const s = stmt as any;
      s.variables = s.variables.map((v: string) => scope.declare(v));
      s.iterators = s.iterators.map((e: any) => transformExpression(e, scope));
      scope.pushScope();
      s.body = s.body.map((b: any) => transformStatement(b, scope));
      scope.popScope();
      return s;
    }
    case "ReturnStatement": {
      const s = stmt as any;
      if (s.arguments) {
        s.arguments = s.arguments.map((e: any) => transformExpression(e, scope));
      }
      return s;
    }
    case "DoStatement": {
      const s = stmt as any;
      scope.pushScope();
      s.body = s.body.map((b: any) => transformStatement(b, scope));
      scope.popScope();
      return s;
    }
    default:
      return stmt;
  }
}

function transformExpression(expr: any, scope: ScopeManager): any {
  if (!expr || typeof expr !== "object") return expr;

  switch (expr.type) {
    case "Identifier":
      return { ...expr, name: scope.resolve(expr.name) };
    case "MemberExpression":
      return { ...expr, base: transformExpression(expr.base, scope) };
    case "IndexExpression":
      return {
        ...expr,
        base: transformExpression(expr.base, scope),
        index: transformExpression(expr.index, scope),
      };
    case "CallExpression":
    case "StringCallExpression":
    case "TableCallExpression":
      return {
        ...expr,
        base: transformExpression(expr.base, scope),
        arguments: expr.arguments?.map((a: any) => transformExpression(a, scope)),
      };
    case "BinaryExpression":
    case "LogicalExpression":
      return {
        ...expr,
        left: transformExpression(expr.left, scope),
        right: transformExpression(expr.right, scope),
      };
    case "UnaryExpression":
      return { ...expr, argument: transformExpression(expr.argument, scope) };
    case "FunctionDeclaration":
      return transformFunctionExpression(expr, scope);
    case "TableConstructorExpression":
      return {
        ...expr,
        fields: expr.fields?.map((f: any) => ({
          ...f,
          value: transformExpression(f.value, scope),
          key: f.key ? transformExpression(f.key, scope) : undefined,
        })),
      };
    case "VarargLiteral":
    case "NilLiteral":
    case "BooleanLiteral":
    case "NumericLiteral":
    case "StringLiteral":
      return expr;
    default:
      return expr;
  }
}

function transformVar(v: any, scope: ScopeManager): any {
  if (!v || typeof v !== "object") return v;
  switch (v.type) {
    case "Identifier":
      return { ...v, name: scope.resolve(v.name) };
    case "MemberExpression":
      return { ...v, base: transformExpression(v.base, scope) };
    case "IndexExpression":
      return {
        ...v,
        base: transformExpression(v.base, scope),
        index: transformExpression(v.index, scope),
      };
    default:
      return v;
  }
}

function transformFunctionExpression(expr: any, scope: ScopeManager): any {
  if (expr.identifier) {
    expr.identifier = scope.declare(expr.identifier);
  }
  scope.pushScope();
  if (expr.parameters) {
    expr.parameters = expr.parameters.map((p: any) =>
      typeof p === "string" ? scope.declare(p) : p
    );
  }
  if (expr.body) {
    expr.body = expr.body.map((b: any) => transformStatement(b, scope));
  }
  scope.popScope();
  return expr;
}

// ============== OPAQUE PREDICATES ==============

const OPAQUE_PREDS: [number, string, number, number][] = [
  [7, "*", 7, 49],
  [1, "+", 1, 2],
  [15, "*", 15, 225],
  [100, "%", 7, 2],
  [12, "*", 12, 144],
  [3, "^", 2, 9],
  [5, "*", 5, 25],
  [2, "+", 3, 5],
  [10, "*", 10, 100],
];

function createOpaquePredicate(index: number): string {
  const [a, op, b, c] = OPAQUE_PREDS[index % OPAQUE_PREDS.length]!;
  return `(${a} ${op} ${b} == ${c})`;
}

function wrapExprWithOpaque(exprRaw: string, seed: number): string {
  return `(${createOpaquePredicate(seed)} and (${exprRaw}))`;
}

// ============== STRING ENCRYPTION ==============

function encodeString(str: string, key: number): number[] {
  return Array.from(str).map((c) => c.charCodeAt(0) ^ key);
}

function generateDecoderCode(decoderName: string, seed: number): string {
  return `local ${decoderName} = (function()
  local cache = {}
  return function(t, k)
    if cache[t] then return cache[t] end
    local s = {}
    for i = 1, #t do
      s[i] = string.char(bit32.bxor(t[i], k or ${seed}))
    end
    local r = table.concat(s)
    cache[t] = r
    return r
  end
end)()`;
}

function makeEncryptedString(str: string, key: number, decoderName: string): string {
  if (str.length === 0) return '""';
  const bytes = encodeString(str, key);
  const table = "{" + bytes.join(",") + "}";
  return `${decoderName}(${table})`;
}

// ============== AST PRINTER (from AST back to Lua) ==============

function printStatement(stmt: LUANode, indentLevel: number = 0): string {
  const ind = "  ".repeat(indentLevel);
  const type = (stmt as any).type;
  switch (type) {
    case "LocalStatement": {
      const s = stmt as any;
      const vars = (s.vars || []).map((v: any) => v.name || v).join(", ");
      let out = `local ${vars}`;
      if (s.init && s.init.length > 0) {
        out += " = " + s.init.map((e: any) => printExpression(e)).join(", ");
      }
      return ind + out;
    }
    case "AssignmentStatement": {
      const s = stmt as any;
      const vars = (s.variables || s.vars || []).map((v: any) => printVar(v)).join(", ");
      const vals = (s.init || s.values || []).map((e: any) => printExpression(e)).join(", ");
      return ind + vars + " = " + vals;
    }
    case "CallStatement": {
      return ind + printExpression((stmt as any).expression);
    }
    case "IfStatement": {
      let out = ind + "if " + printExpression((stmt as any).condition) + " then";
      const body = (stmt as any).body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      const elseifClauses = (stmt as any).elseifClauses || [];
      elseifClauses.forEach((c: any) => {
        out += "\n" + ind + "elseif " + printExpression(c.condition) + " then";
        (c.body || []).forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      });
      const elseBody = (stmt as any).elseBody || (stmt as any).elsebody || [];
      if (elseBody.length > 0) {
        out += "\n" + ind + "else";
        elseBody.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      }
      out += "\n" + ind + "end";
      return out;
    }
    case "WhileStatement": {
      let out = ind + "while " + printExpression((stmt as any).condition) + " do";
      const body = (stmt as any).body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      out += "\n" + ind + "end";
      return out;
    }
    case "RepeatStatement": {
      let out = ind + "repeat";
      const body = (stmt as any).body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      out += "\n" + ind + "until " + printExpression((stmt as any).condition);
      return out;
    }
    case "ForNumericStatement": {
      const s = stmt as any;
      let out = ind + "for " + (s.variable || "i") + " = " +
        printExpression(s.start) + ", " + printExpression(s.end);
      if (s.step) out += ", " + printExpression(s.step);
      out += " do";
      const body = s.body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      out += "\n" + ind + "end";
      return out;
    }
    case "ForGenericStatement": {
      const s = stmt as any;
      const vars = (s.variables || []).join(", ");
      const iters = (s.iterators || []).map((e: any) => printExpression(e)).join(", ");
      let out = ind + "for " + vars + " in " + iters + " do";
      const body = s.body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      out += "\n" + ind + "end";
      return out;
    }
    case "FunctionDeclaration": {
      const s = stmt as any;
      const name = s.identifier || "";
      const params = (s.parameters || []).map((p: any) =>
        typeof p === "string" ? p : p.name || printExpression(p)
      ).join(", ");
      let out = ind + (s.isLocal ? "local " : "") + "function " + name + "(" + params + ")";
      const body = s.body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      out += "\n" + ind + "end";
      return out;
    }
    case "DoStatement": {
      let out = ind + "do";
      const body = (stmt as any).body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, indentLevel + 1));
      out += "\n" + ind + "end";
      return out;
    }
    case "ReturnStatement": {
      const args = (stmt as any).arguments || [];
      if (args.length === 0) return ind + "return";
      return ind + "return " + args.map((e: any) => printExpression(e)).join(", ");
    }
    case "BreakStatement":
      return ind + "break";
    case "ContinueStatement":
      return ind + "continue";
    case "GotoStatement":
      return ind + "goto " + ((stmt as any).label || "");
    case "LabelStatement":
      return ind + "::" + ((stmt as any).label || "") + "::";
    default:
      // Try to handle unknown statement types gracefully
      if (typeof (stmt as any).raw === "string" && (stmt as any).type === "Comment") {
        return ind + ((stmt as any).raw || "");
      }
      return ind + "-- [unknown statement: " + type + "]";
  }
}

function printExpression(expr: any): string {
  if (expr === null || expr === undefined) return "nil";
  if (typeof expr === "string") return expr;
  if (typeof expr !== "object") return String(expr);

  switch (expr.type) {
    case "Identifier":
      return expr.name;
    case "StringLiteral":
      return stringLiteral(expr.value || expr.raw || "");
    case "NumericLiteral":
      return expr.value !== undefined ? String(expr.value) : (expr.raw || "0");
    case "BooleanLiteral":
      return expr.value === true ? "true" : "false";
    case "NilLiteral":
    case "nil":
      return "nil";
    case "VarargLiteral":
      return "...";
    case "MemberExpression": {
      const base = printExpression(expr.base || expr.object);
      const prop = expr.identifier || expr.property || expr.name || "";
      if (expr.indexer === ":" || expr.method) {
        return base + ":" + prop;
      }
      return base + "." + prop;
    }
    case "IndexExpression": {
      const base = printExpression(expr.base || expr.object);
      const index = printExpression(expr.index);
      return base + "[" + index + "]";
    }
    case "CallExpression":
    case "StringCallExpression":
    case "TableCallExpression": {
      const base = printExpression(expr.base || expr.callee);
      const args = (expr.arguments || expr.args || []).map((a: any) => printExpression(a));
      return base + "(" + args.join(", ") + ")";
    }
    case "BinaryExpression":
      return "(" + printExpression(expr.left) + " " + (expr.operator || "") + " " + printExpression(expr.right) + ")";
    case "LogicalExpression":
      return "(" + printExpression(expr.left) + " " + (expr.operator || "") + " " + printExpression(expr.right) + ")";
    case "UnaryExpression":
      return "(" + (expr.operator || "") + printExpression(expr.argument) + ")";
    case "FunctionDeclaration": {
      const params = (expr.parameters || []).map((p: any) =>
        typeof p === "string" ? p : p.name || printExpression(p)
      ).join(", ");
      let out = "function(" + params + ")";
      const body = expr.body || [];
      body.forEach((b: any) => out += "\n" + printStatement(b, 1));
      out += "\nend";
      return out;
    }
    case "TableConstructorExpression": {
      const fields = (expr.fields || []).map((f: any) => printTableField(f)).join(", ");
      return "{" + fields + "}";
    }
    case "ParenExpression":
      return "(" + printExpression(expr.expression) + ")";
    default:
      // Fallback: try raw or toString
      if (expr.raw) return expr.raw;
      return "nil";
  }
}

function printVar(v: any): string {
  if (!v || typeof v !== "object") return String(v);
  switch (v.type) {
    case "Identifier":
      return v.name;
    case "MemberExpression": {
      const base = printExpression(v.base || v.object);
      const prop = v.identifier || v.property || v.name || "";
      if (v.indexer === ":" || v.method) return base + ":" + prop;
      return base + "." + prop;
    }
    case "IndexExpression": {
      return printExpression(v.base || v.object) + "[" + printExpression(v.index) + "]";
    }
    default:
      return printExpression(v);
  }
}

function printTableField(f: any): string {
  if (!f) return "";
  if (f.type === "TableKeyString" || f.type === "TableKey") {
    const key = f.key ? printExpression(f.key) : "";
    const val = f.value ? printExpression(f.value) : "";
    return "[" + key + "] = " + val;
  }
  if (f.type === "TableValue" || f.key === undefined) {
    const val = f.value ? printExpression(f.value) : "";
    return val;
  }
  if (f.type === "TableKeyEntry") {
    return "[" + printExpression(f.key) + "] = " + printExpression(f.value);
  }
  // Named field
  const key = f.name || f.key?.name || "";
  const val = f.value ? printExpression(f.value) : "";
  return key + " = " + val;
}

function stringLiteral(str: string): string {
  // Use single quotes to avoid double-escape issues
  return '"' + str.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t") + '"';
}

function printChunk(ast: LUANode): string {
  const body = (ast as any).body || [];
  return body.map((s: LUANode) => printStatement(s)).join("\n");
}

// ============== SOURCE-LEVEL OPAQUE PREDICATES ==============

function addOpaquePredicates(source: string, seed: number): string {
  // Add opaque predicates to if/while/repeat conditions
  // We use regex to find condition expressions and wrap them

  let idx = 0;
  let result = "";
  let i = 0;
  let condCount = 0;

  while (i < source.length) {
    // Skip strings
    if (source[i] === '"' || source[i] === "'") {
      const q = source[i];
      result += source[i]; i++;
      while (i < source.length && source[i] !== q) {
        if (source[i] === "\\") { result += source[i]; i++; }
        result += source[i]; i++;
      }
      if (i < source.length) { result += source[i]; i++; }
      continue;
    }
    // Skip long strings
    if (source[i] === "[" && i + 1 < source.length && source[i + 1] === "[") {
      let j = i + 2;
      while (j < source.length && !(source[j] === "]" && source[j + 1] === "]")) j++;
      result += source.substring(i, j + 2);
      i = j + 2;
      continue;
    }
    // Skip comments
    if (source[i] === "-" && source[i + 1] === "-") {
      let j = i + 2;
      // Check for long comment
      if (source[j] === "[") {
        let level = 0;
        while (source[j] === "=") { level++; j++; }
        if (source[j] === "[") {
          const close = "]".repeat(level || 0) + "]";
          const endIdx = source.indexOf(close, j + 1);
          if (endIdx >= 0) {
            result += source.substring(i, endIdx + close.length);
            i = endIdx + close.length;
            continue;
          }
        }
      }
      while (i < source.length && source[i] !== "\n") { result += source[i]; i++; }
      continue;
    }

    // Detect condition patterns: "if <cond> then", "while <cond> do", "until <cond>"
    const rest = source.substring(i);
    const ifMatch = rest.match(/^(if\s+)(.*?)(\s+then\b)/s);
    const whileMatch = rest.match(/^(while\s+)(.*?)(\s+do\b)/s);
    const untilMatch = rest.match(/^(until\s+)(.*?)(\s*$|\s*--)/s);

    if (ifMatch) {
      condCount++;
      const prefix = ifMatch[1]!;
      const condition = ifMatch[2]!.trim();
      const suffix = ifMatch[3]!;
      const wrapped = wrapExprWithOpaque(condition, seed + condCount);
      result += prefix + wrapped + suffix;
      i += ifMatch[0].length;
    } else if (whileMatch) {
      condCount++;
      const prefix = whileMatch[1]!;
      const condition = whileMatch[2]!.trim();
      const suffix = whileMatch[3]!;
      const wrapped = wrapExprWithOpaque(condition, seed + condCount);
      result += prefix + wrapped + suffix;
      i += whileMatch[0].length;
    } else if (untilMatch) {
      condCount++;
      const prefix = untilMatch[1]!;
      const condition = untilMatch[2]!.trim();
      const wrapped = wrapExprWithOpaque(condition, seed + condCount);
      result += prefix + wrapped;
      i += prefix.length + untilMatch[2]!.length;
    } else {
      result += source[i];
      i++;
    }
  }

  return result;
}

// ============== MAIN EXPORT ==============

export interface ClydeOptions {
  renameLocals?: boolean;
  opaquePredicates?: boolean;
  encryptStrings?: boolean;
  seed?: number;
}

/**
 * Apply Clyde-style AST transforms to a Lua script.
 * 1. Parse source with luaparse
 * 2. Apply scope-aware variable renaming
 * 3. Apply opaque predicates
 * 4. Encrypt string literals
 * 5. Print back to Lua source
 */
export function clydeTransform(
  source: string,
  options: ClydeOptions = {}
): string {
  const opts = {
    renameLocals: true,
    opaquePredicates: true,
    encryptStrings: true,
    seed: Math.floor(Math.random() * 100000),
    ...options,
  };

  // Step 1: Preprocess Luau (remove type annotations, convert Luau syntax)
  // We import preprocessLuau
  let processed = source;

  // Step 2: Apply opaque predicates at source level (works without full AST)
  if (opts.opaquePredicates) {
    processed = addOpaquePredicates(processed, opts.seed);
  }

  // Step 3: Parse with luaparse
  let ast: LUANode;
  try {
    ast = luaparse.parse(processed, {
      locations: false,
      comments: true,
      luaVersion: "5.2",
      scope: false,
      wait: false,
    });
  } catch (e) {
    // If parsing fails, return the processed source as-is
    console.warn("Clyde: luaparse failed, using processed source", e);
    return processed;
  }

  // Step 4: Apply name mangling
  if (opts.renameLocals) {
    const scope = new ScopeManager();
    ast = transformChunk(ast, scope);
  }

  // Step 5: Print back to Lua source
  let output = printChunk(ast);

  // Step 6: Encrypt string literals
  if (opts.encryptStrings) {
    const decoderName = "_s" + Math.random().toString(36).substring(2, 6);
    const encKey = opts.seed % 256;
    const decoderCode = generateDecoderCode(decoderName, encKey);

    // Replace string literals with encrypted versions
    // We use a simple regex-based approach for the string literals
    let encResult = "";
    let j = 0;
    while (j < output.length) {
      // Skip comments
      if (output[j] === "-" && output[j + 1] === "-") {
        let end = j + 2;
        while (end < output.length && output[end] !== "\n") end++;
        encResult += output.substring(j, end);
        j = end;
        continue;
      }
      // Skip strings
      if (output[j] === '"' || output[j] === "'") {
        const q = output[j];
        let end = j + 1;
        while (end < output.length && output[end] !== q) {
          if (output[end] === "\\") end++;
          end++;
        }
        const inner = output.substring(j + 1, end);
        // Only encrypt non-empty strings with more than 2 chars
        if (inner.length >= 2) {
          encResult += makeEncryptedString(inner, encKey, decoderName);
        } else {
          encResult += output.substring(j, end + 1);
        }
        j = end + 1;
        continue;
      }
      // Skip long strings
      if (output[j] === "[" && output[j + 1] === "[") {
        let end = j + 2;
        while (end < output.length && !(output[end] === "]" && output[end + 1] === "]")) end++;
        encResult += output.substring(j, end + 2);
        j = end + 2;
        continue;
      }
      encResult += output[j];
      j++;
    }

    output = decoderCode + "\n" + encResult;
  }

  return output;
}
