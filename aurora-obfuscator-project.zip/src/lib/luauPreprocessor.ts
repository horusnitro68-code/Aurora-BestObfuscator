/**
 * Lua/Luau Preprocessor - Full Luau Support Module
 *
 * Converts Luau syntax to Lua 5.1 compatible syntax before parsing with luaparse.
 * Also provides luraph-style string obfuscation.
 */

// ========== STRING OBFUSCATION ==========

type EscapeStyle = 'hex' | 'unicode' | 'octal';

function obfuscateChar(char: string): string {
  const code = char.charCodeAt(0);
  // Note: unicode escapes (\u{NNNN}) are NOT valid in Lua 5.1/5.2 - only use hex and octal
  const styles: EscapeStyle[] = ['hex', 'octal'];
  const style = styles[Math.floor(Math.random() * styles.length)];
  switch (style) {
    case 'hex':
      return `\\x${code.toString(16).padStart(2, '0')}`;
    case 'unicode':
      return `\\u{${code.toString(16).padStart(4, '0')}}`;
    case 'octal':
      return `\\${code.toString(8).padStart(3, '0')}`;
  }
}

function obfuscateStringContent(str: string): string {
  if (str.length < 2) return str;
  let result = '';
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    const code = char.charCodeAt(0);
    if (code < 32 || code > 126 || char === '"' || char === "'" || char === '\\') {
      result += char;
    } else if (Math.random() < 0.7) {
      result += obfuscateChar(char);
    } else {
      result += char;
    }
  }
  return result;
}

// ========== ESCAPE SANITIZATION ==========

/**
 * Fix invalid escape sequences in string literals.
 * Lua 5.1 silently ignores unrecognized escapes like \H (treating them as literal H).
 * Lua 5.2+ and luaparse with luaVersion '5.2' throw an error on them.
 * This function double-escapes \\ before invalid escape characters.
 */
function sanitizeInvalidEscapes(source: string): string {
  let result = '';
  let i = 0;
  while (i < source.length) {
    // Skip line comments
    if (source[i] === '-' && source[i + 1] === '-') {
      if (source[i + 2] === '[') {
        let level = 0;
        let j = i + 2;
        while (j < source.length && source[j] === '=') { level++; j++; }
        if (j < source.length && source[j] === '[') {
          const closing = ']'.repeat(level) + ']';
          const endIdx = source.indexOf(closing, j + 1);
          if (endIdx !== -1) {
            result += source.substring(i, endIdx + closing.length);
            i = endIdx + closing.length;
            continue;
          }
        }
      }
      while (i < source.length && source[i] !== '\n') { result += source[i]; i++; }
      continue;
    }
    // Skip long strings (raw content, no escape processing needed)
    if (source[i] === '[') {
      let level = 0;
      let j = i + 1;
      while (j < source.length && source[j] === '=') { level++; j++; }
      if (j < source.length && source[j] === '[') {
        const closing = ']'.repeat(level) + ']';
        const endIdx = source.indexOf(closing, j + 1);
        if (endIdx !== -1) {
          result += source.substring(i, endIdx + closing.length);
          i = endIdx + closing.length;
          continue;
        }
      }
      result += source[i]; i++;
      continue;
    }
    // Process string literals
    if (source[i] === '"' || source[i] === "'") {
      const quote = source[i];
      result += source[i]; i++;
      while (i < source.length && source[i] !== quote) {
        if (source[i] === '\\') {
          if (i + 1 < source.length) {
            const next = source[i + 1];
            // Valid Lua 5.2 escape sequences (NOT including 'u' - \u{...} is Lua 5.3+)
            const validEscapes = 'abfnrtv\\"\'0123456789x';
            if (!validEscapes.includes(next)) {
              // Invalid escape: add extra backslash
              result += '\\\\';
              i++;
              continue;
            }
            // Valid hex \xNN
            if (next === 'x') {
              result += source[i] + source[i + 1]; i += 2;
              if (i < source.length && /[0-9a-fA-F]/.test(source[i])) { result += source[i]; i++; }
              if (i < source.length && /[0-9a-fA-F]/.test(source[i])) { result += source[i]; i++; }
              continue;
            }
            // Valid unicode \u{...}
            if (next === 'u') {
              result += source[i] + source[i + 1]; i += 2;
              if (i < source.length && source[i] === '{') { result += source[i]; i++; }
              while (i < source.length && source[i] !== '}') { result += source[i]; i++; }
              if (i < source.length && source[i] === '}') { result += source[i]; i++; }
              continue;
            }
            // Valid decimal escape \d or \ddd (1-3 digits)
            if (/[0-9]/.test(next)) {
              result += source[i] + source[i + 1]; i += 2;
              let digits = 1;
              while (digits < 3 && i < source.length && /[0-9]/.test(source[i])) {
                result += source[i]; i++; digits++;
              }
              continue;
            }
            // Standard valid escape (\n, \t, \\, etc.)
            result += source[i] + source[i + 1]; i += 2;
            continue;
          }
        }
        result += source[i]; i++;
      }
      if (i < source.length) { result += source[i]; i++; }
      continue;
    }
    result += source[i]; i++;
  }
  return result;
}

// ========== LUAU SYNTAX PREPROCESSING ==========

export function stripTypeAnnotations(source: string): string {

  let result = '';
  let i = 0;
  while (i < source.length) {
    // Skip line comments
    if (source[i] === '-' && source[i + 1] === '-') {
      if (source[i + 2] === '[') {
        let level = 0;
        let j = i + 2;
        while (j < source.length && source[j] === '=') { level++; j++; }
        if (j < source.length && source[j] === '[') {
          const closing = ']'.repeat(level) + ']';
          const endIdx = source.indexOf(closing, j + 1);
          if (endIdx !== -1) {
            result += source.substring(i, endIdx + closing.length);
            i = endIdx + closing.length;
            continue;
          }
        }
      }
      while (i < source.length && source[i] !== '\n') { result += source[i]; i++; }
      continue;
    }
    // Skip strings
    if (source[i] === '"' || source[i] === "'") {
      const quote = source[i];
      result += source[i]; i++;
      while (i < source.length && source[i] !== quote) {
        if (source[i] === '\\') { result += source[i]; i++; }
        result += source[i]; i++;
      }
      if (i < source.length) { result += source[i]; i++; }
      continue;
    }
    // Skip long strings
    if (source[i] === '[') {
      let level = 0;
      let j = i + 1;
      while (j < source.length && source[j] === '=') { level++; j++; }
      if (j < source.length && source[j] === '[') {
        const closing = ']'.repeat(level) + ']';
        const endIdx = source.indexOf(closing, j + 1);
        if (endIdx !== -1) {
          result += source.substring(i, endIdx + closing.length);
          i = endIdx + closing.length;
          continue;
        }
      }
      result += source[i]; i++;
      continue;
    }
    // Skip backtick strings
    if (source[i] === '`') {
      result += '"'; i++;
      while (i < source.length && source[i] !== '`') {
        if (source[i] === '{') {
          let depth = 1; i++;
          while (i < source.length && depth > 0) {
            if (source[i] === '{') depth++;
            if (source[i] === '}') depth--;
            i++;
          }
        } else if (source[i] === '\\') {
          result += source[i]; i++;
          if (i < source.length) { result += source[i]; i++; }
        } else {
          result += source[i]; i++;
        }
      }
      if (i < source.length) i++;
      result += '"';
      continue;
    }
    // Strip type annotations: `: Type` after identifier (NOT method calls `obj:method(`)
    if (source[i] === ':' && i > 0) {
      const prevChar = source[i - 1];
      if (/[a-zA-Z0-9_\])]/.test(prevChar)) {
        let j = i + 1;
        while (j < source.length && source[j] === ' ') j++;
        // If colon is followed by word + '(' it's a method call, not a type annotation
        // e.g. game:GetService(...) — preserve it
        if (source[j] && /[a-zA-Z_]/.test(source[j])) {
          let k = j;
          while (k < source.length && /[a-zA-Z0-9_]/.test(source[k])) k++;
          if (source[k] === '(' || source[k] === '.') { result += source[i]; i++; continue; }
        }
        const rest = source.substring(j);
        const typePatterns = /^(string|number|boolean|any|nil|void|never|unknown|self|typeof|Vector3|Vector2|CFrame|UDim2|UDim|Color3|Instance|Enum|Player|Model|Humanoid)\b/i;
        const complexType = /^[{(\\[]|function\b/i;
        if (typePatterns.test(rest) || complexType.test(rest)) {
          i = skipTypeExpression(source, j);
          continue;
        }
      }
    }
    result += source[i]; i++;
  }
  return result;
}

function skipTypeExpression(source: string, i: number): number {
  while (i < source.length && source[i] === ' ') i++;
  if (i >= source.length) return i;
  if (/[a-zA-Z_]/.test(source[i])) {
    while (i < source.length && /[a-zA-Z0-9_.]/.test(source[i])) i++;
    return i;
  }
  if (source[i] === '{') {
    let depth = 1; i++;
    while (i < source.length && depth > 0) {
      if (source[i] === '{') depth++;
      if (source[i] === '}') depth--;
      i++;
    }
    return i;
  }
  if (source[i] === '(') {
    let depth = 1; i++;
    while (i < source.length && depth > 0) {
      if (source[i] === '(') depth++;
      if (source[i] === ')') depth--;
      i++;
    }
    while (i < source.length && source[i] === ' ') i++;
    if (source[i] === '-' && source[i + 1] === '>') {
      i += 2;
      i = skipTypeExpression(source, i);
    }
    return i;
  }
  return i;
}

function convertCompoundAssignments(source: string): string {
  // Handle //= first: x //= y → x = x // y
  source = source.replace(
    /(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*\/\/=(?!=)\s*/g,
    '$1 = $1 // '
  );
  const patterns: [RegExp, string][] = [
    [/(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*\+=(?!=)\s*/g, '$1 = $1 + '],
    [/(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*-=(?!=)\s*/g, '$1 = $1 - '],
    [/(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*\*=(?!=)\s*/g, '$1 = $1 * '],
    [/(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*\/=(?!=)\s*/g, '$1 = $1 / '],
    [/(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*%=(?!=)\s*/g, '$1 = $1 % '],
    [/(\b[a-zA-Z_][a-zA-Z0-9_.]*(?:\[[^\]]+\])*)\s*\.\.=(?!=)\s*/g, '$1 = $1 .. '],
  ];
  let result = source;
  for (const [pattern, replacement] of patterns) {
    result = result.replace(pattern, replacement);
  }
  return result;
}

function convertTypeof(source: string): string {
  // CRITICAL FIX: only convert `typeof` used as a Luau TYPE ANNOTATION
  // (`: typeof(...)`), NOT the Luau runtime function `typeof()`.
  // The runtime function returns "Vector3", "CFrame", etc. — converting it
  // to `type()` broke every `typeof(x) == "Vector3"` check in scripts because
  // `type(Vector3)` returns "userdata", never "Vector3".
  return source.replace(/(:\s*)typeof\s*\(/g, '$1type(');
}

function convertFloorDivision(source: string): string {
  return source.split('\n').map(convertFloorDivisionLine).join('\n');
}

function convertFloorDivisionLine(line: string): string {
  let result = '';
  let i = 0;
  while (i < line.length) {
    if (line[i] === '-' && line[i + 1] === '-') { result += line.substring(i); break; }
    if (line[i] === '"' || line[i] === "'") {
      const q = line[i]; result += line[i]; i++;
      while (i < line.length && line[i] !== q) { if (line[i] === '\\') { result += line[i]; i++; } result += line[i]; i++; }
      if (i < line.length) { result += line[i]; i++; }
      continue;
    }
    if (line[i] === '`') {
      result += '"'; i++;
      while (i < line.length && line[i] !== '`') { if (line[i] === '\\') { result += line[i]; i++; } if (i < line.length) { result += line[i]; i++; } }
      if (i < line.length) i++;
      result += '"'; continue;
    }
    if (line[i] === '/' && line[i + 1] === '/') {
      let prevIdx = i - 1;
      while (prevIdx >= 0 && line[prevIdx] === ' ') prevIdx--;
      const prevChar = prevIdx >= 0 ? line[prevIdx] : '';
      let nextIdx = i + 2;
      while (nextIdx < line.length && line[nextIdx] === ' ') nextIdx++;
      const nextChar = nextIdx < line.length ? line[nextIdx] : '';
      if (/[a-zA-Z0-9_)\"'\\]]/.test(prevChar) && nextChar && nextChar !== '=') {
        let leftStart = prevIdx;
        let depth = 0;
        while (leftStart > 0) {
          if (line[leftStart] === ')' || line[leftStart] === ']') depth++;
          if (line[leftStart] === '(' || line[leftStart] === '[') depth--;
          if (depth < 0) break;
          if (depth === 0 && /[\s+\-*/%^]/.test(line[leftStart])) break;
          leftStart--;
        }
        if (depth >= 0) leftStart++;
        let rightEnd = nextIdx;
        depth = 0;
        while (rightEnd < line.length) {
          if (line[rightEnd] === '(' || line[rightEnd] === '[') depth++;
          if (line[rightEnd] === ')' || line[rightEnd] === ']') depth--;
          if (depth === 0 && /[\s+\-*/%^;,)\\]]/.test(line[rightEnd])) break;
          rightEnd++;
        }
        const leftOp = line.substring(leftStart, i);
        const rightOp = line.substring(i + 2, rightEnd);
        result = result.substring(0, result.length - (i - leftStart));
        result += `math.floor(${leftOp}/${rightOp})`;
        i = rightEnd; continue;
      }
    }
    result += line[i]; i++;
  }
  return result;
}

function convertContinueStatements(source: string): string {
  // Converts Luau 'continue' to Lua 5.1-compatible 'repeat...until true' + 'break'.
  // This works by wrapping the loop body in a repeat...until true block,
  // so that 'break' acts as 'continue' (exits the inner repeat, not the outer loop).
  //
  // Two-pass approach: Pass 1 records loop structure. Pass 2 applies edits.

  // Skip if no standalone 'continue' found.
  if (!/\bcontinue\b/.test(source)) return source;
  if (/(?<![_a-zA-Z0-9])continue(?![_a-zA-Z0-9])/.test(source) === false) return source;

  // ---- Pass 1: record loop structure ----

  const loopClosePos = new Map<number, number>(); // loopId → position of closing end/until
  const loopBodyStart = new Map<number, number>(); // loopId → position AFTER 'do' (or after 'repeat')
  const loopsWithContinue = new Set<number>();
  const loopsWithBreakAtSameLevel = new Set<number>();
  let loopId = 0;
  const blockStack: string[] = [];
  const continueMap = new Map<number, number>();

  let i = 0;
  while (i < source.length) {
    // Skip line comments
    if (source[i] === '-' && source[i + 1] === '-') {
      if (source[i + 2] === '[') {
        let level = 0; let j = i + 2;
        while (j < source.length && source[j] === '=') { level++; j++; }
        if (j < source.length && source[j] === '[') {
          const closing = ']'.repeat(level) + ']';
          const endIdx = source.indexOf(closing, j + 1);
          if (endIdx !== -1) { i = endIdx + closing.length; continue; }
        }
      }
      while (i < source.length && source[i] !== '\n') i++;
      continue;
    }
    // Skip strings
    if (source[i] === '"' || source[i] === "'") {
      const q = source[i]; i++;
      while (i < source.length && source[i] !== q) { if (source[i] === '\\') i++; i++; }
      if (i < source.length) i++;
      continue;
    }
    // Skip long strings
    if (source[i] === '[') {
      let level = 0; let j = i + 1;
      while (j < source.length && source[j] === '=') { level++; j++; }
      if (j < source.length && source[j] === '[') {
        const closing = ']'.repeat(level) + ']';
        const endIdx = source.indexOf(closing, j + 1);
        if (endIdx !== -1) { i = endIdx + closing.length; continue; }
      }
    }

    const r = source.substring(i);

    // else/elseif — no stack change
    if (/^elseif\b/.test(r)) { i += 6; continue; }
    if (/^else\b/.test(r)) { i += 4; continue; }

    // Block openers
    if (/^while\b/.test(r)) { loopId++; blockStack.push('expect_do_loop_' + loopId); i += 5; continue; }
    if (/^for\b/.test(r))   { loopId++; blockStack.push('expect_do_loop_' + loopId); i += 3; continue; }
    if (/^repeat\b/.test(r)) {
      loopId++;
      blockStack.push('loop_' + loopId);
      // For repeat loops, the body starts right after the keyword
      loopBodyStart.set(loopId, i + 6);
      i += 6; continue;
    }
    if (/^if\b/.test(r))      { blockStack.push('if');  i += 2; continue; }
    if (/^function\b/.test(r)) { blockStack.push('fn');  i += 8; continue; }
    if (/^do\b/.test(r)) {
      const top = blockStack[blockStack.length - 1];
      if (top && top.startsWith('expect_do_loop_')) {
        const lid = parseInt(top.split('_')[3]);
        blockStack[blockStack.length - 1] = 'loop_' + lid;
        // Body starts after 'do' keyword
        loopBodyStart.set(lid, i + 2);
      } else {
        blockStack.push('do');
      }
      i += 2; continue;
    }

    // Block closers — record loop close positions
    if (/^end\b/.test(r)) {
      const popped = blockStack.pop();
      if (popped && popped.startsWith('loop_')) {
        loopClosePos.set(parseInt(popped.split('_')[1]), i);
      }
      i += 3; continue;
    }
    if (/^until\b/.test(r)) {
      const popped = blockStack.pop();
      if (popped && popped.startsWith('loop_')) {
        loopClosePos.set(parseInt(popped.split('_')[1]), i);
      }
      i += 5; continue;
    }

    // Continue — find enclosing loop, respecting function boundaries
    if (/^continue\b/.test(r)) {
      for (let k = blockStack.length - 1; k >= 0; k--) {
        if (blockStack[k] === 'fn') break;
        if (blockStack[k].startsWith('loop_')) {
          const lid = parseInt(blockStack[k].split('_')[1]);
          loopsWithContinue.add(lid);
          continueMap.set(i, lid);
          break;
        }
      }
      i += 8; continue;
    }

    // Break — check if it's at loop level (not inside nested loops/functions)
    if (/^break\b/.test(r)) {
      for (let k = blockStack.length - 1; k >= 0; k--) {
        if (blockStack[k] === 'fn') break;
        if (blockStack[k].startsWith('loop_')) {
          const lid = parseInt(blockStack[k].split('_')[1]);
          // Check: is this loop at the IMMEDIATE enclosing level?
          // (break inside a nested for/while would have a later loop_N entry)
          // The break exits the nearest loop, so we check if there's a loop_N
          // in the block stack that is NOT the innermost one
          let hasInnerLoop = false;
          for (let m = blockStack.length - 1; m > k; m--) {
            if (blockStack[m].startsWith('loop_')) { hasInnerLoop = true; break; }
          }
          if (!hasInnerLoop) {
            loopsWithBreakAtSameLevel.add(lid);
          }
          break;
        }
      }
      i += 5; continue;
    }

    i++;
  }

  // If no loops with continue found, return source unchanged.
  if (loopsWithContinue.size === 0) return source;

  // ---- Pass 2: apply edits ----

  const edits: { pos: number; del: number; ins: string }[] = [];
  const emittedWrappers = new Set<number>();

  // For each loop with continue, insert wrapper and replace continues
  for (const lid of loopsWithContinue) {
    const bodyStart = loopBodyStart.get(lid);
    const bodyEnd = loopClosePos.get(lid);
    if (bodyStart !== undefined && bodyEnd !== undefined) {
      // Insert '\nrepeat' right after body start
      edits.push({ pos: bodyStart, del: 0, ins: '\nrepeat\n' });
      // Insert '\nuntil true\n' right before body end (ensures separation from end/until keyword)
      edits.push({ pos: bodyEnd, del: 0, ins: '\nuntil true\n' });
      emittedWrappers.add(lid);
    }
  }

  // Replace each continue with 'break'
  for (const [pos, lid] of continueMap) {
    edits.push({ pos, del: 8, ins: 'break' });
  }

  // Apply edits in reverse order (so positions don't shift)
  edits.sort((a, b) => b.pos - a.pos);
  let output = source;
  for (const e of edits) {
    output = output.substring(0, e.pos) + e.ins + output.substring(e.pos + e.del);
  }

  return output;
}

function obfuscateAllStrings(source: string): string {
  let result = '';
  let i = 0;
  while (i < source.length) {
    if (source[i] === '-' && source[i + 1] === '-') {
      if (source[i + 2] === '[') {
        let level = 0; let j = i + 2;
        while (j < source.length && source[j] === '=') { level++; j++; }
        if (j < source.length && source[j] === '[') {
          const closing = ']'.repeat(level) + ']';
          const endIdx = source.indexOf(closing, j + 1);
          if (endIdx !== -1) { result += source.substring(i, endIdx + closing.length); i = endIdx + closing.length; continue; }
        }
      }
      while (i < source.length && source[i] !== '\n') { result += source[i]; i++; }
      continue;
    }
    if (source[i] === '[') {
      let level = 0; let j = i + 1;
      while (j < source.length && source[j] === '=') { level++; j++; }
      if (j < source.length && source[j] === '[') {
        const closing = ']'.repeat(level) + ']';
        const endIdx = source.indexOf(closing, j + 1);
        if (endIdx !== -1) { result += source.substring(i, endIdx + closing.length); i = endIdx + closing.length; continue; }
      }
    }
    if (source[i] === '"') {
      let j = i + 1; let s = '';
      while (j < source.length && source[j] !== '"') { if (source[j] === '\\') { s += source[j] + source[j + 1]; j += 2; } else { s += source[j]; j++; } }
      result += '"' + obfuscateStringContent(s) + '"'; i = j + 1; continue;
    }
    if (source[i] === "'") {
      let j = i + 1; let s = '';
      while (j < source.length && source[j] !== "'") { if (source[j] === '\\') { s += source[j] + source[j + 1]; j += 2; } else { s += source[j]; j++; } }
      result += "'" + obfuscateStringContent(s) + "'"; i = j + 1; continue;
    }
    result += source[i]; i++;
  }
  return result;
}

// ========== MAIN PIPELINE ==========

export function preprocessLuau(source: string): string {
  let result = source;
  result = sanitizeInvalidEscapes(result);
  result = stripTypeAnnotations(result);
  result = convertTypeof(result);
  result = convertContinueStatements(result);
  result = convertCompoundAssignments(result);
  result = convertFloorDivision(result);
  // NOTE: obfuscateAllStrings removed - string obfuscation is already
  // handled at the bytecode level by encodeConstantFlat in vmObfuscator.ts.
  // Applying it here corrupts string constants before luaparse parses them,
  // causing the VM runtime to read garbled constant values.
  return result;
}

export { preprocessLuau as preprocessStrings };
