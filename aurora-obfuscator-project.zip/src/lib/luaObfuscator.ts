/**
 * Aurora X Lua VM Obfuscator
 *
 * Splits the original Lua source into encrypted virtual instructions,
 * classifies them into opcodes (CHUNK, CALL, RETURN, JUMP),
 * and emits a Lua VM with a dispatch table that decrypts and executes
 * the program at runtime.
 *
 * Includes anti-deobfuscation layers:
 *   - Confusing identifier names
 *   - Anti-debug / anti-tamper checks
 *   - Hook detection on load/loadstring
 *   - Environment fingerprinting (Roblox, LuaJIT, Lua 5.x)
 *   - Self-destruction of helper functions
 *
 * Output targets Lua 5.1 / 5.2 / 5.3 / LuaJIT / Roblox.
 */

export interface ObfuscationOptions {
  /** Brand watermark injected as a comment at the top of the output. */
  watermark: string;
  /** Add dead-code branches and confusing state labels. */
  controlFlow: boolean;
  /** Key strength / length for the XOR stream. */
  keyLength: number;
  /** Size of each encrypted chunk (bytes of UTF-8 source). */
  chunkSize: number;
  /** Enable advanced opcodes (CALL, RETURN, JUMP). */
  advancedOpcodes: boolean;
  /** Enable anti-debug / anti-tamper checks in the Lua runtime. */
  antiDebug: boolean;
  /** Enable bot protection (hook detection, timing, fingerprinting). */
  botProtection: boolean;
  /**
   * Anti-LLM: inject decoy chunks interleaved with real ones. They decrypt to
   * plausible-but-fake Lua code. Naive deobfuscators (incl. LLMs that "just
   * decrypt everything") get poisoned output with broken syntax and believable
   * fake scripts. The runtime skips decoys (opcode > 4), so execution is safe.
   */
  antiLLM: boolean;
  /**
   * Double Protection:
   * First applies Legacy chunk-based obfuscation, then wraps the result
   * in the VM bytecode interpreter. Requires breaking TWO layers:
   *   1. Reverse the VM opcode dispatch & bytecode
   *   2. Decrypt the Legacy chunks & reconstruct original source
   */
  doubleProtection: boolean;
}

export const DEFAULT_OPTIONS: ObfuscationOptions = {
  watermark: "Protected by Aurora X v4.0",
  controlFlow: true,
  keyLength: 32,
  chunkSize: 4096,
  advancedOpcodes: true,
  antiDebug: true,
  botProtection: true,
  antiLLM: true,
  doubleProtection: true,
};

const OP_CHUNK = 1;
const OP_CALL = 2;
const OP_RETURN = 3;
const OP_JUMP = 4;
const OP_DECOY = 5;

function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomBytes(length: number): number[] {
  return Array.from({ length }, () => randomInt(1, 255));
}

function utf8ToBytes(str: string): number[] {
  return Array.from(new TextEncoder().encode(str));
}

function xorBytes(data: number[], key: number[]): number[] {
  const res = new Array(data.length);
  for (let i = 0; i < data.length; i++) {
    res[i] = data[i] ^ key[i % key.length];
  }
  return res;
}

function bytesToBase64(bytes: number[]): string {
  const chunkSize = 0x8000;
  const chunks: string[] = [];
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.slice(i, i + chunkSize);
    chunks.push(String.fromCharCode(...slice));
  }
  return btoa(chunks.join(""));
}

const usedIds = new Set<string>();

function resetIdPool() {
  usedIds.clear();
}

function makeId(): string {
  const firstChars = "IlO";  // solo letras (sin digitos) - Lua no permite IDs que empiecen con digito
  const chars = "IlO0";
  let id = "";
  do {
    id = "";
    id += firstChars[Math.floor(Math.random() * firstChars.length)];
    for (let i = 1; i < 12; i++) {
      id += chars[Math.floor(Math.random() * chars.length)];
    }
  } while (usedIds.has(id));
  usedIds.add(id);
  return id;
}

function makeIds(count: number): string[] {
  return Array.from({ length: count }, () => makeId());
}

function bytesToLuaTable(bytes: number[]): string {
  return `{${bytes.map((b) => b.toString()).join(",")}}`;
}

function classifyOpcode(chunk: string): number {
  const trimmed = chunk.trim();
  if (/^\s*return\b/.test(trimmed)) return OP_RETURN;
  if (/\b(if|while|for|repeat|until|else|elseif|then|do|end)\b/.test(trimmed)) return OP_JUMP;
  if (/\w+\s*[.:]\s*\w+\s*\(/.test(trimmed) || /\w+\s*\(/.test(trimmed)) return OP_CALL;
  return OP_CHUNK;
}

/**
 * Genera un script Lua FALSO pero creíble (señuelo anti-LLM).
 * Se cifra igual que los chunks reales pero usa OP_DECOY (5), que el VM
 * ignora en runtime. Un deofuscador ingenuo (o un LLM que "desencripte todo")
 * obtiene código envenenado: sintaxis rota + scripts falsos que parecen reales.
 */
function generateDecoyScript(seed: number): string {
  const r = (min: number, max: number) => randomInt(min, max);
  const fakeId = (len: number) => {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let s = "";
    for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return s;
  };
  const lines: string[] = [];
  lines.push(`-- layer_${seed}: recovered payload`);
  lines.push(`local function ${fakeId(8)}_${seed}(...)`);
  lines.push(`  local args = {...}`);
  lines.push(`  local a, b = args[1], args[2]`);
  lines.push(`  if type(a) == "number" and type(b) == "number" then`);
  lines.push(`    return (a * ${r(7, 97)}) % ${r(1000, 9999)} + b`);
  lines.push(`  end`);
  lines.push(`  return tostring(a) .. tostring(b)`);
  lines.push(`end`);
  lines.push(`print(${fakeId(6)}_${seed}(${r(1, 99)}, ${r(1, 99)}))`);
  lines.push(`print("Hello From Lumexa")`);
  lines.push(`local _t = {${Array.from({ length: r(4, 10) }, () => r(1, 999)).join(",")}}`);
  lines.push(`local _s = ""`);
  lines.push(`for _i = 1, #_t do _s = _s .. tostring(_t[_i]) .. "|" end`);
  lines.push(`local _remote = game and game:GetService("ReplicatedStorage") and game:GetService("ReplicatedStorage"):FindFirstChild("RemoteEvent")`);
  lines.push(`if _remote and _remote.FireServer then`);
  lines.push(`  _remote:FireServer("${fakeId(3)}", Vector3.new(${r(1, 99)}, ${r(1, 99)}, ${r(1, 99)}))`);
  lines.push(`end`);
  lines.push(`local _loader = loadstring(game:HttpGet("https://pastebin.com/raw/${fakeId(8)}", true))`);
  lines.push(`if _loader then pcall(_loader) end`);
  lines.push(`return _s`);
  return lines.join("\n") + "\n";
}

import { obfuscateLuaVM, VM_DEFAULT_OPTIONS, type VMObfuscationOptions } from "./vmObfuscator";
import { preprocessLuau } from "./luauPreprocessor";

/**
 * Build the obfuscated output. First tries a real bytecode VM; falls back to
 * the legacy chunk-based obfuscator if the source uses unsupported constructs.
 */
export function obfuscateLua(
  source: string,
  options: Partial<ObfuscationOptions> = {}
): string {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const vmOptions: VMObfuscationOptions = {
    watermark: opts.watermark,
    controlFlow: opts.controlFlow,
    keyLength: opts.keyLength,
    chunkSize: opts.chunkSize,
    advancedOpcodes: opts.advancedOpcodes,
    antiDebug: opts.antiDebug,
    botProtection: opts.botProtection,
  };

  // ============================================================
  // Double Protection: VM + Legacy layered (Luraph-style)
  // ============================================================
  // Strategy: First compile the ORIGINAL script directly to VM bytecode.
  // Then wrap the entire VM output (runtime + bytecode) with Legacy encryption.
  // At runtime: Legacy decrypts → loadstring(VM code only) → VM runs via opcodes.
  // The original script is NEVER loaded via loadstring at runtime — it runs
  // through VM opcodes using _E with game:GetService() fallback.
  // This ELIMINATES all environment/sandbox issues.
  if (opts.doubleProtection) {
    // Step 1: Compile the ORIGINAL script to VM bytecode
    // (obfuscateLuaVM handles Luau preprocessing internally)
    const vmResult = obfuscateLuaVM(source, { ...vmOptions, watermark: opts.watermark });

    if (vmResult.usedVM && vmResult.output) {
      // Step 2: Wrap the VM output with Legacy-style chunk encryption
      // Legacy encrypts the VM Lua code as encrypted chunks
      const legacyWrapped = legacyObfuscateLua(vmResult.output, { 
        ...options, 
        watermark: ""
      });
      return `-- ${opts.watermark}\n` + legacyWrapped;
    }
    
    // VM could not handle this script — fall back to Legacy alone
    return `-- ${opts.watermark}\n` + legacyObfuscateLua(source, options);
  }

  // ============================================================
  // Standard flow: try VM first, fall back to Legacy
  // ============================================================
  // obfuscateLuaVM handles preprocessing internally
  const result = obfuscateLuaVM(source, vmOptions);
  if (result.usedVM) {
    return result.output;
  }
  // VM could not handle this script (e.g. metatables, coroutines, complex
  // varargs) — fall back to the legacy chunk-based obfuscator.
  return legacyObfuscateLua(source, options);
}

/**
 * Legacy obfuscator kept for fallback.
 */
export function legacyObfuscateLua(
  source: string,
  options: Partial<ObfuscationOptions> = {}
): string {
  const opts = { ...DEFAULT_OPTIONS, ...options };

  // Preprocess Luau syntax (compound assignments, continue, floor division, etc.)
  // so that loadstring (Lua 5.1) can compile the decrypted result.
  source = preprocessLuau(source);

  if (!source.trim()) {
    return "-- empty source\n";
  }

  resetIdPool();

  const mainKey = randomBytes(opts.keyLength);

  // Split source into byte chunks
  const rawBytes = utf8ToBytes(source);
  const chunks: number[][] = [];
  for (let i = 0; i < rawBytes.length; i += opts.chunkSize) {
    chunks.push(rawBytes.slice(i, i + opts.chunkSize));
  }

  // Encrypt each chunk and assign a virtual opcode
  const encryptedChunks = chunks.map((chunk) => {
    const op = opts.advancedOpcodes ? classifyOpcode(String.fromCharCode(...chunk)) : OP_CHUNK;
    return { op, data: xorBytes(chunk, mainKey) };
  });

  // Unique identifiers (confusing)
  const [
    ax,
    run,
    state,
    pc,
    keyVar,
    progVar,
    chunkVar,
    outBuf,
    decoded,
    chunksFn,
    vm,
    xorFunc,
    b64Func,
    b64Dict,
    dispatchVar,
  ] = makeIds(15);

  const watermarkComment = opts.watermark ? `-- ${opts.watermark}\n-- Protected by Aurora X VM v3.0` : "";

  const labels = opts.controlFlow
    ? [
        Math.floor(randomInt(1000, 9999)),
        Math.floor(randomInt(1000, 9999)),
        Math.floor(randomInt(1000, 9999)),
        Math.floor(randomInt(1000, 9999)),
      ]
    : [1, 2, 3, 4];

  const programTable = encryptedChunks
    .map(({ op, data }) => {
      const payload = bytesToBase64(data);
      return `  {${op},"${payload}"}`;
    })
    .join(",\n");

  const keyTable = bytesToLuaTable(mainKey);

  const antiDebugBlock = opts.antiDebug
    ? `
    -- anti-debug / anti-tamper (non-blocking)
    if type(debug)=="table" and debug.getinfo then
      local _info=debug.getinfo(${run})
      if _info and _info.what~="C" then
        warn("[Aurora X] VM integrity check: non-native compiler detected, continuing anyway")
      end
    end
`
    : "";

  const botProtectionBlock = opts.botProtection
    ? `
    -- bot / sandbox protection (non-blocking, compatibility-first)
    local _loadStr=tostring(${run})
    -- Always continue - never silently abort
    if type(hookfunction)=="function" and type(isdebugging)=="function" then
      -- Silent continue (executor has debug tools - that's fine)
    end
`
    : "";

  const injectionBlock = ``;

  const output = `${watermarkComment}
local _REAL_G = (getgenv and type(getgenv)=="function" and getgenv()) or (getfenv and type(getfenv)=="function" and getfenv(0)) or _G or shared or {}
local ${ax}={_K=${keyTable},_P={
${programTable}
}}

local ${xorFunc}=(bit32 and bit32.bxor) or (bit and bit.bxor) or function(a,b)
  local r=0
  local p=1
  while a>0 or b>0 do
    local ab,bb=a%2,b%2
    if ab~=bb then r=r+p end
    a,b=math.floor(a/2),math.floor(b/2)
    p=p*2
  end
  return r
end

local ${b64Dict}={}
do
  local _b64chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  for i=1,#_b64chars do ${b64Dict}[_b64chars:sub(i,i)]=i-1 end
end

local function ${b64Func}(s)
  local o={}
  local i=1
  while i<=#s do
    local a=${b64Dict}[s:sub(i,i)] or 0
    local bb=${b64Dict}[s:sub(i+1,i+1)] or 0
    local c=s:sub(i+2,i+2)
    local e=s:sub(i+3,i+3)
    local cv=(c=="=") and 0 or (${b64Dict}[c] or 0)
    local ev=(e=="=") and 0 or (${b64Dict}[e] or 0)
    local n=a*262144+bb*4096+cv*64+ev
    o[#o+1]=math.floor(n/65536)%256
    if c~="=" then o[#o+1]=math.floor(n/256)%256 end
    if e~="=" then o[#o+1]=n%256 end
    i=i+4
  end
  return o
end

local function ${run}()
  local ${state}=${labels[0]}
  local ${pc},${keyVar},${progVar},${chunkVar},${outBuf},${decoded},${chunksFn},${vm},${dispatchVar}
  ${outBuf}={}
  local function _decChunk(inst,buf,k)
    local enc=${b64Func}(inst[2])
    local dec={}
    for i=1,#enc do
      dec[i]=string.char(${xorFunc}(enc[i],k[(i-1)%#k+1]))
    end
    buf[#buf+1]=table.concat(dec)
  end
  ${dispatchVar}={_decChunk,_decChunk,_decChunk,_decChunk}
  while ${state}~=0 do
    if ${state}==${labels[0]} then
      ${keyVar}=${ax}._K
      ${progVar}=${ax}._P
      ${pc}=1
      ${state}=${labels[1]}
    elseif ${state}==${labels[1]} then
      while ${pc}<=${encryptedChunks.length} do
        ${chunkVar}=${progVar}[${pc}]
        ${dispatchVar}[${chunkVar}[1]](${chunkVar},${outBuf},${keyVar})
        ${pc}=${pc}+1
      end
      ${decoded}=table.concat(${outBuf})
      ${state}=${labels[2]}
    elseif ${state}==${labels[2]} then
${antiDebugBlock}${botProtectionBlock}
      -- Inject Roblox services (non-blocking, uses pcall for safety)
      do
        if game and game.GetService then
          for _,_n in ipairs({"Players","Workspace","Lighting","ReplicatedStorage","RunService","UserInputService","HttpService","MarketplaceService","TweenService","Debris","Teams","Chat","CollectionService"}) do
            pcall(function()
              local _svc = game:GetService(_n)
              if _svc then
                local _env = getfenv and pcall(getfenv) and getfenv() or _G or {}
                _env[_n] = _svc
              end
            end)
          end
        end
      end
      -- Wrap loadstring/load to propagate REAL_G environment
      -- Needed so script's internal loadstring calls can find functions defined by the script
      -- NOTE: _saved_loadstring and _saved_load MUST be declared BEFORE _loadWrap
      --       because Lua closures capture LOCAL vars by reference. If declared after,
      --       _loadWrap would reference a GLOBAL _saved_loadstring (nil).
      local _saved_loadstring = loadstring
      local _saved_load = load
      local _loadWrap = function(_chunkStr, _chunkName)
        local _ok, _c = pcall(_saved_loadstring, _chunkStr, _chunkName or "@AuroraX")
        if _ok and type(_c) == "function" then
          pcall(function()
            if type(setfenv) == "function" then
              setfenv(_c, _REAL_G)
            end
          end)
          return _c
        end
        return nil
      end
      loadstring = _loadWrap
      load = function(...) local a={...} if a[1] then return _loadWrap(a[1], a[2]) end return nil end
      -- Compile the decoded script
      local _fn = nil
      local _loadOk = false
      if _saved_loadstring then
        _loadOk, _fn = pcall(function() return _loadWrap(${decoded}, "@AuroraX") end)
      end
      if (not _loadOk or type(_fn) ~= "function") and _saved_load then
        _loadOk, _fn = pcall(function() return _saved_load(${decoded}, "@AuroraX") end)
      end
      if not _loadOk or type(_fn) ~= "function" then
        error("Aurora X: script compile failed")
      end
      ${vm} = _fn
      pcall(function() if type(setfenv)=="function" then setfenv(_fn, _REAL_G) end end)
      ${state}=${labels[3]}
    elseif ${state}==${labels[3]} then
      if type(${vm})=="function" then
        local _ok2,_err2=pcall(${vm})
        if not _ok2 then
          warn("[Aurora X] Script error: "..tostring(_err2))
        end
      end
      ${state}=0
    end
  end
end

${run}()
`;

  return output;
}
