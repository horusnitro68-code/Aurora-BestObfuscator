import { obfuscateLua, ObfuscationOptions } from "./luaObfuscator";

export interface ObfuscatorWorkerInput {
  source: string;
  options: ObfuscationOptions;
}

export interface ObfuscatorWorkerProgress {
  type: "progress";
  stage: string;
  percent: number;
}

export interface ObfuscatorWorkerResult {
  type: "done";
  output: string;
}

export interface ObfuscatorWorkerError {
  type: "error";
  message: string;
}

self.onmessage = (event: MessageEvent<ObfuscatorWorkerInput>) => {
  const { source, options } = event.data;

  try {
    self.postMessage({
      type: "progress",
      stage: "Ofuscando...",
      percent: 10,
    } as ObfuscatorWorkerProgress);

    const output = obfuscateLua(source, options);

    self.postMessage({
      type: "progress",
      stage: "Finalizando...",
      percent: 90,
    } as ObfuscatorWorkerProgress);

    self.postMessage({ type: "done", output } as ObfuscatorWorkerResult);
  } catch (error) {
    self.postMessage({
      type: "error",
      message: error instanceof Error ? error.message : "Unknown error",
    } as ObfuscatorWorkerError);
  }
};
