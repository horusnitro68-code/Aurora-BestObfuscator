/**
 * Test file for Aurora X VM String Obfuscation
 * 
 * Tests the luraph-style string obfuscation that fragments string literals
 * into mixed escape sequences (hex, unicode, octal)
 */

import { preprocessStrings } from './luauPreprocessor';

// Test 1: Basic string obfuscation
console.log("=== TEST 1: Basic String Obfuscation ===\n");

const testScript1 = `
local playerName = "Hero123"
local service = "game:GetService"
print("Hello, " .. playerName)
`;

const obfuscated1 = preprocessStrings(testScript1);
console.log("Original:");
console.log(testScript1);
console.log("\nObfuscated:");
console.log(obfuscated1);

// Test 2: Complex script with multiple string types
console.log("\n=== TEST 2: Complex Script ===\n");

const testScript2 = `
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local character = player.Character

if character then
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid then
        print("Player found: " .. player.Name)
        humanoid.WalkSpeed = 16
    end
end

-- String in table
local config = {
    name = "Config",
    version = "1.0",
    author = "Test"
}
`;

const obfuscated2 = preprocessStrings(testScript2);
console.log("Original:");
console.log(testScript2);
console.log("\nObfuscated:");
console.log(obfuscated2);

// Test 3: Edge cases
console.log("\n=== TEST 3: Edge Cases ===\n");

const testScript3 = `
local empty = ""
local single = "A"
local special = "line1\\nline2"
local unicode = "Café"
local mixed = "Hello\\x20World"
`;

const obfuscated3 = preprocessStrings(testScript3);
console.log("Original:");
console.log(testScript3);
console.log("\nObfuscated:");
console.log(obfuscated3);

// Test 4: Comments should not be modified
console.log("\n=== TEST 4: Comments Preserved ===\n");

const testScript4 = `
-- This is a comment with "strings" inside
local x = "real string"
--[[
  Long comment with "strings"
  that should not be modified
]]
local y = "another string"
`;

const obfuscated4 = preprocessStrings(testScript4);
console.log("Original:");
console.log(testScript4);
console.log("\nObfuscated:");
console.log(obfuscated4);

// Test 5: Show the effect of multiple runs (randomness)
console.log("\n=== TEST 5: Randomness Effect ===\n");

const testScript5 = `print("Hello World")`;
console.log("Original: " + testScript5);
console.log("Run 1:    " + preprocessStrings(testScript5));
console.log("Run 2:    " + preprocessStrings(testScript5));
console.log("Run 3:    " + preprocessStrings(testScript5));

console.log("\n=== ALL TESTS COMPLETED ===");
