/**
 * Aurora X VM Obfuscator - Phase 1 (Stack VM)
 *
 * Compiles Lua source into a custom stack-based bytecode, then emits a Lua
 * runtime that interprets the bytecode WITHOUT calling loadstring() on the
 * original source.
 *
 * Supports a subset of Lua 5.1. Falls back to the legacy chunk-based
 * obfuscator for scripts that use unsupported constructs (metatables,
 * coroutines, varargs in complex positions, etc.).
 */

import * as luaparse from "luaparse";
import { preprocessLuau } from "./luauPreprocessor";
export interface VMObfuscationOptions {
  watermark: string;
  controlFlow: boolean;
  keyLength: number;
  chunkSize: number;
  advancedOpcodes: boolean;
  antiDebug: boolean;
  botProtection: boolean;
}

export const VM_DEFAULT_OPTIONS: VMObfuscationOptions = {
  watermark: "Aurora X Obfuscator",
  controlFlow: true,
  keyLength: 256,
  chunkSize: 4096,
  advancedOpcodes: true,
  antiDebug: true,
  botProtection: true,
};

// ---------- Helpers ----------

function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ---------- Opcode Randomization ----------

const NUM_OPCODES = 38; // 0-37

/** Generate a random mapping for opcodes using Fisher-Yates shuffle. */
function generateOpcodeMapping(): number[] {
  const opcodes = Array.from({ length: NUM_OPCODES }, (_, i) => i);
  // Fisher-Yates shuffle
  for (let i = opcodes.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [opcodes[i], opcodes[j]] = [opcodes[j], opcodes[i]];
  }
  return opcodes; // opcodes[original] = shuffled
}

/** Create reverse mapping: shuffled -> original */
function reverseOpcodeMapping(mapping: number[]): number[] {
  const reverse = new Array(mapping.length);
  for (let i = 0; i < mapping.length; i++) {
    reverse[mapping[i]] = i;
  }
  return reverse;
}

function randomBytes(length: number): number[] {
  return Array.from({ length }, () => randomInt(1, 255));
}

/** Write a 32-bit unsigned integer as 4 little-endian bytes. */
function writeU32(out: number[], n: number) {
  out.push(n & 0xff, (n >> 8) & 0xff, (n >> 16) & 0xff, (n >> 24) & 0xff);
}

/** Write an unsigned integer using varint encoding (1-5 bytes). */
function writeVarint(out: number[], n: number) {
  while (n >= 0x80) {
    out.push((n & 0x7f) | 0x80);
    n = Math.floor(n / 128);
  }
  out.push(n & 0x7f);
}

/**
 * Derive independent keys from a master seed using HMAC-like construction.
 * Each key is derived by XORing the seed with a context-specific salt.
 */
function deriveKeys(masterSeed: number[], keyLength: number): {
  bytecodeKey: number[];
  opmapKey: number[];
} {
  // Create two independent keys by XORing seed with different salts
  const salt1 = [0x4F, 0x50, 0x4D, 0x41, 0x50]; // "OPMAP" in hex
  const salt2 = [0x42, 0x59, 0x54, 0x45, 0x43, 0x4F, 0x44, 0x45]; // "BYTECODE" in hex
  
  const bytecodeKey: number[] = [];
  const opmapKey: number[] = [];
  
  for (let i = 0; i < keyLength; i++) {
    const seedByte = masterSeed[i % masterSeed.length];
    bytecodeKey.push(seedByte ^ salt2[i % salt2.length]);
    opmapKey.push(seedByte ^ salt1[i % salt1.length]);
  }
  
  return { bytecodeKey, opmapKey };
}

function xorBytes(data: number[], key: number[]): number[] {
  const res = new Array(data.length);
  for (let i = 0; i < data.length; i++) {
    res[i] = data[i] ^ key[i % key.length];
  }
  return res;
}

// ---------- Runtime Variable Name Randomization ----------

/** Generate random variable names for the runtime */
function generateRuntimeNames(): {
  bytecode: string;    // Was: _D
  opmap: string;       // Was: _OM  
  reverse: string;     // Was: _REVERSE
  key: string;         // Was: _K
  key2: string;        // Was: _K2 (new)
  runner: string;      // Was: _run
  stack: string;       // Was: _S
  sp: string;          // Was: _T
  pc: string;          // Was: _pc
  code: string;        // Was: _C
  constants: string;   // Was: _K (inside proto)
  locals: string;      // Was: _L
  reader: string;      // Was: _N
  decoder: string;      // Was: _decodeProto
  env: string;         // Was: _E
  xorFn: string;       // Was: _xor
  metatable: string;   // Was: _MT
  unpack: string;      // Was: _U
  varargs: string;     // Was: _VA
  isVararg: string;    // Was: _isva
  makeVararg: string;  // Was: _mkva
} {
  const chars = 'IlO0o';
  const genName = () => {
    let name = '_';
    for (let i = 0; i < 6 + Math.floor(Math.random() * 4); i++) {
      name += chars[Math.floor(Math.random() * chars.length)];
    }
    return name;
  };
  
  // Generate unique names
  const names = new Set<string>();
  const unique = () => {
    let n: string;
    do { n = genName(); } while (names.has(n));
    names.add(n);
    return n;
  };
  
  return {
    bytecode: unique(),
    opmap: unique(),
    reverse: unique(),
    key: unique(),
    key2: unique(),
    runner: unique(),
    stack: unique(),
    sp: unique(),
    pc: unique(),
    code: unique(),
    constants: unique(),
    locals: unique(),
    reader: unique(),
    decoder: unique(),
    env: unique(),
    xorFn: unique(),
    metatable: unique(),
    unpack: unique(),
    varargs: unique(),
    isVararg: unique(),
    makeVararg: unique(),
  };
}

function floatToBytes(n: number): number[] {
  const buf = new ArrayBuffer(8);
  // Encode as big-endian to match the Lua decoder loop.
  new DataView(buf).setFloat64(0, n, false);
  return Array.from(new Uint8Array(buf));
}

function bytesToLuaTable(bytes: number[]): string {
  return `{${bytes.join(",")}}`;
}

function bytesToBase64(bytes: number[]): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let result = "";
  const len = bytes.length;
  for (let i = 0; i < len; i += 3) {
    const a = bytes[i];
    const b = i + 1 < len ? bytes[i + 1] : 0;
    const c = i + 2 < len ? bytes[i + 2] : 0;
    result += chars[a >> 2];
    result += chars[((a & 3) << 4) | (b >> 4)];
    result += i + 1 < len ? chars[((b & 15) << 2) | (c >> 6)] : "=";
    result += i + 2 < len ? chars[c & 63] : "=";
  }
  return result;
}

function parseLuaString(raw: string): string {
  if (!raw) return "";
  if (raw.startsWith("[[") && raw.endsWith("]]")) {
    return raw.slice(2, -2);
  }
  if (raw.startsWith("[") && raw.includes("=")) {
    const eqMatch = raw.match(/^\[(=*)\[(.*)\]\1\]$/);
    if (eqMatch) return eqMatch[2];
  }
  const quoted = raw.slice(1, -1);
  return quoted
    .replace(/\\\\/g, "\x00")
    .replace(/\\"/g, '"')
    .replace(/\\'/g, "'")
    .replace(/\\n/g, "\n")
    .replace(/\\t/g, "\t")
    .replace(/\\r/g, "\r")
    .replace(/\\a/g, "\x07")
    .replace(/\\b/g, "\x08")
    .replace(/\\f/g, "\x0c")
    .replace(/\\v/g, "\x0b")
    .replace(/\x00/g, "\\\\");
}

// ---------- Bytecode format ----------

const OpCode = {
  NOP: 0,
  PUSH_K: 1,
  PUSH_LOCAL: 2,
  STORE_LOCAL: 3,
  POP: 4,
  GET_GLOBAL: 5,
  SET_GLOBAL: 6,
  GET_TABLE: 7,
  SET_TABLE: 8,
  NEWTABLE: 9,
  ADD: 10,
  SUB: 11,
  MUL: 12,
  DIV: 13,
  MOD: 14,
  POW: 15,
  CONCAT: 16,
  UNM: 17,
  NOT: 18,
  LEN: 19,
  EQ: 20,
  LT: 21,
  LE: 22,
  JMP: 23,
  JMP_IF: 24,
  JMP_IF_NOT: 25,
  CALL: 26,
  RETURN: 27,
  CLOSURE: 28,
  VARARGS: 29,
  EXPAND_VARARGS: 30,
  CALLM: 31,
  EXPAND_MULTIRET: 32,
  PEEK_JMP_IF: 33,
  PEEK_JMP_IF_NOT: 34,
  DUP: 35,
  SWAP: 36,
  MAKE_CELL: 37,
} as const;
type OpCode = (typeof OpCode)[keyof typeof OpCode];

interface Instruction {
  op: number; // Number after opcode mapping (not OpCode type)
  a: number;
  b: number;
}

interface ConstantValue {
  type: "nil" | "boolean" | "number" | "string";
  value: unknown;
}

interface Proto {
  code: Instruction[];
  constants: ConstantValue[];
  locals: string[];
  numParams: number;
  isVararg: boolean;
  protos: Proto[];
  closureId: number;
  globalNames: string[];  // integer-indexed global name table
  globalNameMap: Map<string, number>; // dedup map for global names (per-proto)
}

class CompilerError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CompilerError";
  }
}

class CompilerCtx {
  proto: Proto;
  protoStack: Proto[] = [];
  localStack: string[][] = [[]];
  breakJumps: number[][] = []; // stack of break JMP positions per loop
  opcodeMap: number[];
  nextClosureId = 1; // root has id 0, children get 1+
  labelDefs = new Map<string, number>(); // label name -> instruction index
  labelJumps = new Map<string, number[]>(); // label name -> list of JMP indices to patch
  constructor(opcodeMap: number[]) {
    this.opcodeMap = opcodeMap;
    this.proto = {
      code: [],
      constants: [],
      locals: [],
      numParams: 0,
      isVararg: true,
      protos: [],
      closureId: 0,
      globalNames: [],
      globalNameMap: new Map(),
    };
  }

  pushProto(params: string[], isVararg: boolean): Proto {
    const p: Proto = {
      code: [],
      constants: [],
      locals: [...params],
      numParams: params.length,
      isVararg,
      protos: [],
      closureId: this.nextClosureId++,
      globalNames: [],
      globalNameMap: new Map(),
    };
    this.protoStack.push(this.proto);
    this.proto = p;
    (this.proto as Proto).globalNameMap = new Map();
    this.localStack.push([...params]);
    return p;
  }

  popProto(): Proto {
    const finished = this.proto;
    this.proto = this.protoStack.pop()!;
    this.localStack.pop();
    this.proto.protos.push(finished);
    return finished;
  }

  emit(op: OpCode, a = 0, b = 0): number {
    const mappedOp = this.opcodeMap[op] ?? op; // Apply opcode mapping
    this.proto.code.push({ op: mappedOp, a, b });
    return this.proto.code.length - 1;
  }

  addConstant(v: ConstantValue): number {
    for (let i = 0; i < this.proto.constants.length; i++) {
      const c = this.proto.constants[i];
      if (c.type === v.type && c.value === v.value) return i;
    }
    this.proto.constants.push(v);
    return this.proto.constants.length - 1;
  }

  declareLocal(name: string): number {
    const locals = this.localStack[this.localStack.length - 1];
    const idx = locals.length;
    locals.push(name);
    if (!this.proto.locals.includes(name)) this.proto.locals.push(name);
    return idx;
  }

  resolveLocal(name: string): number {
    // Only search the CURRENT proto's local frame.
    // Variables from outer scopes are captured into _E and accessed via GET_GLOBAL.
    const currentScope = this.localStack[this.localStack.length - 1];
    for (let j = currentScope.length - 1; j >= 0; j--) {
      if (currentScope[j] === name) return j;
    }
    return -1;
  }

  /**
   * Search outer scopes for a variable and return the unique global key
   * used to capture it for closures. Returns null if not found anywhere.
   */
  resolveOuterCapture(name: string): string | null {
    for (let s = this.localStack.length - 2; s >= 0; s--) {
      const scope = this.localStack[s];
      for (let i = 0; i < scope.length; i++) {
        if (scope[i] === name) {
          return `_AURORA_UPV_${this.proto.closureId}_${name}`;
        }
      }
    }
    return null;
  }

  // Check if a name exists anywhere in any scope (for assignment detection)
  existsInAnyScope(name: string): boolean {
    for (let i = this.localStack.length - 1; i >= 0; i--) {
      if (this.localStack[i].includes(name)) return true;
    }
    return false;
  }

  /** Register a global name and return its integer index */
  registerGlobal(name: string): number {
    const existing = this.proto.globalNameMap.get(name);
    if (existing !== undefined) return existing;
    const idx = this.proto.globalNames.length;
    this.proto.globalNames.push(name);
    this.proto.globalNameMap.set(name, idx);
    return idx;
  }

  /** Emit GET_GLOBAL using integer-indexed global name table */
  emitGetGlobal(name: string): number {
    const gIdx = this.registerGlobal(name);
    return this.emit(OpCode.GET_GLOBAL, gIdx);
  }

  /** Emit SET_GLOBAL using integer-indexed global name table */
  emitSetGlobal(name: string): number {
    const gIdx = this.registerGlobal(name);
    return this.emit(OpCode.SET_GLOBAL, gIdx);
  }
}

// ---------- AST to bytecode compiler ----------

const unsupportedNodes = new Set([
  "DoWhileStatement",
]);

function compileNode(ctx: CompilerCtx, node: luaparse.Node): void {
  if (!node) return;
  if (unsupportedNodes.has(node.type)) {
    throw new CompilerError(`Unsupported Lua construct: ${node.type}`);
  }

  switch (node.type) {
    case "Chunk":
      node.body.forEach((n) => compileNode(ctx, n));
      break;
    case "LocalStatement":
      compileLocalStatement(ctx, node);
      break;
    case "AssignmentStatement":
      compileAssignmentStatement(ctx, node);
      break;
    case "CallStatement":
      compileExpression(ctx, node.expression);
      ctx.emit(OpCode.POP);
      break;
    case "IfStatement":
      compileIfStatement(ctx, node);
      break;
    case "WhileStatement":
      compileWhileStatement(ctx, node);
      break;
    case "RepeatStatement":
      compileRepeatStatement(ctx, node);
      break;
    case "ForGenericStatement":
      compileForGenericStatement(ctx, node);
      break;
    case "ForNumericStatement":
      compileForNumericStatement(ctx, node);
      break;
    case "ReturnStatement":
      compileReturnStatement(ctx, node);
      break;
    case "FunctionDeclaration":
      compileFunctionDeclaration(ctx, node);
      break;
    case "BreakStatement":
      if (ctx.breakJumps.length > 0) {
        ctx.breakJumps[ctx.breakJumps.length - 1].push(ctx.emit(OpCode.JMP, 0, 0));
      } else {
        ctx.emit(OpCode.JMP, 0, 0); // fallback
      }
      break;
    case "DoStatement":
      // do...end blocks are just scope wrappers in Lua
      (node as any).body.forEach((n: luaparse.Node) => compileNode(ctx, n));
      break;
    case "LabelStatement":
      // ::label_name:: - record position and patch any forward gotos
      {
        const labelName = (node as any).label;
        const pos = ctx.proto.code.length; // position AFTER this label (no instruction emitted)
        if (ctx.labelDefs.has(labelName)) {
          throw new CompilerError(`Duplicate label: ${labelName}`);
        }
        ctx.labelDefs.set(labelName, pos);
        // Patch any forward jumps that referenced this label
        const pendingJumps = ctx.labelJumps.get(labelName);
        if (pendingJumps) {
          for (const jmpIdx of pendingJumps) {
            ctx.proto.code[jmpIdx].b = pos + 1; // JMP targets are 1-based in VM
          }
          ctx.labelJumps.delete(labelName);
        }
      }
      break;
    case "GotoStatement":
      // goto label_name - emit JMP, patch now if label exists, else record for later
      {
        const labelName = (node as any).label;
        const existingPos = ctx.labelDefs.get(labelName);
        if (existingPos !== undefined) {
          // Label already defined (backward jump)
          ctx.emit(OpCode.JMP, 0, existingPos + 1);
        } else {
          // Forward jump - record for patching when label is found
          const jmpIdx = ctx.emit(OpCode.JMP, 0, 0);
          if (!ctx.labelJumps.has(labelName)) {
            ctx.labelJumps.set(labelName, []);
          }
          ctx.labelJumps.get(labelName)!.push(jmpIdx);
        }
      }
      break;
    default:
      if (node.type.endsWith("Expression")) {
        compileExpression(ctx, node as luaparse.Expression);
        ctx.emit(OpCode.POP);
      }
      break;
  }
}

function compileLocalStatement(ctx: CompilerCtx, node: luaparse.LocalStatement): void {
  const multiRet = node.variables.length > 1 && node.init[0] && node.init[0].type === "CallExpression";
  if (multiRet) {
    compileExpression(ctx, node.init[0], true);
    ctx.emit(OpCode.EXPAND_MULTIRET, node.variables.length);
    const slots: number[] = [];
    for (let i = 0; i < node.variables.length; i++) {
      const v = node.variables[i];
      if (v.type !== "Identifier") throw new CompilerError("Local variable must be an identifier");
      slots.push(ctx.declareLocal(v.name));
    }
    // EXPAND_MULTIRET pushes values in order (first value at bottom),
    // but STORE_LOCAL pops from the top, so store in reverse order.
    for (let i = slots.length - 1; i >= 0; i--) {
      ctx.emit(OpCode.STORE_LOCAL, slots[i]);
    }
    return;
  }
  for (let i = 0; i < node.variables.length; i++) {
    const v = node.variables[i];
    if (v.type !== "Identifier") throw new CompilerError("Local variable must be an identifier");
    const name = v.name;
    if (node.init[i]) {
      compileExpression(ctx, node.init[i]);
    } else {
      ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "nil", value: null }));
    }
    const slot = ctx.declareLocal(name);
    ctx.emit(OpCode.STORE_LOCAL, slot);
  }
}

function compileAssignmentStatement(ctx: CompilerCtx, node: luaparse.AssignmentStatement): void {
  for (let i = 0; i < node.variables.length; i++) {
    const target = node.variables[i];
    const init = node.init[i];

    if (target.type === "Identifier") {
      compileExpression(ctx, init);
      const slot = ctx.resolveLocal(target.name);
      if (slot >= 0) {
        ctx.emit(OpCode.STORE_LOCAL, slot);
      } else {
        const captureKey = ctx.resolveOuterCapture(target.name);
        if (captureKey) {
          ctx.emitGetGlobal(captureKey);
          ctx.emit(OpCode.SWAP);
          const vIdxUp = ctx.addConstant({ type: "string", value: "v" });
          ctx.emit(OpCode.PUSH_K, vIdxUp);
          ctx.emit(OpCode.SWAP);
          ctx.emit(OpCode.SET_TABLE);
        } else {
          ctx.emitSetGlobal(target.name);
        }
      }
    } else if (target.type === "IndexExpression") {
      compileExpression(ctx, target.base);
      compileExpression(ctx, target.index);
      compileExpression(ctx, init);
      ctx.emit(OpCode.SET_TABLE);
      ctx.emit(OpCode.POP);
    } else if (target.type === "MemberExpression") {
      compileExpression(ctx, target.base);
      const nameIdx = ctx.addConstant({ type: "string", value: target.identifier.name });
      ctx.emit(OpCode.PUSH_K, nameIdx);
      compileExpression(ctx, init);
      ctx.emit(OpCode.SET_TABLE);
      ctx.emit(OpCode.POP);
    }
  }
}

function compileIfStatement(ctx: CompilerCtx, node: luaparse.IfStatement): void {
  const endJumps: number[] = [];
  for (const clause of node.clauses) {
    if (clause.type === "IfClause" || clause.type === "ElseifClause") {
      compileExpression(ctx, clause.condition);
      const falseJump = ctx.emit(OpCode.JMP_IF_NOT, 0);
      clause.body.forEach((n) => compileNode(ctx, n));
      endJumps.push(ctx.emit(OpCode.JMP, 0));
      ctx.proto.code[falseJump].b = ctx.proto.code.length + 1;
    } else if (clause.type === "ElseClause") {
      clause.body.forEach((n) => compileNode(ctx, n));
    }
  }
  const end = ctx.proto.code.length + 1;
  for (const j of endJumps) {
    if (ctx.proto.code[j].b === 0) ctx.proto.code[j].b = end;
  }
}

function compileWhileStatement(ctx: CompilerCtx, node: luaparse.WhileStatement): void {
  const start = ctx.proto.code.length;
  compileExpression(ctx, node.condition);
  const exitJump = ctx.emit(OpCode.JMP_IF_NOT, 0);
  // Push break-jumps context for this loop
  ctx.breakJumps.push([]);
  node.body.forEach((n) => compileNode(ctx, n));
  // Patch all break JMPs to jump past the loop
  const loopEnd = ctx.proto.code.length + 2; // after the JMP back
  const breakJumps = ctx.breakJumps.pop()!;
  for (const bj of breakJumps) {
    ctx.proto.code[bj].b = loopEnd;
  }
  ctx.emit(OpCode.JMP, 0, start + 1);
  ctx.proto.code[exitJump].b = ctx.proto.code.length + 1;
}

function compileRepeatStatement(ctx: CompilerCtx, node: luaparse.RepeatStatement): void {
  const start = ctx.proto.code.length;
  ctx.breakJumps.push([]);
  node.body.forEach((n) => compileNode(ctx, n));
  compileExpression(ctx, node.condition);
  ctx.emit(OpCode.JMP_IF_NOT, 0, start + 1);
  const loopEnd = ctx.proto.code.length + 1;
  const breakJumps = ctx.breakJumps.pop()!;
  for (const bj of breakJumps) {
    ctx.proto.code[bj].b = loopEnd;
  }
}

function compileForGenericStatement(ctx: CompilerCtx, node: luaparse.ForGenericStatement): void {
  // Lua generic for semantics:
  //   for v1, ..., vn in f, s, var do ... end
  // is equivalent to:
  //   do
  //     local f, s, var = <iterators>
  //     while true do
  //       local v1, ..., vn = f(s, var)
  //       var = v1
  //       if var == nil then break end
  //       ...body...
  //     end
  //   end
  //
  // Evaluate iterator expressions. Luau/Roblox scripts often use a single
  // expression such as pairs(t) or next, table. Support both cases.
  const iterCount = node.iterators.length;

  if (iterCount === 1) {
    // A single expression may return multiple values (e.g. pairs(t)).
    compileExpression(ctx, node.iterators[0], true);
    ctx.emit(OpCode.EXPAND_MULTIRET, 3);
  } else {
    // Multiple explicit expressions; pad with nil to 3 values.
    for (let i = 0; i < 3; i++) {
      if (i < iterCount) {
        compileExpression(ctx, node.iterators[i]);
      } else {
        ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "nil", value: null }));
      }
    }
  }

  // Stack now has [f, s, var] with var on top. Store in reverse order.
  const uid = Math.random().toString(36).slice(2, 8);
  const varSlot = ctx.declareLocal("__for_var_" + uid);
  const sSlot = ctx.declareLocal("__for_s_" + uid);
  const fSlot = ctx.declareLocal("__for_f_" + uid);
  ctx.emit(OpCode.STORE_LOCAL, varSlot);
  ctx.emit(OpCode.STORE_LOCAL, sSlot);
  ctx.emit(OpCode.STORE_LOCAL, fSlot);

  const loopStart = ctx.proto.code.length;

  // Push f, s, var and call f(s, var), expecting multiple returns.
  ctx.emit(OpCode.PUSH_LOCAL, fSlot);
  ctx.emit(OpCode.PUSH_LOCAL, sSlot);
  ctx.emit(OpCode.PUSH_LOCAL, varSlot);
  ctx.emit(OpCode.CALLM, 2);
  ctx.emit(OpCode.EXPAND_MULTIRET, node.variables.length);

  // Declare loop variables and store multi-return values in reverse order.
  const varSlots: number[] = [];
  for (const v of node.variables) {
    if (v.type !== "Identifier") throw new CompilerError("For loop variable must be an identifier");
    varSlots.push(ctx.declareLocal(v.name));
  }
  for (let i = varSlots.length - 1; i >= 0; i--) {
    ctx.emit(OpCode.STORE_LOCAL, varSlots[i]);
  }

  // var = v1
  ctx.emit(OpCode.PUSH_LOCAL, varSlots[0]);
  ctx.emit(OpCode.STORE_LOCAL, varSlot);

  // if v1 == nil then break end
  ctx.emit(OpCode.PUSH_LOCAL, varSlots[0]);
  ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "nil", value: null }));
  ctx.emit(OpCode.EQ);
  const exitJump = ctx.emit(OpCode.JMP_IF, 0);

  ctx.breakJumps.push([]);
  node.body.forEach((n) => compileNode(ctx, n));
  const loopEnd = ctx.proto.code.length + 2;
  const breakJumps = ctx.breakJumps.pop()!;
  for (const bj of breakJumps) {
    ctx.proto.code[bj].b = loopEnd;
  }
  ctx.emit(OpCode.JMP, 0, loopStart + 1);
  ctx.proto.code[exitJump].b = ctx.proto.code.length + 1;
}

function compileForNumericStatement(ctx: CompilerCtx, node: luaparse.ForNumericStatement): void {
  if (node.variable.type !== "Identifier") throw new CompilerError("Numeric for variable must be an identifier");
  const varName = node.variable.name;
  const startSlot = ctx.declareLocal(varName);
  const limitSlot = ctx.declareLocal("__lim_" + varName);
  const stepSlot = ctx.declareLocal("__step_" + varName);

  compileExpression(ctx, node.start);
  ctx.emit(OpCode.STORE_LOCAL, startSlot);
  compileExpression(ctx, node.end);
  ctx.emit(OpCode.STORE_LOCAL, limitSlot);
  if (node.step) {
    compileExpression(ctx, node.step);
  } else {
    ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "number", value: 1 }));
  }
  ctx.emit(OpCode.STORE_LOCAL, stepSlot);

  const loopStart = ctx.proto.code.length;
  ctx.emit(OpCode.PUSH_LOCAL, startSlot);
  ctx.emit(OpCode.PUSH_LOCAL, limitSlot);
  ctx.emit(OpCode.LE);
  const exitJump = ctx.emit(OpCode.JMP_IF_NOT, 0);

  ctx.breakJumps.push([]);
  node.body.forEach((n) => compileNode(ctx, n));

  ctx.emit(OpCode.PUSH_LOCAL, startSlot);
  ctx.emit(OpCode.PUSH_LOCAL, stepSlot);
  ctx.emit(OpCode.ADD);
  ctx.emit(OpCode.STORE_LOCAL, startSlot);
  ctx.emit(OpCode.JMP, 0, loopStart + 1);
  const loopEnd = ctx.proto.code.length + 1;
  const breakJumps = ctx.breakJumps.pop()!;
  for (const bj of breakJumps) {
    ctx.proto.code[bj].b = loopEnd;
  }
  ctx.proto.code[exitJump].b = ctx.proto.code.length + 1;
}

function compileReturnStatement(ctx: CompilerCtx, node: luaparse.ReturnStatement): void {
  let varargs = false;
  for (let i = 0; i < node.arguments.length; i++) {
    const arg = node.arguments[i];
    if (arg.type === "VarargLiteral") {
      if (i !== node.arguments.length - 1) {
        throw new CompilerError("VarargLiteral must be the last return argument");
      }
      ctx.emit(OpCode.VARARGS, 1);
      varargs = true;
    } else if (arg.type === "CallExpression") {
      compileExpression(ctx, arg, true);
    } else {
      compileExpression(ctx, arg);
    }
  }
  ctx.emit(OpCode.RETURN, node.arguments.length, varargs ? 1 : 0);
}

function compileFunctionDeclaration(ctx: CompilerCtx, node: luaparse.FunctionDeclaration): void {
  let params = node.parameters
    .filter((p) => p.type === "Identifier")
    .map((p) => (p as luaparse.Identifier).name);
  // luaparse doesn't include 'self' for method syntax (function Table:Method())
  // but the caller passes self as first arg, so we must add it
  const isMethod = node.identifier && node.identifier.type === "MemberExpression" && (node.identifier as any).indexer === ":";
  if (isMethod) {
    params = ["self", ...params];
  }
  ctx.pushProto(params, true);
  node.body.forEach((n) => compileNode(ctx, n));
  if (ctx.proto.code.length === 0 || ctx.proto.code[ctx.proto.code.length - 1].op !== OpCode.RETURN) {
    ctx.emit(OpCode.RETURN, 0);
  }
  const finished = ctx.popProto();

  // Capture ALL ancestor-scope locals into _E so inner functions can access them via GET_GLOBAL.
  // This is transitive: if C uses a var from A (skipping B), all intermediate scopes
  // must also capture and re-export it so the chain of globals is complete.
  const allAncestorLocals: string[] = [];
  for (let s = 0; s < ctx.localStack.length; s++) {
    for (const name of ctx.localStack[s]) {
      if (!allAncestorLocals.includes(name)) {
        allAncestorLocals.push(name);
      }
    }
  }
  for (let i = 0; i < allAncestorLocals.length; i++) {
    const capName = allAncestorLocals[i];
    const captureKey = `_AURORA_UPV_${finished.closureId}_${capName}`;
    let foundIdx = -1;
    let foundScope = -1;
    for (let s = ctx.localStack.length - 1; s >= 0; s--) {
      const idx = ctx.localStack[s].indexOf(capName);
      if (idx !== -1) { foundIdx = idx; foundScope = s; break; }
    }
    if (foundIdx !== -1 && foundIdx < (ctx.localStack[ctx.localStack.length - 1] || []).indexOf(capName) + 1) {
      ctx.emit(OpCode.PUSH_LOCAL, foundIdx);
      ctx.emit(OpCode.MAKE_CELL);
      ctx.emitSetGlobal(captureKey);
    } else {
      const ancestorKey = `_AURORA_UPV_${ctx.proto.closureId}_${capName}`;
      ctx.emitGetGlobal(ancestorKey);
      ctx.emit(OpCode.MAKE_CELL);
      ctx.emitSetGlobal(captureKey);
    }
  }

  // For MemberExpression (function Table:Method()), emit CLOSURE AFTER table+key
  // so stack is [table, key, function] which SET_TABLE expects
  if (node.identifier && node.identifier.type === "MemberExpression") {
    const memberExpr = node.identifier as any;
    compileExpression(ctx, memberExpr.base);
    const methodName = memberExpr.identifier ? memberExpr.identifier.name : (memberExpr.property && memberExpr.property.name) || "";
    const nameIdx = ctx.addConstant({ type: "string", value: methodName });
    ctx.emit(OpCode.PUSH_K, nameIdx);
    ctx.emit(OpCode.CLOSURE, ctx.proto.protos.length - 1);
    ctx.emit(OpCode.SET_TABLE);
    ctx.emit(OpCode.POP);
  } else {
    ctx.emit(OpCode.CLOSURE, ctx.proto.protos.length - 1);
    if (node.isLocal && node.identifier && node.identifier.type === "Identifier") {
      const slot = ctx.declareLocal(node.identifier.name);
      ctx.emit(OpCode.STORE_LOCAL, slot);
    } else if (node.identifier && node.identifier.type === "Identifier") {
      ctx.emitSetGlobal(node.identifier.name);
    } else {
      ctx.emit(OpCode.POP);
    }
  }
}

function compileExpression(ctx: CompilerCtx, expr: luaparse.Expression | null, multiReturn = false): void {
  if (!expr) {
    ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "nil", value: null }));
    return;
  }

  switch (expr.type) {
    case "NilLiteral":
      ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "nil", value: null }));
      break;
    case "BooleanLiteral":
      ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "boolean", value: expr.value }));
      break;
    case "NumericLiteral":
      ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "number", value: expr.value }));
      break;
    case "StringLiteral":
      {
        const s = typeof expr.value === "string" ? expr.value : parseLuaString((expr as any).raw);
        ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "string", value: s }));
      }
      break;
    case "Identifier":
      {
        const slot = ctx.resolveLocal(expr.name);
        if (slot >= 0) {
          ctx.emit(OpCode.PUSH_LOCAL, slot);
        } else {
          const captureKey = ctx.resolveOuterCapture(expr.name);
          if (captureKey) {
            ctx.emitGetGlobal(captureKey);
            const vIdx = ctx.addConstant({ type: "string", value: "v" });
            ctx.emit(OpCode.PUSH_K, vIdx);
            ctx.emit(OpCode.GET_TABLE);
          } else {
            ctx.emitGetGlobal(expr.name);
          }
        }
      }
      break;
    case "VarargLiteral":
      ctx.emit(OpCode.VARARGS, 0);
      break;
    case "TableConstructorExpression":
      compileTable(ctx, expr);
      break;
    case "BinaryExpression":
      compileBinaryExpression(ctx, expr);
      break;
    case "LogicalExpression":
      compileLogicalExpression(ctx, expr);
      break;
    case "UnaryExpression":
      compileUnaryExpression(ctx, expr);
      break;
    case "IndexExpression":
      compileExpression(ctx, expr.base);
      compileExpression(ctx, expr.index);
      ctx.emit(OpCode.GET_TABLE);
      break;
    case "MemberExpression":
      compileExpression(ctx, expr.base);
      {
        const nameIdx = ctx.addConstant({
          type: "string",
          value: expr.identifier.name,
        });
        ctx.emit(OpCode.PUSH_K, nameIdx);
      }
      ctx.emit(OpCode.GET_TABLE);
      break;
    case "CallExpression":
      compileCallExpression(ctx, expr, multiReturn);
      break;
    case "TableCallExpression":
      {
        // f{...} is sugar for f({...})
        const e = expr as any;
        compileExpression(ctx, e.base);
        ctx.emit(OpCode.NEWTABLE);
        let i = 1;
        for (const field of (e.fields || [])) {
          if (field.type === "TableKey") {
            compileExpression(ctx, field.key);
            compileExpression(ctx, field.value);
            ctx.emit(OpCode.SET_TABLE);
          } else if (field.type === "TableKeyString") {
            const keyIdx = ctx.addConstant({ type: "string", value: field.key.name });
            ctx.emit(OpCode.PUSH_K, keyIdx);
            compileExpression(ctx, field.value);
            ctx.emit(OpCode.SET_TABLE);
          } else {
            ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "number", value: i++ }));
            compileExpression(ctx, field.value);
            ctx.emit(OpCode.SET_TABLE);
          }
        }
        ctx.emit(OpCode.CALL, 1, 0);
      }
      break;
    case "StringCallExpression":
      {
        // f"..." is sugar for f("...")
        const e = expr as any;
        compileExpression(ctx, e.base);
        const s = (e.argument.value || parseLuaString(e.argument.raw)) as string;
        const idx = ctx.addConstant({ type: "string", value: s });
        ctx.emit(OpCode.PUSH_K, idx);
        ctx.emit(OpCode.CALL, 1, 0);
      }
      break;
    case "FunctionDeclaration":
      {
        let params = expr.parameters
          .filter((p) => p.type === "Identifier")
          .map((p) => (p as luaparse.Identifier).name);
        const isMethodExpr = expr.identifier && (expr as any).identifier.type === "MemberExpression" && (expr as any).identifier.indexer === ":";
        if (isMethodExpr) params = ["self", ...params];
        ctx.pushProto(params, expr.isLocal);
        expr.body.forEach((n) => compileNode(ctx, n));
        if (ctx.proto.code.length === 0 || ctx.proto.code[ctx.proto.code.length - 1].op !== OpCode.RETURN) {
          ctx.emit(OpCode.RETURN, 0);
        }
        const finishedExpr = ctx.popProto();
        // Capture ALL ancestor-scope locals into _E for transitive closure access
        const allAncestorLocalsExpr: string[] = [];
        for (let s = 0; s < ctx.localStack.length; s++) {
          for (const name of ctx.localStack[s]) {
            if (!allAncestorLocalsExpr.includes(name)) {
              allAncestorLocalsExpr.push(name);
            }
          }
        }
        for (let i = 0; i < allAncestorLocalsExpr.length; i++) {
          const capName = allAncestorLocalsExpr[i];
          const captureKey = `_AURORA_UPV_${finishedExpr.closureId}_${capName}`;
          const capNameIdx = ctx.addConstant({ type: "string", value: captureKey });
          let foundIdx = -1;
          for (let s = ctx.localStack.length - 1; s >= 0; s--) {
            const idx = ctx.localStack[s].indexOf(capName);
            if (idx !== -1) { foundIdx = idx; break; }
          }
          if (foundIdx !== -1 && foundIdx < (ctx.localStack[ctx.localStack.length - 1] || []).indexOf(capName) + 1) {
            ctx.emit(OpCode.PUSH_LOCAL, foundIdx);
            ctx.emit(OpCode.MAKE_CELL);
            ctx.emitSetGlobal(captureKey);
          } else {
            const ancestorKey = `_AURORA_UPV_${ctx.proto.closureId}_${capName}`;
            ctx.emitGetGlobal(ancestorKey);
            ctx.emit(OpCode.MAKE_CELL);
            ctx.emitSetGlobal(captureKey);
          }
        }
        ctx.emit(OpCode.CLOSURE, ctx.proto.protos.length - 1);
      }
      break;
    default:
      throw new CompilerError(`Unsupported expression: ${(expr as any).type}`);
  }
}

function compileBinaryExpression(ctx: CompilerCtx, expr: luaparse.BinaryExpression): void {
  // For relational operators, we may need to swap operands or invert.
  const opMap: Record<string, OpCode> = {
    "+": OpCode.ADD,
    "-": OpCode.SUB,
    "*": OpCode.MUL,
    "/": OpCode.DIV,
    "%": OpCode.MOD,
    "^": OpCode.POW,
    "==": OpCode.EQ,
    "<": OpCode.LT,
    "<=": OpCode.LE,
    ">": OpCode.LT,
    ">=": OpCode.LE,
    "..": OpCode.CONCAT,
  };

  if (opMap[expr.operator]) {
    const operator = expr.operator;
    if (operator === ">" || operator === ">=") {
      // a > b  => b < a;  a >= b => b <= a
      compileExpression(ctx, expr.right);
      compileExpression(ctx, expr.left);
    } else {
      compileExpression(ctx, expr.left);
      compileExpression(ctx, expr.right);
    }
    if (operator === "~=") {
      ctx.emit(OpCode.EQ);
      ctx.emit(OpCode.NOT);
    } else {
      ctx.emit(opMap[operator]);
    }
  } else if (expr.operator === "~=") {
    compileExpression(ctx, expr.left);
    compileExpression(ctx, expr.right);
    ctx.emit(OpCode.EQ);
    ctx.emit(OpCode.NOT);
  } else {
    throw new CompilerError(`Unsupported binary operator: ${expr.operator}`);
  }
}

function compileLogicalExpression(ctx: CompilerCtx, expr: luaparse.LogicalExpression): void {
  compileExpression(ctx, expr.left);
  const jumpOp = expr.operator === "and" ? OpCode.PEEK_JMP_IF_NOT : OpCode.PEEK_JMP_IF;
  const skip = ctx.emit(jumpOp, 0);
  ctx.emit(OpCode.POP);
  compileExpression(ctx, expr.right);
  ctx.proto.code[skip].b = ctx.proto.code.length + 1;
}

function compileUnaryExpression(ctx: CompilerCtx, expr: luaparse.UnaryExpression): void {
  compileExpression(ctx, expr.argument);
  const opMap: Record<string, OpCode> = {
    "-": OpCode.UNM,
    not: OpCode.NOT,
    "#": OpCode.LEN,
  };
  if (opMap[expr.operator]) {
    ctx.emit(opMap[expr.operator]);
  } else {
    throw new CompilerError(`Unsupported unary operator: ${expr.operator}`);
  }
}

function compileTable(ctx: CompilerCtx, expr: luaparse.TableConstructorExpression): void {
  ctx.emit(OpCode.NEWTABLE);
  let i = 1;
  for (const field of expr.fields) {
    if (field.type === "TableKey") {
      compileExpression(ctx, field.key);
      compileExpression(ctx, field.value);
      ctx.emit(OpCode.SET_TABLE);
    } else if (field.type === "TableKeyString") {
      const keyIdx = ctx.addConstant({ type: "string", value: field.key.name });
      ctx.emit(OpCode.PUSH_K, keyIdx);
      compileExpression(ctx, field.value);
      ctx.emit(OpCode.SET_TABLE);
    } else {
      if (field.value.type === "VarargLiteral") {
        ctx.emit(OpCode.VARARGS, 1);
        ctx.emit(OpCode.EXPAND_VARARGS);
      } else {
        ctx.emit(OpCode.PUSH_K, ctx.addConstant({ type: "number", value: i++ }));
        compileExpression(ctx, field.value);
        ctx.emit(OpCode.SET_TABLE);
      }
    }
  }
}

function compileCallExpression(ctx: CompilerCtx, expr: luaparse.CallExpression, multiReturn = false): void {
  const isMethod = expr.base.type === "MemberExpression" && (expr.base as any).indexer === ":";
  if (isMethod) {
    // Method call a:b(c) -> compile a, DUP, push "b", GET_TABLE, SWAP, push args, CALL
    compileExpression(ctx, (expr.base as any).base);
    ctx.emit(OpCode.DUP);
    const nameIdx = ctx.addConstant({ type: "string", value: (expr.base as any).identifier.name });
    ctx.emit(OpCode.PUSH_K, nameIdx);
    ctx.emit(OpCode.GET_TABLE);
    ctx.emit(OpCode.SWAP);
  } else {
    compileExpression(ctx, expr.base);
  }
  let varargs = false;
  let multiret = false;
  for (let i = 0; i < expr.arguments.length; i++) {
    const arg = expr.arguments[i];
    const isLast = i === expr.arguments.length - 1;
    if (arg.type === "VarargLiteral") {
      if (!isLast) {
        throw new CompilerError("VarargLiteral must be the last call argument");
      }
      ctx.emit(OpCode.VARARGS, 1);
      varargs = true;
    } else if (isLast && arg.type === "CallExpression") {
      compileExpression(ctx, arg, true);
      multiret = true;
    } else {
      compileExpression(ctx, arg);
    }
  }
  const argCount = expr.arguments.length + (isMethod ? 1 : 0);
  const mode = (varargs ? 1 : 0) | (multiret ? 2 : 0);
  ctx.emit(multiReturn ? OpCode.CALLM : OpCode.CALL, argCount, mode);
}

// ---------- Serialization ----------

function encodeConstant(c: ConstantValue): number[] {
  switch (c.type) {
    case "nil":
      return [0];
    case "boolean":
      return [1, c.value === true ? 1 : 0];
    case "number":
      {
        // Store numbers as strings and use tonumber at runtime to avoid
        // needing to convert IEEE-754 bytes back to Lua numbers.
        const s = (c.value as number).toString();
        const b = Array.from(new TextEncoder().encode(s));
        return [2, b.length & 0xff, (b.length >> 8) & 0xff, ...b];
      }
    case "string":
      {
        const raw = Array.from(new TextEncoder().encode(c.value as string));
        const b = raw.map((byte, i) => byte ^ ((0x6B + i * 0x9D) & 0xFF));
        return [3, b.length & 0xff, (b.length >> 8) & 0xff, ...b];
      }
  }
}

function encodeProto(proto: Proto): number[] {
  const out: number[] = [];
  // numParams as uint32 little-endian
  writeU32(out, proto.numParams);
  out.push(proto.isVararg ? 1 : 0);
  // constants count (uint32)
  writeU32(out, proto.constants.length);
  for (const c of proto.constants) {
    out.push(...encodeConstant(c));
  }
  // global names count (uint32)
  writeU32(out, (proto.globalNames || []).length);
  for (const gn of (proto.globalNames || [])) {
    const b = Array.from(new TextEncoder().encode(gn));
    writeU32(out, b.length);
    out.push(...b);
  }
  // code: op(1 byte), a(uint32), b(uint32)
  writeU32(out, proto.code.length);
  for (const ins of proto.code) {
    out.push(ins.op & 0xff);
    writeVarint(out, ins.a);
    writeVarint(out, ins.b);
  }
  // child protos count (uint32)
  writeU32(out, proto.protos.length);
  for (const p of proto.protos) {
    out.push(...encodeProto(p));
  }
  return out;
}

// ---------- Lua VM runtime (inlined) ----------

// Part 1: Helper functions (no dependency on _REVERSE)
const VM_RUNTIME_HELPERS = `local _U=unpack or table.unpack
if not _U then _U=function(t,i,j) i=i or 1;j=j or #t;local r={};for k=i,j do r[#r+1]=t[k] end;local n=#r;return r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8],r[9],r[10] end end
local _E
local _MT={}
local _RSM=setmetatable
local function _setmetatable(t,mt) _MT[t]=mt; if setmetatable then pcall(setmetatable,t,mt) end; return t end
local function _getmetatable(t)
  local _ok,_mt=pcall(getmetatable,t)
  if _ok and _mt~=nil then return _mt end
  for _k,_v in pairs(_MT) do
    if _k==t then return _v end
  end
  return nil
end
local _loadstring=loadstring
local _load=load
local _VA={}
local function _mkva(_V)
  local _t={__va=true}
  for _=1,#_V do _t[_]=_V[_] end
  return _t
end
local function _isva(_v) return type(_v)=="table" and _v.__va end
`;

// Part 2: The _run interpreter function (depends on _REVERSE being defined BEFORE this)
const VM_RUNTIME_RUN = `local function _run(_P,_A,_V)
  local _C=_P.c
  local _K=_P.k
  local _L={}
  local _nL=_P.l or 0
  for _=1,_nL do _L[_]=nil end
  if _A then for _=1,#_A do _L[_]=_A[_] end end
  if _V==nil then _V={} end
  local _S={}
  local _T=0
  local _pc=1
  local _ic=0
  while true do
    _ic=_ic+1
    if _ic>2000000 then error("[Aurora VM] Watchdog timeout at pc=".._pc.." op=".._o,0) end
    if _ic%1000==0 then local _Y=task and task.wait;if _Y then pcall(_Y,0) end end
    local _i=_C[_pc]
    if _i==nil then break end
    local _o=_REVERSE[_i[1]] or _i[1]
    local _jmp=false
    if _o==1 then local _cv=_K[_i[2]+1];if type(_cv)=="table" and _cv.__nil then _cv=nil end;_T=_T+1;_S[_T]=_cv
    elseif _o==2 then _T=_T+1;_S[_T]=_L[_i[2]+1]
    elseif _o==3 then _L[_i[2]+1]=_S[_T];_T=_T-1
    elseif _o==4 then _T=_T-1
elseif _o==5 then local _gnname=(_P.gn and _P.gn[_i[2]+1]) or _K[_i[2]+1];_lastGlobal=_gnname;table.insert(_globalTrace,_gnname);if #_globalTrace>5 then table.remove(_globalTrace,1) end;local _gn=_gnname;local _gv=_E[_gn];if _gv==nil then local _gok1,_grv1=pcall(function() return _REAL_ENV[_gn] end);if _gok1 and _grv1~=nil then _gv=_grv1 end end;if _gv==nil then local _gok2,_grv2=pcall(function() return shared[_gn] end);if _gok2 and _grv2~=nil then _gv=_grv2 end end;if _gv==nil then local _gok3,_grv3=pcall(function() return game:GetService(_gn) end);if _gok3 and _grv3~=nil then _gv=_grv3 end end;_T=_T+1;_S[_T]=_gv
elseif _o==6 then local _gn=(_P.gn and _P.gn[_i[2]+1]) or _K[_i[2]+1];_E[_gn]=_S[_T];pcall(function() _REAL_ENV[_gn]=_S[_T] end);pcall(function() if shared then shared[_gn]=_S[_T] end end);_T=_T-1
    elseif _o==7 then local _k=_S[_T];_T=_T-1;local _t=_S[_T];_T=_T-1;local _r,_m;local _ok,_rr=pcall(function() return _t[_k] end); if _ok then _r=_rr else _r=nil end;if _r==nil then _m=_MT[_t];if _m and _m.__index then if type(_m.__index)=="function" then _r=_m.__index(_t,_k) else _r=_m.__index[_k] end end end;_T=_T+1;_S[_T]=_r
    elseif _o==8 then local _v=_S[_T];_T=_T-1;local _k=_S[_T];_T=_T-1;local _t=_S[_T];local _m=_MT[_t];if _m and _m.__newindex then if type(_m.__newindex)=="function" then _m.__newindex(_t,_k,_v) else _m.__newindex[_k]=_v end else _t[_k]=_v end
    elseif _o==9 then _T=_T+1;_S[_T]={}
    elseif _o==10 then _S[_T-1]=_S[_T-1]+_S[_T];_T=_T-1
    elseif _o==11 then _S[_T-1]=_S[_T-1]-_S[_T];_T=_T-1
    elseif _o==12 then _S[_T-1]=_S[_T-1]*_S[_T];_T=_T-1
    elseif _o==13 then _S[_T-1]=_S[_T-1]/_S[_T];_T=_T-1
    elseif _o==14 then _S[_T-1]=_S[_T-1]%_S[_T];_T=_T-1
    elseif _o==15 then _S[_T-1]=_S[_T-1]^_S[_T];_T=_T-1
    elseif _o==16 then _S[_T-1]=_S[_T-1].._S[_T];_T=_T-1
    elseif _o==17 then _S[_T]=-_S[_T]
    elseif _o==18 then _S[_T]=not _S[_T]
    elseif _o==19 then _S[_T]=#_S[_T]
    elseif _o==20 then _S[_T-1]=_S[_T-1]==_S[_T];_T=_T-1
    elseif _o==21 then _S[_T-1]=_S[_T-1]<_S[_T];_T=_T-1
    elseif _o==22 then _S[_T-1]=_S[_T-1]<=_S[_T];_T=_T-1
    elseif _o==23 then _pc=_i[3];_jmp=true
    elseif _o==24 then if _S[_T] then _pc=_i[3];_jmp=true end;_T=_T-1
    elseif _o==25 then if not _S[_T] then _pc=_i[3];_jmp=true end;_T=_T-1
    elseif _o==33 then if _S[_T] then _pc=_i[3];_jmp=true end
    elseif _o==34 then if not _S[_T] then _pc=_i[3];_jmp=true end
    elseif _o==35 then _T=_T+1;_S[_T]=_S[_T-1]
    elseif _o==36 then local _x=_S[_T];_S[_T]=_S[_T-1];_S[_T-1]=_x
    elseif _o==37 then _S[_T]={v=_S[_T]}
    elseif _o==26 or _o==31 then
      local _n=_i[2]
      local _a={}
      for _=1,_n do _a[_]=_S[_T-_n+_] end
      _T=_T-_n
      local _expand=_i[3]
      if _expand>0 and _n>0 and _isva(_a[_n]) then
        local _va=_a[_n];_a[_n]=nil
        for _=1,#_va do table.insert(_a,_va[_]) end
      end
      local _f=_S[_T];_T=_T-1
      if _f==nil then error("[Aurora VM] Attempt to call nil at pc=".._pc.." op=".._o.." stackTop=".._T.." lastGlobal="..tostring(_lastGlobal).." nArgs=".._n.." flags=".._expand.." insOp=".._i[1].." insA=".._i[2].." insB=".._i[3].." trace="..table.concat(_globalTrace,",")..")") end
      if type(_f)~="function" then warn("[Aurora VM] CALL non-function at pc=".._pc.." op=".._o.." type="..type(_f).." lastGlobal="..tostring(_lastGlobal).." value="..tostring(_f)) end
      local _t0=os.clock()
      local _r={_f(_U(_a))}
      if os.clock()-_t0>0.005 then _ic=0 end
      if _o==31 then
        _T=_T+1;_S[_T]=_mkva(_r)
      else
        _T=_T+1;_S[_T]=_r[1]
      end
    elseif _o==27 then
      local _n=_i[2]
      local _r={}
      for _=1,_n do _r[_]=_S[_T-_n+_] end
      if _n>0 and _isva(_r[_n]) then
        local _va=_r[_n]
        _r[_n]=nil
        for _=1,#_va do table.insert(_r,_va[_]) end
      end
      _ret=_r;_returned=true;return true
    elseif _o==32 then
      local _n=_i[2]
      local _m=_S[_T]
      _T=_T-1
      for _=1,_n do
        if _m and _m[_]~=nil then
          _T=_T+1;_S[_T]=_m[_]
        else
          _T=_T+1;_S[_T]=nil
        end
      end
    elseif _o==28 then
      local _p=_P.p[_i[2]+1]
      _T=_T+1;_S[_T]=function(...)
        local _a={...}
        local _va={}
        for _=_p.n+1,#_a do _va[_-_p.n]=_a[_] end
        local _r=_run(_p,_a,_va)
        if _r then return _U(_r) end
      end
    elseif _o==29 then
      if _i[2]==1 then
        _T=_T+1;_S[_T]=_mkva(_V)
      else
        _T=_T+1;_S[_T]=_V[1]
      end
    elseif _o==30 then
      local _t=_S[_T]
      for _=1,#_V do _t[#_t+1]=_V[_] end
    end
    if not _jmp then _pc=_pc+1 end
  end
end
`;

// ---------- Dead Code Injection (luraph-style) ----------

/** Generate a random junk name that looks like a real variable */
function generateJunkName(): string {
  const prefixes = ['_m', '_f', '_g', '_h', '_j', '_k', '_l', '_n', '_r', '_s', '_t', '_v', '_w', '_x', '_y', '_z'];
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  let suffix = '';
  const len = 3 + Math.floor(Math.random() * 5);
  for (let i = 0; i < len; i++) {
    const chars = 'IlO0oO0Il';
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return prefix + suffix;
}

/** Generate fake dead code Lua blocks that are never executed */
function generateDeadCode(): string {
  const blocks: string[] = [];
  const numBlocks = 3 + Math.floor(Math.random() * 4);
  for (let i = 0; i < numBlocks; i++) {
    const name = generateJunkName();
    const name2 = generateJunkName();
    const name3 = generateJunkName();
    const patterns = [
      // Dead function with misleading name
      `local function ${name}(_a,_b,_c) if _a and _b then return _c or ${name2}(_a) end end`,
      // Dead variable assignment
      `local ${name}=${name2} and ${name3} or nil`,
      // Dead conditional that never executes
      `if false then local ${name}=function() return ${name2} end end`,
      // Fake metamethod setup
      `do local _t={} function _t:__index(_k) return ${name} end end`,
      // Dead loop that's optimized away
      `for ${name}=1,0 do ${name2}=${name3} end`,
      // Fake closure capture
      `local function ${name}() local _x=0 return function() _x=_x+1 return _x end end`,
      // Dead table constructor
      `local ${name}={["${name2}"]=${name3},["x"]=nil}`,
    ];
    blocks.push(patterns[i % patterns.length]);
  }
  return blocks.join('\n');
}

/** Generate misleading global variable names */
function generateMisleadingGlobals(): string {
  const names = [
    generateJunkName(), generateJunkName(), generateJunkName(),
    generateJunkName(), generateJunkName(), generateJunkName(),
  ];
  return names.map(n => `rawset(_E,"${n}",${Math.random() > 0.5 ? 'nil' : 'function() end'})`).join('\n');
}

/** Generate opaque predicates */
function generateOpaquePredicates(): string {
  const p: string[] = [];
  for (let i = 0; i < 3; i++) {
    const a = generateJunkName();
    const b = generateJunkName();
    p.push("if false then local " + a + "=" + b + " end");
  }
  return p.join("\n");
}

// ---------- Multi-handler VM Dispatch (luraph-style) ----------

// Split the single _run while-true loop into multiple handler functions
// This makes reverse engineering significantly harder
const VM_MULTI_HANDLER_RUNTIME = `local function _run(_P,_A,_V)
  local _C=_P.c
  local _K=_P.k
  local _L={}
  local _nL=_P.l or 0
  for _=1,_nL do _L[_]=nil end
  if _A then for _=1,#_A do _L[_]=_A[_] end end
  if _V==nil then _V={} end
  local _S={}
  local _T=0
  local _pc=1
  local _ic=0
  local _h1,_h2,_h3,_h4,_h5,_h6,_h7,_h8
  local _ret=nil;local _returned=false
  local _lastGlobal=""
  local _globalTrace={}
  _h1=function(_o,_i)
    if _o==1 then local _cv=_K[_i[2]+1];if type(_cv)=="table" and _cv.__nil then _cv=nil end;_T=_T+1;_S[_T]=_cv
    elseif _o==2 then _T=_T+1;_S[_T]=_L[_i[2]+1]
    elseif _o==3 then _L[_i[2]+1]=_S[_T];_T=_T-1
    elseif _o==4 then _T=_T-1
    elseif _o==9 then _T=_T+1;_S[_T]={}
    elseif _o==35 then _T=_T+1;_S[_T]=_S[_T-1]
    elseif _o==36 then local _x=_S[_T];_S[_T]=_S[_T-1];_S[_T-1]=_x
    elseif _o==37 then _S[_T]={v=_S[_T]}
    else return false end
    return true
  end
  _h2=function(_o,_i)
    if _o==5 then local _gnname=(_P.gn and _P.gn[_i[2]+1]) or _K[_i[2]+1];_lastGlobal=_gnname;table.insert(_globalTrace,_gnname);if #_globalTrace>5 then table.remove(_globalTrace,1) end;local _gn=_gnname;local _gv=_E[_gn];if _gv==nil then local _gok3,_grv3=pcall(function() return game:GetService(_gn) end);if _gok3 and _grv3~=nil then _gv=_grv3 end end;_T=_T+1;_S[_T]=_gv
    elseif _o==6 then local _gn=(_P.gn and _P.gn[_i[2]+1]) or _K[_i[2]+1];_E[_gn]=_S[_T];pcall(function() _REAL_ENV[_gn]=_S[_T] end);pcall(function() if shared then shared[_gn]=_S[_T] end end);_T=_T-1
    else return false end
    return true
  end
  _h3=function(_o,_i)
    if _o==7 then local _k=_S[_T];_T=_T-1;local _t=_S[_T];_T=_T-1;local _r,_m;local _ok,_rr=pcall(function() return _t[_k] end); if _ok then _r=_rr else _r=nil end;if _r==nil then _m=_MT[_t];if _m and _m.__index then if type(_m.__index)=="function" then _r=_m.__index(_t,_k) else _r=_m.__index[_k] end end end;_T=_T+1;_S[_T]=_r
    elseif _o==8 then local _v=_S[_T];_T=_T-1;local _k=_S[_T];_T=_T-1;local _t=_S[_T];local _m=_MT[_t];if _m and _m.__newindex then if type(_m.__newindex)=="function" then _m.__newindex(_t,_k,_v) else _m.__newindex[_k]=_v end else _t[_k]=_v end
    else return false end
    return true
  end
  _h4=function(_o,_i)
    if _o==10 then _S[_T-1]=_S[_T-1]+_S[_T];_T=_T-1
    elseif _o==11 then _S[_T-1]=_S[_T-1]-_S[_T];_T=_T-1
    elseif _o==12 then _S[_T-1]=_S[_T-1]*_S[_T];_T=_T-1
    elseif _o==13 then _S[_T-1]=_S[_T-1]/_S[_T];_T=_T-1
    elseif _o==14 then _S[_T-1]=_S[_T-1]%_S[_T];_T=_T-1
    elseif _o==15 then _S[_T-1]=_S[_T-1]^_S[_T];_T=_T-1
    elseif _o==16 then _S[_T-1]=_S[_T-1].._S[_T];_T=_T-1
    elseif _o==17 then _S[_T]=-_S[_T]
    elseif _o==18 then _S[_T]=not _S[_T]
    elseif _o==19 then _S[_T]=#_S[_T]
    elseif _o==20 then _S[_T-1]=_S[_T-1]==_S[_T];_T=_T-1
    elseif _o==21 then _S[_T-1]=_S[_T-1]<_S[_T];_T=_T-1
    elseif _o==22 then _S[_T-1]=_S[_T-1]<=_S[_T];_T=_T-1
    else return false end
    return true
  end
  _h5=function(_o,_i)
    if _o==23 then _pc=_i[3];return true
    elseif _o==24 then if _S[_T] then _T=_T-1;_pc=_i[3];return true end;_T=_T-1;return false
    elseif _o==25 then if not _S[_T] then _T=_T-1;_pc=_i[3];return true end;_T=_T-1;return false
    elseif _o==33 then if _S[_T] then _pc=_i[3];return true end;return false
    elseif _o==34 then if not _S[_T] then _pc=_i[3];return true end;return false
    else return false end
    return false
  end
  _h6=function(_o,_i)
    if _o==26 or _o==31 then
      local _n=_i[2]
      local _a={}
      for _=1,_n do _a[_]=_S[_T-_n+_] end
      _T=_T-_n
      local _expand=_i[3]
      if _expand>0 and _n>0 and _isva(_a[_n]) then
        local _va=_a[_n];_a[_n]=nil
        for _=1,#_va do table.insert(_a,_va[_]) end
      end
      local _f=_S[_T];_T=_T-1
      if _f==nil then error("[Aurora VM] Attempt to call nil at pc=".._pc.." op=".._o.." stackTop=".._T.." lastGlobal="..tostring(_lastGlobal).." nArgs=".._n.." flags=".._expand.." insOp=".._i[1].." insA=".._i[2].." insB=".._i[3].." trace="..table.concat(_globalTrace,",")..")") end
      if type(_f)~="function" then warn("[Aurora VM] CALL non-function at pc=".._pc.." op=".._o.." type="..type(_f).." lastGlobal="..tostring(_lastGlobal).." value="..tostring(_f)) end
      local _t0=os.clock()
      local _r={_f(_U(_a))}
      if os.clock()-_t0>0.005 then _ic=0 end
      if _o==31 then
        _T=_T+1;_S[_T]=_mkva(_r)
      else
        _T=_T+1;_S[_T]=_r[1]
      end
    elseif _o==27 then
      local _n=_i[2]
      local _r={}
      for _=1,_n do _r[_]=_S[_T-_n+_] end
      if _n>0 and _isva(_r[_n]) then
        local _va=_r[_n]
        _r[_n]=nil
        for _=1,#_va do table.insert(_r,_va[_]) end
      end
      _ret=_r;_returned=true;return true
    elseif _o==32 then
      local _n=_i[2]
      local _m=_S[_T]
      _T=_T-1
      for _=1,_n do
        if _m and _m[_]~=nil then
          _T=_T+1;_S[_T]=_m[_]
        else
          _T=_T+1;_S[_T]=nil
        end
      end
    elseif _o==28 then
      local _p=_P.p[_i[2]+1]
      _T=_T+1;_S[_T]=function(...)
        local _a={...}
        local _va={}
        for _=_p.n+1,#_a do _va[_-_p.n]=_a[_] end
        local _r=_run(_p,_a,_va)
        if _r then return _U(_r) end
      end
    elseif _o==29 then
      if _i[2]==1 then
        _T=_T+1;_S[_T]=_mkva(_V)
      else
        _T=_T+1;_S[_T]=_V[1]
      end
    elseif _o==30 then
      local _t=_S[_T]
      for _=1,#_V do _t[#_t+1]=_V[_] end
    else return false end
    return true
  end
  while true do
    _ic=_ic+1
    if _ic>2000000 then error("[Aurora VM] Watchdog timeout at pc=".._pc.." op=".._o,0) end
    if _ic%1000==0 then local _Y=task and task.wait;if _Y then pcall(_Y,0) end end
    local _i=_C[_pc]
    if _i==nil then break end
    local _o=_REVERSE[_i[1]] or _i[1]
    local _jmp=false
    if _h1(_o,_i) then
    elseif _h2(_o,_i) then
    elseif _h3(_o,_i) then
    elseif _h4(_o,_i) then
    elseif _h5(_o,_i) then _jmp=true
    elseif _h6(_o,_i) then
    end
    if _returned then return _ret end
    if not _jmp then _pc=_pc+1 end
  end
end
`;

// ---------- Bytecode to Lua table literal ----------

function encodeConstantFlat(c: ConstantValue): number[] {
  switch (c.type) {
    case "nil":
      return [0];
    case "boolean":
      return [1, c.value === true ? 1 : 0];
    case "number": {
      // Encode as a length-prefixed string so the runtime can tonumber() it.
      const s = (c.value as number).toString();
      const b = Array.from(new TextEncoder().encode(s));
      const out: number[] = [2];
      writeU32(out, b.length);
      out.push(...b);
      return out;
    }
    case "string": {
      const b = Array.from(new TextEncoder().encode(c.value as string)).map((byte, i) => byte ^ ((0x6B + i * 0x9D) & 0xFF));
      const out: number[] = [3];
      writeU32(out, b.length);
      out.push(...b);
      return out;
    }
  }
}

function protoToFlatBytes(proto: Proto): number[] {
  const out: number[] = [];
  // header: numParams (uint32 little-endian) and vararg flag
  writeU32(out, proto.numParams);
  out.push(proto.isVararg ? 1 : 0);
  // constants count (uint32)
  writeU32(out, proto.constants.length);
  for (const c of proto.constants) {
    out.push(...encodeConstantFlat(c));
  }
  // global names count (uint32) - integer-indexed global name table
  writeU32(out, proto.globalNames ? proto.globalNames.length : 0);
  for (const gn of (proto.globalNames || [])) {
    const b = Array.from(new TextEncoder().encode(gn));
    writeU32(out, b.length);
    out.push(...b);
  }
  // code - opcodes are already mapped by CompilerCtx.emit()
  // instruction format: op(1 byte), a(uint32 little-endian), b(uint32 little-endian)
  writeU32(out, proto.code.length);
  for (const ins of proto.code) {
    out.push(ins.op & 0xff);
    writeVarint(out, ins.a);
    writeVarint(out, ins.b);
  }
  // child protos count (uint32)
  writeU32(out, proto.protos.length);
  for (const p of proto.protos) {
    out.push(...protoToFlatBytes(p));
  }
  // defensive validation: every byte must be 0-255
  for (let i = 0; i < out.length; i++) {
    const v = out[i];
    if (v < 0 || v > 255 || !Number.isInteger(v)) {
      throw new Error(`Invalid bytecode byte at index ${i}: ${v}`);
    }
  }
  return out;
}

// ---------- Public API ----------

export function canCompileWithVM(source: string): boolean {
  try {
    // Preprocess Luau syntax before parsing
    const preprocessed = preprocessLuau(source);
    luaparse.parse(preprocessed, { luaVersion: '5.2', scope: true, locations: false, comments: false });
    return true;
  } catch {
    return false;
  }
}

export function tryCompileToVM(
  source: string,
  options: VMObfuscationOptions = VM_DEFAULT_OPTIONS
): { success: true; output: string } | { success: false; error: string } {
  try {
    if (!source.trim()) return { success: true, output: "-- empty source\n" };

    // NOTE: Caller must preprocess with preprocessLuau() before calling.
    // We parse directly to avoid double-preprocessing corruption.
    const ast = luaparse.parse(source, {
      luaVersion: '5.2',
      scope: true,
      locations: false,
      comments: false,
    });

    // Generate random opcode mapping for this compilation
    const opcodeMap = generateOpcodeMapping();
    const ctx = new CompilerCtx(opcodeMap);
    if (ast.type === "Chunk") {
      ast.body.forEach((n) => compileNode(ctx, n));
    } else {
      compileNode(ctx, ast);
    }

    if (ctx.proto.code.length === 0 || ctx.proto.code[ctx.proto.code.length - 1].op !== OpCode.RETURN) {
      ctx.emit(OpCode.RETURN, 0);
    }

    const protoBytes = protoToFlatBytes(ctx.proto);
    const masterSeed = randomBytes(options.keyLength);
    const { bytecodeKey, opmapKey } = deriveKeys(masterSeed, options.keyLength);
    const encrypted = xorBytes(protoBytes, bytecodeKey);
    const encryptedMap = xorBytes(opcodeMap, opmapKey); // Independent key for opcode mapping

    const header = options.watermark ? `-- ${options.watermark}\n-- Protected by Aurora X VM v4.0 (real bytecode VM)\n` : "";
    // Dead code injection (luraph-style)
    const deadCode = generateDeadCode();
    const opaquePredicates = generateOpaquePredicates();
    const misleadingGlobals = generateMisleadingGlobals();

    const output = `${header}${VM_RUNTIME_HELPERS}
_E={}
rawset(_E,"print",print)
rawset(_E,"warn",warn)
rawset(_E,"error",error)
rawset(_E,"pcall",pcall)
rawset(_E,"xpcall",xpcall)
rawset(_E,"tostring",tostring)
rawset(_E,"tonumber",tonumber)
rawset(_E,"type",type)
rawset(_E,"assert",assert)
rawset(_E,"select",select)
rawset(_E,"pairs",pairs)
rawset(_E,"ipairs",ipairs)
rawset(_E,"next",next)
rawset(_E,"unpack",unpack or table.unpack)
rawset(_E,"rawget",rawget)
rawset(_E,"rawset",rawset)
rawset(_E,"rawequal",rawequal)
rawset(_E,"setmetatable",setmetatable)
rawset(_E,"getmetatable",getmetatable)
pcall(function() rawset(_E,"collectgarbage",collectgarbage) end)
pcall(function() rawset(_E,"getfenv",getfenv) end)
pcall(function() rawset(_E,"setfenv",setfenv) end)
pcall(function() rawset(_E,"newproxy",newproxy) end)
rawset(_E,"loadstring",function(s,n)
  if type(s)=="string" then
    local u=s:match("(https?://[^%s]+)")
    if u and not u:match("^https://api%.aurorax%.site/") and not u:match("^https://raw%.githubusercontent%.com/") then
      error("[Aurora X] loadstring bloqueado: origen no autorizado")
    end
  end
  return loadstring(s,n)
end)
rawset(_E,"load",function(...)
  local a={...}
  if type(a[1])=="string" then
    local u=a[1]:match("(https?://[^%s]+)")
    if u and not u:match("^https://api%.aurorax%.site/") and not u:match("^https://raw%.githubusercontent%.com/") then
      error("[Aurora X] loadstring bloqueado: origen no autorizado")
    end
  end
  return load(...)
end)
rawset(_E,"string",string)
rawset(_E,"table",table)
rawset(_E,"math",math)
rawset(_E,"coroutine",coroutine)
pcall(function() rawset(_E,"bit32",bit32) end)
rawset(_E,"os",os)
rawset(_E,"game",game)
rawset(_E,"sea1",false)
rawset(_E,"sea2",false)
rawset(_E,"sea3",false)
rawset(_E,"shared",(shared or _G or {}))
local _REAL_ENV = _G or ((typeof~="nil" and typeof(getfenv)=="function") and getfenv()) or {}
rawset(_E,"_REAL_ENV",_REAL_ENV)
rawset(_E,"_G",_REAL_ENV)
pcall(function()
  if shared and not shared.game then
    shared.game = game
    shared.workspace = workspace
    shared.Players = Players
    shared.Instance = Instance
  end
end)
-- Inject executor APIs by RESOLVING real values (not storing chunk functions)
local function _inject(_gn)
  local _ok, _val = pcall(function()
    if type(getgenv) == "function" then
      local _g = getgenv()
      if type(_g) == "table" and _g[_gn] ~= nil then return _g[_gn] end
    end
    if type(_G) == "table" and _G[_gn] ~= nil then return _G[_gn] end
    if type(getfenv) == "function" then
      local _e = getfenv(0)
      if type(_e) == "table" and _e[_gn] ~= nil then return _e[_gn] end
    end
    if type(loadstring) == "function" then
      local _chunk = loadstring("return " .. _gn)
      if type(_chunk) == "function" then
        local _ok2, _v2 = pcall(_chunk)
        if _ok2 and _v2 ~= nil then return _v2 end
      end
    end
    return nil
  end)
  if _ok and _val ~= nil then rawset(_E, _gn, _val) end
end
local _EXEC_FNS = {"getgenv","getrawmetatable","hookfunction","hookmetamethod","getnamecallmethod","checkcaller","newcclosure","islclosure","iscclosure","getinfo","getconstants","getupvalues","getstack","setstack","identifyexecutor","getexecutorname","saveinstance","decompile","getscriptclosure","getscripthash","cloneref","compareinstances","request","http_request","syn_request","getgc","getinstances","getnilinstances","getscripts","getrunningscripts","getloadedmodules","getconnections","setsimulationradius","sethiddenproperty","gethiddenproperty","isscriptable","setscriptable","getproperties","replaceclosure","fireclickdetector","firetouchinterest","fireproximityprompt","setreadonly","isreadonly","getsenv","getrawproto","getrawprotos","getrawconstant","getrawconstants","typeof","setclipboard","isnetworkowner","settings","setfflag","getfflag"}
local _EXEC_LIBS = {"Drawing","crypt","buffer","bit","websocket","Mouse","syn","fluxus","KRNL_LOADED"}
for _, _gn in ipairs(_EXEC_FNS) do _inject(_gn) end
for _, _gn in ipairs(_EXEC_LIBS) do _inject(_gn) end
-- Resolve Roblox globals safely with GetService fallback
local function _safe(name, fallbackFn)
  local ok, v = pcall(function()
    if type(getgenv) == "function" then
      local g = getgenv()
      if type(g) == "table" and g[name] ~= nil then return g[name] end
    end
    if type(_G) == "table" and _G[name] ~= nil then return _G[name] end
    if fallbackFn then return fallbackFn() end
    return nil
  end)
  if ok then return v end
  return nil
end
rawset(_E, "workspace", _safe("workspace", function() return game:GetService("Workspace") end) or workspace)
rawset(_E, "Players", _safe("Players", function() return game:GetService("Players") end))
rawset(_E, "UserInputService", _safe("UserInputService", function() return game:GetService("UserInputService") end))
rawset(_E, "RunService", _safe("RunService", function() return game:GetService("RunService") end))
rawset(_E, "HttpService", _safe("HttpService", function() return game:GetService("HttpService") end))
rawset(_E, "ReplicatedStorage", _safe("ReplicatedStorage", function() return game:GetService("ReplicatedStorage") end))
rawset(_E, "Lighting", _safe("Lighting", function() return game:GetService("Lighting") end))
rawset(_E, "StarterGui", _safe("StarterGui", function() return game:GetService("StarterGui") end))
rawset(_E, "SoundService", _safe("SoundService", function() return game:GetService("SoundService") end))
rawset(_E, "Teams", _safe("Teams", function() return game:GetService("Teams") end))
rawset(_E, "MarketplaceService", _safe("MarketplaceService", function() return game:GetService("MarketplaceService") end))
rawset(_E, "TeleportService", _safe("TeleportService", function() return game:GetService("TeleportService") end))
rawset(_E, "TweenService", _safe("TweenService", function() return game:GetService("TweenService") end))
rawset(_E, "PathfindingService", _safe("PathfindingService", function() return game:GetService("PathfindingService") end))
rawset(_E, "Debris", _safe("Debris", function() return game:GetService("Debris") end))
rawset(_E, "Stats", _safe("Stats", function() return game:GetService("Stats") end))
rawset(_E, "Instance", _safe("Instance", function() return Instance end))
rawset(_E, "CFrame", _safe("CFrame", function() return CFrame end))
rawset(_E, "Vector3", _safe("Vector3", function() return Vector3 end))
rawset(_E, "Vector2", _safe("Vector2", function() return Vector2 end))
rawset(_E, "UDim2", _safe("UDim2", function() return UDim2 end))
rawset(_E, "UDim", _safe("UDim", function() return UDim end))
rawset(_E, "Color3", _safe("Color3", function() return Color3 end))
rawset(_E, "Enum", _safe("Enum", function() return Enum end))
rawset(_E, "Drawing", _safe("Drawing", function() return Drawing end))
rawset(_E, "crypt", _safe("crypt", function() return crypt end))
rawset(_E, "buffer", _safe("buffer", function() return buffer end))
rawset(_E, "bit", _safe("bit", function() return bit end))
rawset(_E, "utf8", _safe("utf8", function() return utf8 end))
rawset(_E, "debug", _safe("debug", function() return debug end))
rawset(_E, "task", _safe("task", function() return task end))
rawset(_E, "wait", _safe("wait", function() return wait end))
rawset(_E, "spawn", _safe("spawn", function() return spawn end))
rawset(_E, "delay", _safe("delay", function() return delay end))
rawset(_E, "tick", _safe("tick", function() return tick end))
rawset(_E, "time", _safe("time", function() return time end))
rawset(_E, "typeof", _safe("typeof", function() return typeof end))
rawset(_E, "require", _safe("require", function() return require end))
rawset(_E,"setmetatable",_setmetatable)
rawset(_E,"getmetatable",_getmetatable)
_E=_RSM(_E,{__index=function(_t,_k)
  -- Check _REAL_ENV FIRST (external toggles update this, not _E)
  if _REAL_ENV and _REAL_ENV[_k]~=nil then return _REAL_ENV[_k] end
  local _v=rawget(_t,_k)
  if _v~=nil then return _v end
  if getgenv then
    local _ok,_gv=pcall(function() return getgenv()[_k] end)
    if _ok and _gv~=nil then return _gv end
  end
  if getfenv then
    local _ok,_fv=pcall(function() return getfenv()[_k] end)
    if _ok and _fv~=nil then return _fv end
  end
  return nil
end})
local _t0=(_E.os and _E.os.clock and _E.os.clock())or 0
local _xor=(bit32 and bit32.bxor)or(bit and bit.bxor)or function(a,b)
  local r=0
  local p=1
  for _=1,8 do
    local ab=a%2
    local bb=b%2
    if ab~=bb then r=r+p end
    a=(a-ab)*0.5
    b=(b-bb)*0.5
    p=p+p
  end
  return r
end
local _K={${bytecodeKey.join(",")}}
local _K2={${opmapKey.join(",")}}
local _OM={${encryptedMap.join(",")}}
local _D_b64="${bytesToBase64(encrypted)}"
for i=1,#_OM do _OM[i]=_xor(_OM[i],_K2[(i-1)%#_K2+1]) end
-- base64 decode to reconstruct bytecode table (fast path via crypt if available)
local _D={}
local _b64ok=false
pcall(function()
  local _c=nil
  pcall(function() _c=crypt.base64decode end)
  if _c==nil then pcall(function() _c=crypt.base64_decode end) end
  if _c then
    local _s,_r=pcall(_c,_D_b64)
    if _s and type(_r)=="string" then
      for _i=1,#_r do _D[_i]=_r:byte(_i) end
      _b64ok=true
    end
  end
end)
if not _b64ok then
  local _b64_t={}
  for i=1,64 do _b64_t[string.sub("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",i,i)]=i-1 end
  local _bp=1
  while _bp<=#_D_b64 do
    local _a=_b64_t[_D_b64:sub(_bp,_bp)]or 0
    local _b=_b64_t[_D_b64:sub(_bp+1,_bp+1)]or 0
    local _c=_b64_t[_D_b64:sub(_bp+2,_bp+2)]or 0
    local _d=_b64_t[_D_b64:sub(_bp+3,_bp+3)]or 0
    _D[#_D+1]=_a*4+math.floor(_b/16)
    if _D_b64:sub(_bp+2,_bp+2)~="=" then _D[#_D+1]=(_b%16)*16+math.floor(_c/4) end
    if _D_b64:sub(_bp+3,_bp+3)~="=" then _D[#_D+1]=(_c%4)*64+_d end
    _bp=_bp+4
  end
end
for i=1,#_D do _D[i]=_xor(_D[i],_K[(i-1)%#_K+1]) end
local _REVERSE={}
for i=1,#_OM do _REVERSE[_OM[i]]=i-1 end
${VM_MULTI_HANDLER_RUNTIME}
local _I=1
local function _N()
  local _v=_D[_I];_I=_I+1
  return _v
end
local function _N32()
  local _b0=_D[_I];_I=_I+1
  local _b1=_D[_I];_I=_I+1
  local _b2=_D[_I];_I=_I+1
  local _b3=_D[_I];_I=_I+1
  return _b0+(_b1*256)+(_b2*65536)+(_b3*16777216)
end
local function _readVarint()
  local _v=0
  local _s=0
  while true do
    local _b=_N()
    _v=_v+((_b%128)*math.floor(2^_s))
    if _b<128 then break end
    _s=_s+7
  end
  return _v
end
local function _decodeProto()
  local _P={n=_N32(),v=_N()==1,c={},k={},p={}}
  local _nc=_N32()
  for _=1,_nc do
    local _t=_N()
    if _t==0 then table.insert(_P.k,{__nil=true})
    elseif _t==1 then table.insert(_P.k,_N()==1)
    elseif _t==2 then
      local _l=_N32()
      local _s={}
      for __=1,_l do _s[__]=string.char(_N()) end
      table.insert(_P.k,tonumber(table.concat(_s)))
    elseif _t==3 then
      local _l=_N32()
      local _s={}
      for __=1,_l do _s[__]=string.char(_xor(_N(),((0x6B+(__-1)*0x9D)%256))) end
      table.insert(_P.k,table.concat(_s))
    end
  end
  -- Decode integer-indexed global name table
  local _gnCount=_N32()
  _P.gn={}
  for _=1,_gnCount do
    local _gl=_N32()
    local _gs={}
    for __=1,_gl do _gs[__]=string.char(_N()) end
    table.insert(_P.gn,table.concat(_gs))
  end
  local _ni=_N32()
  for _=1,_ni do
    local _op=_N()
    local _a=_readVarint()
    local _b=_readVarint()
    table.insert(_P.c,{_op,_a,_b})
  end
  local _np=_N32()
  for _=1,_np do
    table.insert(_P.p,_decodeProto())
  end
  return _P
end
local _P=_decodeProto()
task.spawn(_run,_P,{},{})
`;

      return { success: true, output };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export function obfuscateLuaVM(
  source: string,
  options: VMObfuscationOptions = VM_DEFAULT_OPTIONS
): { output: string; usedVM: boolean; error?: string } {
  // Preprocess Luau → Lua 5.2 so the parser can handle it
  const preprocessed = preprocessLuau(source);
  const vm = tryCompileToVM(preprocessed, options);
  if (vm.success) {
    return { output: vm.output, usedVM: true };
  }
  return { output: "", usedVM: false, error: vm.error };
}
